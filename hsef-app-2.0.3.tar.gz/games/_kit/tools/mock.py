"""خادم تجريبي صغير يحاكي التلفاز لتجربة الألعاب على الكمبيوتر.

    python3 games/_kit/tools/mock.py 8766
ثم افتح: http://127.0.0.1:8766/tv/game/1/<اسم اللعبة>/index.html

- يخدم مجلدات الألعاب كما يخدمها التلفاز (/tv/game/1/...)، والخطوط من /static.
- /api/tv/tile/1/list?sub=<مجلد>: قائمة ملفات مجلد داخل games (مثل صور اللعبة).
- /api/tv/wallpaper و /api/tv/photo/<n>/view: «صور الطفل» من مجلد tools/photos إن وُجد.
- POST /api/tv/stars/earn: يحاكي نجمة إنهاء الدرس (رصيد يبدأ بـ 10، وحد يومي 20): نجمة واحدة إن كان app.json
  في مجلد التطبيق يقول education، ولا شيء للألعاب. انظر _kit/API.txt.
- /api/tv/family/people و /api/tv/face/<n> و /api/tv/face/<n>/photo: «صور العائلة» من tools/faces/<الاسم>/*.jpg
  إن وُجد، وإلا وجوه مرسومة لأربعة أشخاص (بابا، ماما، جدّو، تيتا).
- POST /api/tv/learn/result: يطبع النتيجة فقط (لتقرير الأهل)، انظر _kit/API.txt.
- GET/PUT /api/tv/save: حفظ التقدّم في الذاكرة (البند 50)، وGET /api/tv/tts: صوت espeak-ng إن وُجد وإلا صوت صامت (البند 58).
"""
import http.server
import io
import json
import mimetypes
import os
import shutil
import subprocess
import sys
import urllib.parse
import wave

TOOLS = os.path.dirname(os.path.abspath(__file__))
GAMES = os.path.dirname(os.path.dirname(TOOLS))          # home-nas/games
ROOT = os.path.dirname(GAMES)                             # home-nas
PHOTOS = os.path.join(TOOLS, "photos")


STARS = {"balance": 10, "today": 0, "limit": 20}
FACES_DIR = os.path.join(TOOLS, "faces")
COLORS = ["#f59e0b", "#ec4899", "#22c55e", "#3b82f6", "#a855f7", "#ef4444"]


def family():
    """[(id, name, path_or_None)] — من tools/faces إن وُجد، وإلا وجوه مرسومة."""
    out, n = [], 0
    if os.path.isdir(FACES_DIR):
        for name in sorted(os.listdir(FACES_DIR)):
            d = os.path.join(FACES_DIR, name)
            if os.path.isdir(d):
                for f in sorted(os.listdir(d)):
                    if f.lower().endswith((".jpg", ".jpeg", ".png")):
                        n += 1
                        out.append((n, name, os.path.join(d, f)))
    if not out:
        for name in ("بابا", "ماما", "جدّو", "تيتا"):
            for _ in range(3):
                n += 1
                out.append((n, name, None))
    return out


def face_svg(fid, name):
    c = COLORS[(fid - 1) % len(COLORS)]
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="{c}"/>'
            f'<circle cx="100" cy="92" r="58" fill="#fde2c8"/><circle cx="80" cy="85" r="7" fill="#333"/><circle cx="120" cy="85" r="7" fill="#333"/>'
            f'<path d="M78 112 Q100 {128 + fid % 3 * 4} 122 112" stroke="#333" stroke-width="6" fill="none" stroke-linecap="round"/>'
            f'<text x="100" y="190" font-size="26" text-anchor="middle" fill="#fff" font-family="sans-serif">{name}</text></svg>').encode()


SAVES = {}


def tts_wav(text, rate):
    exe = shutil.which("espeak-ng") or shutil.which("espeak")
    if exe and text:
        try:
            r = subprocess.run([exe, "-v", "ar", "-s", str(max(80, min(200, int(rate or 130)))), "--stdout", "--", text[:200]], capture_output=True, timeout=20)
            if r.returncode == 0 and len(r.stdout) > 100:
                return r.stdout
        except (OSError, ValueError, subprocess.TimeoutExpired):
            pass
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000); w.writeframes(b"\0\0" * 800)
    return buf.getvalue()


class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def file(self, p):
        if os.path.isdir(p):
            p = os.path.join(p, "index.html")
        if not os.path.isfile(p):
            return self.send(404, b"not found", "text/plain")
        self.send(200, open(p, "rb").read(), mimetypes.guess_type(p)[0] or "application/octet-stream")

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        path, qs = urllib.parse.unquote(u.path), urllib.parse.parse_qs(u.query)
        if path.startswith("/tv/game/1/"):
            return self.file(os.path.join(GAMES, path[len("/tv/game/1/"):]))
        if path.startswith("/static/"):
            return self.file(os.path.join(ROOT, path[1:]))
        if path == "/api/tv/tile/1/list":
            d = os.path.join(GAMES, qs.get("sub", [""])[0])
            if not os.path.isdir(d):
                return self.send(200, json.dumps({"items": [], "missing": True}).encode())
            items = [{"name": n, "type": "image" if n.lower().endswith((".jpg", ".jpeg", ".png", ".webp")) else "other"} for n in sorted(os.listdir(d))]
            return self.send(200, json.dumps({"items": items}).encode())
        if path == "/api/tv/family/people":
            people = {}
            for fid, name, _ in family():
                people.setdefault(name, []).append(fid)
            data = [{"id": i + 1, "name": k, "faces": v[:6], "count": len(v)} for i, (k, v) in enumerate(people.items())]
            return self.send(200, json.dumps({"people": data}, ensure_ascii=False).encode())
        if path == "/api/tv/save":   # البند 50: حفظ التقدّم (في الذاكرة فقط)
            k = qs.get("key", [""])[0]
            return self.send(200, json.dumps({"found": True, "value": SAVES[k]} if k in SAVES else {"found": False}, ensure_ascii=False).encode())
        if path == "/api/tv/tts":   # البند 58: espeak-ng إن وُجد، وإلا صوت صامت قصير (لتجربة اللعبة بلا أخطاء)
            return self.send(200, tts_wav(qs.get("t", [""])[0], qs.get("r", ["130"])[0]), "audio/wav")
        if path.startswith("/api/tv/face/"):
            fid = int(path.split("/")[4])
            hit = next((x for x in family() if x[0] == fid), None)
            if not hit:
                return self.send(404, b"nf", "text/plain")
            return self.file(hit[2]) if hit[2] else self.send(200, face_svg(fid, hit[1]), "image/svg+xml")
        photos = sorted(os.listdir(PHOTOS)) if os.path.isdir(PHOTOS) else []
        if path == "/api/tv/wallpaper":
            return self.send(200, json.dumps({"ids": list(range(1, len(photos) + 1))}).encode())
        if path.startswith("/api/tv/photo/"):
            i = int(path.split("/")[4])
            return self.file(os.path.join(PHOTOS, photos[i - 1])) if 0 < i <= len(photos) else self.send(404, b"nf", "text/plain")
        self.send(404, b"not found", "text/plain")

    def do_PUT(self):
        path = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            d = {}
        if path == "/api/tv/save" and isinstance(d.get("value"), dict):
            SAVES[str(d.get("key", ""))] = d["value"]
            return self.send(200, b'{"ok": true}')
        self.send(404, b"not found", "text/plain")

    def do_POST(self):
        path = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            d = {}
        if path == "/api/tv/learn/result":
            print(f"📘 {d.get('game')} · {d.get('topic')} · {'✓' if d.get('ok') else '✗'}", flush=True)
            return self.send(200, json.dumps({"ok": True, "stored": True}).encode())
        if path != "/api/tv/stars/earn":
            return self.send(404, b"not found", "text/plain")
        try:
            amount = int(d.get("amount"))
        except (TypeError, ValueError):
            return self.send(400, json.dumps({"error": "amount غير صالح"}).encode())
        if not 1 <= amount <= 10 or not str(d.get("game") or "").strip():
            return self.send(400, json.dumps({"error": "amount من 1 إلى 10، و game مطلوب"}).encode())
        # مثل السيرفر (v1.9.6): التطبيق التعليمي (app.json: education) يأخذ نجمة واحدة، واللعبة لا شيء
        ref = urllib.parse.unquote(urllib.parse.urlparse(self.headers.get("Referer") or "").path)
        app = ref[len("/tv/game/1/"):].split("/")[0] if ref.startswith("/tv/game/1/") else ""
        try:
            kind = json.load(open(os.path.join(GAMES, app, "app.json"), encoding="utf-8")).get("type") if app else None
        except (OSError, ValueError):
            kind = None
        learn = kind == "education"
        added = max(0, min(1, STARS["limit"] - STARS["today"])) if learn else 0
        STARS["balance"] += added
        STARS["today"] += added
        print(f"{'📚' if learn else '🎮'} +{added} ({d.get('game')}: {d.get('reason')}) → {STARS['balance']}", flush=True)
        self.send(200, json.dumps({"ok": True, "added": added, "balance": STARS["balance"], "today": STARS["today"],
                                   "limit": STARS["limit"], "capped": learn and added < 1, "learn": learn}).encode())


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8766
    print(f"http://127.0.0.1:{port}/tv/game/1/<اسم اللعبة>/index.html")
    http.server.ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
