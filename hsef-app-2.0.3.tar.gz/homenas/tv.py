"""وضع التلفاز: واجهة تظهر على الشاشة الموصولة بالسيرفر، تُدار بالكامل من لوحة التحكم.

- كل مستخدم له «ملف» على التلفاز: بالغ (برمز PIN)، طفل (يظهر تاريخ ميلاده)، أو طفل صغير.
- لكل ملف «مربعات» يضيفها المدير ويحذفها ويرتبها؛ كل مربع مرتبط بمجلد في ملفات المستخدم
  (مثل سارة/التلفاز/رسوم متحركة): ما يوضع في المجلد يظهر على التلفاز.
- أنواع المربعات: وسائط (فيديو، صوت، صور، كتب/صفحات)، ألعاب (كل لعبة مجلد فيه index.html)،
  ومكتبة صوري (صور المستخدم في تطبيق الصور).
- واجهة التلفاز تعمل من نفس الجهاز (127.0.0.1)؛ ويستطيع المدير معاينتها من متصفحه.
"""
from __future__ import annotations

import json
import mimetypes
import os
import re
import shutil
import subprocess
from urllib.parse import quote
from datetime import date, datetime
from pathlib import Path

from flask import Blueprint, abort, jsonify, render_template, request, send_file, session
from werkzeug.security import check_password_hash, generate_password_hash

from .core import (BROWSER_IMAGE_EXT, IMAGE_EXT, RECYCLE, VIDEO_EXT, admin_required, body, current_user, get_db, get_setting,
                   log_action, now_iso, paths, set_setting)
from . import mawaqit, prayer, welcome

bp = Blueprint("tv", __name__)

AUDIO_EXT = {".mp3", ".m4a", ".aac", ".flac", ".wav", ".ogg", ".opus"}
# صيغ فيديو قديمة يعرضها التلفاز أيضاً (تُحوَّل مرة واحدة عند أول تشغيل)
TV_VIDEO_EXT = VIDEO_EXT | {".rmvb", ".rm", ".asf", ".wmv", ".vob", ".flv", ".f4v", ".mpg", ".mpeg", ".ts", ".m2ts", ".mts",
                            ".divx", ".ogv"}
BOOK_EXT = {".pdf"}
ROLES = ("none", "adult", "kid", "little")
KINDS = ("media", "games", "learn", "photos", "cameras")
NOFOLDER = ("photos", "cameras")   # مربعات بلا مجلد
APP_KINDS = ("games", "learn")     # مربعات مجلدها مجلد مشترك لكل العائلة
TV_DIR = "التلفاز"
HELPER = "/usr/local/sbin/hsef-extras"
APPLIANCE = os.environ.get("HOMENAS_APPLIANCE") == "1"

ICONS = ["cartoon", "music", "animals", "math", "games", "photos", "video", "quran", "book", "film", "star", "heart",
         "science", "letters", "nature", "sport", "camera"]
COLORS = ["#a855f7,#ec4899", "#f97316,#ef4444", "#22c55e,#15803d", "#06b6d4,#2563eb", "#8b5cf6,#06b6d4",
          "#f59e0b,#f97316", "#10b981,#0ea5e9", "#0f766e,#14532d", "#64748b,#1e293b", "#e11d48,#7f1d1d"]

GAMES_SHARE = "الألعاب"      # مجلد مشترك واحد لكل ألعاب التلفاز (بلا نجوم)
GAMES_PATH = "/" + GAMES_SHARE
EDU_SHARE = "التعليم"        # مجلد مشترك للتطبيقات التعليمية (إنهاء الدرس = نجمة)
EDU_PATH = "/" + EDU_SHARE
SHARES = {   # نوع المربع ← (اسم المجلد المشترك، وصفه)
    "games": (GAMES_SHARE, "ألعاب التلفاز لكل العائلة: ضع كل لعبة في مجلد خاص بها. الألعاب لا تعطي نجوماً"),
    "learn": (EDU_SHARE, "التطبيقات التعليمية لكل العائلة: كل تطبيق في مجلد خاص به. إنهاء الدرس يعطي نجمة واحدة"),
}
SHARE_PATH = {k: "/" + v[0] for k, v in SHARES.items()}

# التطبيقات التعليمية التي كانت في مجلد «الألعاب» قبل v1.9.6 (تُنقل إلى «التعليم» مرة واحدة)
EDU_APPS = ("حروفي العربية", "الكلمة المفقودة", "جملة", "الجمع والطرح", "جدول الضرب", "الرياضيات بالأشياء",
            "الساعة والتقويم", "جغرافيا", "روبوت البرمجة", "الفرنسية", "الألمانية", "الإسبانية", "الهولندية",
            "التركية", "السويدية", "حفظ القرآن", "الوضوء والصلاة", "قصص الأنبياء", "موسوعة الحيوانات",
            "عالم الحيوان", "سارة والتفكير")

DEFAULT_TILES = {
    "kid": [("رسوم متحركة", "media", "cartoon", 0), ("أناشيد", "media", "music", 1), ("عالم الحيوان", "media", "animals", 2),
            ("عالم الرياضيات", "media", "math", 3), ("ألعاب", "games", "games", 4), ("التعليم", "learn", "letters", 2),
            ("صوري", "photos", "photos", 5), ("فيديوهاتي", "media", "video", 6), ("القرآن الكريم", "media", "quran", 7)],
    "little": [("ألعاب", "games", "games", 4), ("التعليم", "learn", "letters", 2), ("رسوم متحركة", "media", "cartoon", 0),
               ("أناشيد", "media", "music", 1), ("عالم الحيوان", "media", "animals", 2)],
    "adult": [("صوري", "photos", "photos", 5), ("الفيديو", "media", "video", 3), ("الأفلام", "media", "film", 9),
              ("الصوتيات", "media", "music", 2), ("القرآن الكريم", "media", "quran", 7), ("ألعاب", "games", "games", 4),
              ("التعليم", "learn", "letters", 2)],
}


SCHEMA = """
CREATE TABLE IF NOT EXISTS tv_tiles (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'media',
    path TEXT,
    icon TEXT,
    color TEXT,
    position INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_tv_tiles_user ON tv_tiles(user_id, position);
"""


def migrate(db):
    db.executescript(SCHEMA)
    cols = {r[1] for r in db.execute("PRAGMA table_info(users)")}
    for col, decl in (("display_name", "TEXT"), ("tv_role", "TEXT NOT NULL DEFAULT 'none'"), ("birthdate", "TEXT"),
                      ("avatar", "INTEGER NOT NULL DEFAULT 0"), ("tv_pin", "TEXT"),
                      ("photo_v", "INTEGER NOT NULL DEFAULT 0"), ("wallpaper", "TEXT"), ("theme", "TEXT")):
        if col not in cols:
            db.execute(f"ALTER TABLE users ADD COLUMN {col} {decl}")
    # v1.5: الاسم الجديد للسيرفر
    db.execute("UPDATE settings SET value='HOME ANAB' WHERE key='server_name' AND value='H.SEF'")
    # v1.5.5: نص اليوم الافتراضي صار «حديث، آية، حكمة» (من لم يغيّر الاختيار القديم)
    db.execute("""UPDATE settings SET value='["hadith", "ayah", "wisdom"]' WHERE key='tv_daily_kinds' AND value='["hadith", "proverb", "wisdom"]'""")
    # v1.8.2: مربع «الموسيقى» صار «الصوتيات»
    db.execute("UPDATE tv_tiles SET title='الصوتيات' WHERE title='الموسيقى'")
    db.commit()


def share_dir(db, data_paths, kind: str = "games") -> Path:
    """المجلد المشترك «الألعاب» أو «التعليم» (يُنشأ إن لم يوجد). المدير يضيف إليه من «الملفات» أو من الكمبيوتر."""
    name, desc = SHARES[kind]
    row = db.execute("SELECT path FROM folders WHERE name=?", (name,)).fetchone()
    if row:
        d = Path(row["path"])
    else:
        d = data_paths.shares / name
        db.execute("INSERT INTO folders(name, path, description, created_at, smb) VALUES (?,?,?,?,'admin')",
                   (name, str(d.resolve()), desc, now_iso()))
        db.commit()
    d.mkdir(parents=True, exist_ok=True)
    return d


def games_share_dir(db, data_paths) -> Path:
    return share_dir(db, data_paths, "games")


def app_type(d: Path) -> str | None:
    """النوع المكتوب في app.json داخل مجلد التطبيق: "game" أو "education" (أو None إن لم يوجد)."""
    for f in (d / "app.json", *(x / "app.json" for x in _only_sub(d))):
        try:
            t = json.loads(f.read_text(encoding="utf-8")).get("type")
        except (OSError, ValueError, AttributeError):
            continue
        if t in ("game", "education"):
            return t
    return None


def _only_sub(d: Path) -> list[Path]:
    """مجلد وحيد داخل مجلد التطبيق (بعد فك ضغط ZIP يكون التطبيق داخله)."""
    try:
        subs = [x for x in d.iterdir() if x.is_dir() and not x.name.startswith((".", "@", "#"))]
    except OSError:
        return []
    return subs if len(subs) == 1 else []


def set_app_type(d: Path, t: str):
    """يكتب النوع في app.json (يحافظ على باقي الحقول)."""
    f = d / "app.json"
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError):
        data = {}
    data.setdefault("name", d.name)
    data["type"] = t
    try:
        f.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    except OSError:
        pass


def app_category(app_dir: Path, db, data_paths) -> str:
    """«learn» إن كان التطبيق تعليمياً (يعطي نجمة عند إنهاء الدرس)، وإلا «games» (بلا نجوم).
    المجلد يقرر أولاً: ما في «التعليم» تعليمي، وما في «الألعاب» لعبة. خارجهما يقرر app.json."""
    p = app_dir.resolve()
    for kind in ("learn", "games"):
        try:
            p.relative_to(share_dir(db, data_paths, kind).resolve())
            return kind
        except ValueError:
            pass
    d = p
    while d != d.parent:   # أقرب app.json فوق الملف
        t = app_type(d)
        if t:
            return "learn" if t == "education" else "games"
        if (d / "index.html").is_file():
            break
        d = d.parent
    return "games"


def learn_migrate(db, data_paths):
    """v1.9.6: مجلد مشترك «التعليم». التطبيقات التعليمية تُنقل إليه من «الألعاب» (مرة واحدة)،
    ولكل ملف على التلفاز مربع «التعليم»."""
    if db.execute("SELECT 1 FROM settings WHERE key='learn_shared_v1'").fetchone():
        return
    games, edu = share_dir(db, data_paths, "games"), share_dir(db, data_paths, "learn")
    moved = 0

    def children(d: Path) -> list[Path]:
        try:
            return sorted(x for x in d.iterdir() if x.is_dir() and not x.name.startswith((".", "#", "@")))
        except OSError:
            return []
    items = []
    for x in children(games):   # التطبيقات مباشرة، أو داخل مجلد فُكّ فيه ملف ZIP (مثل «ألعاب الأطفال»)
        is_app = (x / "index.html").is_file() or any((s / "index.html").is_file() for s in _only_sub(x))
        items += [x] if is_app or x.name in EDU_APPS else children(x)
    for item in items:
        if not item.is_dir() or item.name.startswith((".", "#", "@")):
            continue
        if item.name in EDU_APPS or app_type(item) == "education":
            if (edu / item.name).exists():
                continue   # تطبيق بالاسم نفسه موجود: نترك النسخة القديمة مكانها
            try:
                item.rename(edu / item.name)
                moved += 1
            except OSError:
                pass
    for u in db.execute("SELECT id FROM users WHERE disabled=0 AND tv_role IN ('adult','kid','little')").fetchall():
        if not db.execute("SELECT 1 FROM tv_tiles WHERE user_id=? AND kind='learn'", (u["id"],)).fetchone():
            g = db.execute("SELECT position FROM tv_tiles WHERE user_id=? AND kind='games' ORDER BY position LIMIT 1",
                           (u["id"],)).fetchone()
            if g:   # بجانب «ألعاب» مباشرة
                db.execute("UPDATE tv_tiles SET position=position+1 WHERE user_id=? AND position>?", (u["id"], g["position"]))
                pos = g["position"] + 1
            else:
                pos = db.execute("SELECT COALESCE(MAX(position),-1)+1 FROM tv_tiles WHERE user_id=?", (u["id"],)).fetchone()[0]
            db.execute("INSERT INTO tv_tiles(user_id, title, kind, path, icon, color, position, created_at) VALUES (?,?,?,?,?,?,?,?)",
                       (u["id"], "التعليم", "learn", EDU_PATH, "letters", COLORS[2], pos, now_iso()))
    db.execute("INSERT INTO settings(key,value) VALUES('learn_shared_v1', ?)", (str(moved),))
    db.commit()


def games_migrate(db, data_paths):
    """v1.6.2: كل مربعات «ألعاب» تشير إلى المجلد المشترك، والألعاب الموجودة عند الأطفال تُنقل إليه،
    ولكل ملف على التلفاز (أطفال وبالغين) مربع ألعاب."""
    if db.execute("SELECT 1 FROM settings WHERE key='games_shared_v1'").fetchone():
        return
    shared = games_share_dir(db, data_paths)
    moved = 0
    for t in db.execute("SELECT t.id, t.path, u.username FROM tv_tiles t JOIN users u ON u.id=t.user_id WHERE t.kind='games'").fetchall():
        path = t["path"] or ""
        if path == GAMES_PATH:
            continue
        if path == "/home" or path.startswith("/home/"):
            old = data_paths.homes / t["username"] / path[len("/home/"):] if path != "/home" else data_paths.homes / t["username"]
            if old.is_dir() and old.resolve() != shared.resolve():
                for item in sorted(old.iterdir()):
                    if item.name.startswith(("#", ".")) or (shared / item.name).exists():
                        continue   # لعبة بالاسم نفسه موجودة: نترك النسخة القديمة مكانها
                    try:
                        item.rename(shared / item.name)
                        moved += 1
                    except OSError:
                        pass
        db.execute("UPDATE tv_tiles SET path=? WHERE id=?", (GAMES_PATH, t["id"]))
    for u in db.execute("SELECT id FROM users WHERE disabled=0 AND tv_role IN ('adult','kid','little')").fetchall():
        if not db.execute("SELECT 1 FROM tv_tiles WHERE user_id=? AND kind='games'", (u["id"],)).fetchone():
            pos = db.execute("SELECT COALESCE(MAX(position),-1)+1 FROM tv_tiles WHERE user_id=?", (u["id"],)).fetchone()[0]
            db.execute("INSERT INTO tv_tiles(user_id, title, kind, path, icon, color, position, created_at) VALUES (?,?,?,?,?,?,?,?)",
                       (u["id"], "ألعاب", "games", GAMES_PATH, "games", COLORS[4], pos, now_iso()))
    db.execute("INSERT INTO settings(key,value) VALUES('games_shared_v1', ?)", (str(moved),))
    db.commit()


# ----------------------------------------------------------------------------- مساعدات

def display_name(u) -> str:
    return (u["display_name"] or "").strip() or u["username"]


def age_info(birthdate: str | None) -> dict:
    if not birthdate:
        return {}
    try:
        b = date.fromisoformat(birthdate)
    except ValueError:
        return {}
    t = date.today()
    age = t.year - b.year - ((t.month, t.day) < (b.month, b.day))
    nxt = b.replace(year=t.year)
    if nxt < t:
        nxt = b.replace(year=t.year + 1)
    return {"age": age, "birthday_in": (nxt - t).days, "birthday_today": (nxt - t).days == 0,
            "birth_day": b.day, "birth_month": b.month, "birth_year": b.year}


def tv_settings() -> dict:
    def g(k, d):
        v = get_setting(k)
        return d if v is None else v
    return {
        "theme": g("tv_theme", "playful"), "wallpaper": g("tv_wallpaper", "animated"),
        "city": g("tv_city", ""), "lat": g("tv_lat", ""), "lon": g("tv_lon", ""), "method": g("tv_method", "mwl"),
        "hanafi": g("tv_hanafi", "0") == "1", "prayer": g("tv_prayer", "1") == "1",
        "words": json.loads(g("tv_words", '["ar","fr","en"]')), "nosleep": g("tv_nosleep", "1") == "1",
        "saver_min": int(g("tv_saver_min", "10")), "night_off": g("tv_night_off", ""),
        "pad_sleep": int(g("tv_pad_sleep", "15")),   # البند 65: دقائق بلا لعب ثم تُطفأ القبضات (0 = أبداً)
        "zoom": int(g("tv_zoom", "100")), "margin": int(g("tv_margin", "0")), "text": int(g("tv_text", "100")),
        "lite": g("tv_lite", "auto"),   # وضع خفيف للأجهزة الضعيفة: auto / on / off
        "lang": tv_lang(),               # لغة واجهة التلفاز يختارها الأبوان
        "kids_wallpaper": g("tv_kids_wallpaper", "garden"), "walls": wall_versions(),
        "night_dim": g("tv_night_dim", "auto"),   # إضاءة خفيفة جداً في الليل (من العشاء حتى الشروق): auto / off
        "source": g("tv_prayer_source", "calc"), "offsets": json.loads(g("tv_prayer_off", "{}")),
        "adhan": {**ADHAN_DEFAULT, **json.loads(g("tv_adhan", "{}"))},
        "weather": g("tv_weather", "0") == "1",   # البند 57: مطفأ حتى يفعّله الأبوان (يتصل بـ open-meteo)
        "daily_kinds": welcome.daily_kinds(),
        "saver_kind": g("tv_saver_kind", "prayer"), "saver_text": g("tv_saver_text", ""),
        "home_cards": home_cards(g("tv_home_cards", "")),
    }


# البند 63: البطاقات في الشاشة الرئيسية للبالغين، يختارها المدير للجميع (الترتيب ثابت)
HOME_CARDS = ("prayer", "text", "word", "calendar", "family", "memory")
HOME_DEFAULT = ["prayer", "text", "word"]


def home_cards(raw) -> list:
    try:
        v = json.loads(raw) if raw else HOME_DEFAULT
    except ValueError:
        v = HOME_DEFAULT
    return [k for k in HOME_CARDS if k in (v if isinstance(v, list) else HOME_DEFAULT)]


def home_family(db) -> dict:
    """أعياد الميلاد القادمة وأكثر من جمع نجوماً (لبطاقة «العائلة»)."""
    from .stars import balance, is_parent
    people = [u for u in db.execute("SELECT * FROM users WHERE disabled=0") if (u["tv_role"] or "none") != "none"]
    bdays = []
    for u in people:
        a = age_info(u["birthdate"])
        if a.get("birthday_in") is not None:
            bdays.append({"name": display_name(u), "in": a["birthday_in"], "age": (a.get("age") or 0) + (0 if a["birthday_in"] == 0 else 1)})
    bdays.sort(key=lambda x: x["in"])
    kids = [{"name": display_name(u), "stars": balance(db, u["id"])} for u in people if not is_parent(u)]
    kids.sort(key=lambda x: -x["stars"])
    db.commit()   # balance() قد يكتب رصيد البداية
    return {"birthdays": bdays[:2], "stars": [k for k in kids if k["stars"] > 0][:3]}


def home_memory(db, u):
    """صورة التُقطت في مثل هذا اليوم في سنة سابقة (لبطاقة «ذكرى من هذا اليوم»)."""
    import random
    from .kids import onthisday_rows
    try:
        rows = onthisday_rows(db, u, limit=40)
    except Exception:
        return None
    if not rows:
        return None
    r = random.choice(rows)
    year = int(r["taken_at"][:4])
    return {"id": r["id"], "year": year, "ago": datetime.now().year - year}


SAVER_KINDS = ("prayer", "photos", "fire", "text", "rain", "galaxy", "mix", "calendar", "nature", "sea", "snow", "moon", "clock")


def city_coords(s: dict):
    if s["city"] in prayer.CITIES:
        name, lat, lon = prayer.CITIES[s["city"]]
        return name, lat, lon
    try:
        return None, float(s["lat"]), float(s["lon"])
    except (TypeError, ValueError):
        return None, None, None


def weather_now(s: dict) -> dict | None:
    """درجة الحرارة لمدينة المواقيت (تُجلب في الخلفية وتُحفظ نصف ساعة)."""
    if not s.get("weather"):
        return None
    name, lat, lon = city_coords(s)
    if lat is None:
        return None
    from . import weather
    from .sysadmin import is_offline
    w = weather.current(lat, lon, is_offline())
    return (w | {"city": name}) if w else None


ADHAN_DEFAULT = {"on": False, "prayers": ["fajr", "dhuhr", "asr", "maghrib", "isha"], "volume": 80, "remind": 0, "pause": True}
PRAYER_KEYS = ("fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha")


def adhan_dir() -> Path:
    d = paths().system / "adhan"
    d.mkdir(parents=True, exist_ok=True)
    return d


WALLS = ("adult", "kids")


def wall_dir() -> Path:
    d = paths().system / "tv-wall"
    d.mkdir(parents=True, exist_ok=True)
    return d


def wall_versions() -> dict:
    """خلفية من اختيار الأهل لكل شاشة: رقم نسخة (وقت الرفع) أو 0 إن لا توجد."""
    out = {}
    for w in WALLS:
        f = wall_dir() / f"{w}.jpg"
        out[w] = int(f.stat().st_mtime) if f.exists() else 0
    return out


def adhan_files() -> dict:
    return {w: (adhan_dir() / f"{w}.mp3").exists() for w in ("main", "fajr")}


def prayer_now(s: dict) -> dict | None:
    if not s["prayer"] and not s["adhan"].get("on"):
        return None
    if s.get("source") == "mawaqit":
        from . import mawaqit
        data = mawaqit.load(paths().system)
        now = datetime.now().astimezone()
        t = mawaqit.times_for(data, now.date())
        if t:
            out = prayer.finish(t, now, s.get("offsets"))
            out["city"] = data.get("name")
            out["source"] = "mawaqit"
            out["jumua"] = data.get("jumua")
            return out
    lat, lon = s["lat"], s["lon"]
    if s["city"] in prayer.CITIES:
        _, lat, lon = prayer.CITIES[s["city"]]
    try:
        lat, lon = float(lat), float(lon)
    except (TypeError, ValueError):
        return {"city": None, "times": None}
    out = prayer.today(lat, lon, s["method"], s["hanafi"], offsets=s.get("offsets"))
    out["city"] = prayer.CITIES[s["city"]][0] if s["city"] in prayer.CITIES else None
    out["source"] = "calc"
    return out


def file_kind(name: str) -> str | None:
    ext = os.path.splitext(name)[1].lower()
    if ext in TV_VIDEO_EXT:
        return "video"
    if ext in AUDIO_EXT:
        return "audio"
    if ext in IMAGE_EXT:
        return "image"
    if ext in BOOK_EXT:
        return "pdf"
    return None


def user_row(uid: int):
    return get_db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()


def tile_folder(owner, tile) -> Path | None:
    """المجلد الحقيقي للمربع، بصلاحيات صاحبه (لا يصل لأي مكان لا يصل إليه المستخدم نفسه)."""
    from .vfs import resolve
    if not tile["path"]:
        return None
    sp = SHARE_PATH.get(tile["kind"])
    if sp and (tile["path"] == sp or tile["path"].startswith(sp + "/")):
        from .core import paths
        base = share_dir(get_db(), paths(), tile["kind"])
        sub = tile["path"][len(sp):].strip("/")
        p = (base / sub).resolve() if sub else base
        return p if str(p).startswith(str(base.resolve())) else None
    try:
        _root, p = resolve(owner, tile["path"])
    except Exception:
        return None
    return p


def safe_sub(base: Path, sub: str) -> Path:
    parts = [p for p in (sub or "").replace("\\", "/").split("/") if p not in ("", ".")]
    if any(p == ".." or p == RECYCLE for p in parts):
        abort(400)
    p = base.joinpath(*parts).resolve() if parts else base.resolve()
    try:
        p.relative_to(base.resolve())
    except ValueError:
        abort(403)
    return p


def make_tile_folder(owner, title: str) -> str:
    from .core import home_dir
    name = re.sub(r'[\\/:*?"<>|#\x00]', "", title).strip() or "مربع"
    folder = home_dir(owner["username"]) / TV_DIR / name
    folder.mkdir(parents=True, exist_ok=True)
    return f"/home/{TV_DIR}/{name}"


def norm_tile_path(owner, path: str | None) -> str | None:
    """يقبل مسار المدير (/homes/سارة/...) ويحوّله لمسار صاحب المربع (/home/...)، ويتأكد أن صاحبه يصل إليه."""
    path = (path or "").strip()
    if not path:
        return None
    parts = [p for p in path.replace("\\", "/").split("/") if p]
    if len(parts) >= 2 and parts[0] == "homes" and parts[1].lower() == owner["username"].lower():
        parts = ["home"] + parts[2:]
    path = "/" + "/".join(parts)
    from .vfs import resolve
    try:
        _root, p = resolve(owner, path)
    except Exception:
        abort(400, "هذا المستخدم لا يملك صلاحية على هذا المجلد. اختر مجلداً داخل ملفاته أو مجلداً مشتركاً مسموحاً له.")
    if not p.is_dir():
        abort(400, "المجلد غير موجود")
    return path


def tile_dict(t) -> dict:
    return {k: t[k] for k in ("id", "user_id", "title", "kind", "path", "icon", "color", "position", "enabled")}


# ----------------------------------------------------------------------------- الإدارة (من لوحة التحكم)

def kiosk_helper(*args, timeout=1800) -> tuple[bool, str]:
    if not (APPLIANCE and os.path.exists(HELPER)):
        return False, "not available"
    r = subprocess.run(["sudo", "-n", HELPER, *args], capture_output=True, text=True, timeout=timeout)
    return r.returncode == 0, (r.stdout if r.returncode == 0 else (r.stderr or r.stdout)).strip()


@bp.get("/api/admin/tv")
@admin_required
def api_admin_tv():
    db = get_db()
    users = []
    for u in db.execute("SELECT * FROM users ORDER BY id"):
        tiles = [tile_dict(t) for t in db.execute("SELECT * FROM tv_tiles WHERE user_id=? ORDER BY position, id", (u["id"],))]
        users.append({"id": u["id"], "username": u["username"], "display_name": u["display_name"] or "",
                      "tv_role": u["tv_role"] or "none", "birthdate": u["birthdate"] or "", "avatar": u["avatar"] or 0,
                      "photo_v": u["photo_v"] or 0,
                      "has_pin": bool(u["tv_pin"]), "disabled": bool(u["disabled"]), "tiles": tiles, **age_info(u["birthdate"])})
    kiosk = None
    if APPLIANCE and os.path.exists(HELPER):
        ok, out = kiosk_helper("tv-status", timeout=30)
        try:
            kiosk = json.loads(out) if ok else None
        except ValueError:
            kiosk = None
    return jsonify(settings=tv_settings(), users=users, kiosk=kiosk, available=APPLIANCE and os.path.exists(HELPER),
                   cities=[{"id": k, "name": v[0]} for k, v in prayer.CITIES.items()],
                   methods=[{"id": k, "name": v[0]} for k, v in prayer.METHODS.items()],
                   icons=ICONS, colors=COLORS, prayer=prayer_now(tv_settings()),
                   mawaqit=mawaqit.summary(mawaqit.load(paths().system)),
                   adhan_files=adhan_files())


@bp.post("/api/admin/tv/settings")
@admin_required
def api_admin_tv_settings():
    apply_tv_settings(body())
    log_action("تعديل إعدادات وضع التلفاز")
    return jsonify(ok=True)


def apply_tv_settings(d: dict):
    """حفظ إعدادات التلفاز (من لوحة التحكم، ومن إعدادات التلفاز نفسه منذ البند 72)."""
    for key, sk in (("theme", "tv_theme"), ("wallpaper", "tv_wallpaper"), ("kids_wallpaper", "tv_kids_wallpaper"),
                    ("city", "tv_city"), ("method", "tv_method"), ("night_off", "tv_night_off")):
        if key in d:
            set_setting(sk, str(d[key] or "")[:40])
    for key, sk in (("lat", "tv_lat"), ("lon", "tv_lon")):
        if key in d:
            try:
                set_setting(sk, str(float(d[key])) if str(d[key]).strip() else "")
            except ValueError:
                abort(400, "إحداثيات غير صالحة")
    if d.get("lite") in ("auto", "on", "off"):
        set_setting("tv_lite", d["lite"])
    if d.get("night_dim") in ("auto", "off"):
        set_setting("tv_night_dim", d["night_dim"])
    if d.get("lang") in TV_LANGS:
        set_setting("tv_lang", d["lang"])
    for key, sk in (("hanafi", "tv_hanafi"), ("prayer", "tv_prayer"), ("nosleep", "tv_nosleep")):
        if key in d:
            set_setting(sk, "1" if d[key] else "0")
    for key, sk, lo, hi in (("zoom", "tv_zoom", 70, 130), ("margin", "tv_margin", 0, 8), ("text", "tv_text", 80, 150)):
        if key in d:
            set_setting(sk, str(max(lo, min(hi, int(d[key] or 0)))))
    if "saver_min" in d:
        set_setting("tv_saver_min", str(max(0, min(240, int(d["saver_min"] or 0)))))
    if "pad_sleep" in d:
        set_setting("tv_pad_sleep", str(max(0, min(240, int(d["pad_sleep"] or 0)))))
    if "words" in d:
        set_setting("tv_words", json.dumps([x for x in d["words"] if x in ("ar", "fr", "en")]))
    if "weather" in d:
        set_setting("tv_weather", "1" if d["weather"] else "0")
    if isinstance(d.get("daily_kinds"), list):
        set_setting("tv_daily_kinds", json.dumps([k for k in d["daily_kinds"] if k in welcome.KIND_LABEL]))
    if d.get("saver_kind") in SAVER_KINDS:
        set_setting("tv_saver_kind", d["saver_kind"])
    if "saver_text" in d:
        set_setting("tv_saver_text", str(d["saver_text"] or "").strip()[:160])
    if isinstance(d.get("home_cards"), list):
        set_setting("tv_home_cards", json.dumps([k for k in HOME_CARDS if k in d["home_cards"]]))
    if d.get("source") in ("calc", "mawaqit"):
        set_setting("tv_prayer_source", d["source"])
    if isinstance(d.get("offsets"), dict):
        set_setting("tv_prayer_off", json.dumps({k: max(-60, min(60, int(d["offsets"].get(k) or 0))) for k in PRAYER_KEYS}))
    if isinstance(d.get("adhan"), dict):
        a = d["adhan"]
        set_setting("tv_adhan", json.dumps({
            "on": bool(a.get("on")), "pause": bool(a.get("pause", True)),
            "prayers": [k for k in a.get("prayers") or [] if k in PRAYER_KEYS and k != "sunrise"],
            "volume": max(10, min(100, int(a.get("volume") or 80))), "remind": max(0, min(60, int(a.get("remind") or 0)))}))


@bp.post("/api/admin/tv/mawaqit")
@admin_required
def api_admin_mawaqit():
    """جدول السنة من صفحة المسجد على Mawaqit: من الرابط (إنترنت) أو من ملف الصفحة المحفوظ (بدون إنترنت)."""
    from . import mawaqit
    from .sysadmin import is_offline
    try:
        if request.files.get("page"):
            data = mawaqit.parse(request.files["page"].read(8 * 1024 * 1024).decode("utf-8", "replace"))
            data["url"] = (request.form.get("url") or "").strip()[:300] or None
        else:
            if is_offline():
                abort(400, "وضع «بدون إنترنت» مفعّل. احفظ صفحة المسجد من الكمبيوتر وارفع الملف بدل الرابط.")
            data = mawaqit.fetch(str(body().get("url") or ""))
    except ValueError as e:
        abort(400, str(e))
    except OSError as e:
        abort(400, f"تعذر الوصول إلى Mawaqit (لا إنترنت؟). يمكنك حفظ صفحة المسجد من الكمبيوتر ورفع الملف. ({e})")
    mawaqit.save(paths().system, data)
    set_setting("tv_prayer_source", "mawaqit")
    log_action("مواقيت المسجد من Mawaqit", data.get("name") or "")
    return jsonify(ok=True, mawaqit=mawaqit.summary(data), prayer=prayer_now(tv_settings()))


@bp.delete("/api/admin/tv/mawaqit")
@admin_required
def api_admin_mawaqit_delete():
    from . import mawaqit
    mawaqit.file(paths().system).unlink(missing_ok=True)
    set_setting("tv_prayer_source", "calc")
    return jsonify(ok=True)


@bp.post("/api/admin/tv/adhan/<which>")
@admin_required
def api_admin_adhan_upload(which):
    if which not in ("main", "fajr"):
        abort(404)
    f = request.files.get("file")
    if not f or not (f.filename or "").lower().endswith((".mp3", ".m4a", ".ogg", ".wav")):
        abort(400, "اختر ملف صوت (MP3)")
    data = f.read(30 * 1024 * 1024 + 1)
    if len(data) > 30 * 1024 * 1024:
        abort(400, "الملف كبير جداً (الحد 30 ميغابايت)")
    (adhan_dir() / f"{which}.mp3").write_bytes(data)
    log_action("ملف الأذان", which)
    return jsonify(ok=True, files=adhan_files())


@bp.delete("/api/admin/tv/adhan/<which>")
@admin_required
def api_admin_adhan_delete(which):
    if which not in ("main", "fajr"):
        abort(404)
    (adhan_dir() / f"{which}.mp3").unlink(missing_ok=True)
    return jsonify(ok=True, files=adhan_files())


@bp.post("/api/admin/tv/wall/<who>")
@admin_required
def api_admin_wall_upload(who):
    """صورة خلفية من اختيار الأهل (للبالغين أو للأطفال): تُصغَّر إلى 1920×1080 وتُحفظ JPEG."""
    if who not in WALLS:
        abort(404)
    f = request.files.get("file")
    if not f:
        abort(400, "اختر صورة")
    data = f.read(40 * 1024 * 1024 + 1)
    if len(data) > 40 * 1024 * 1024:
        abort(400, "الملف كبير جداً (الحد 40 ميغابايت)")
    import io
    from PIL import Image, ImageOps
    try:
        im = ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert("RGB")
    except Exception:
        abort(400, "هذه ليست صورة مدعومة (JPG أو PNG)")
    im.thumbnail((1920, 1080))
    tmp = wall_dir() / f".{who}.tmp"
    im.save(tmp, "JPEG", quality=86)
    tmp.replace(wall_dir() / f"{who}.jpg")
    log_action("خلفية التلفاز", who)
    return jsonify(ok=True, walls=wall_versions())


@bp.delete("/api/admin/tv/wall/<who>")
@admin_required
def api_admin_wall_delete(who):
    if who not in WALLS:
        abort(404)
    (wall_dir() / f"{who}.jpg").unlink(missing_ok=True)
    return jsonify(ok=True, walls=wall_versions())


@bp.get("/api/tv/wall/<who>")
def api_tv_wall(who):
    tv_guard()
    f = wall_dir() / f"{who}.jpg"
    if who not in WALLS or not f.exists():
        abort(404)
    return send_file(f, mimetype="image/jpeg", max_age=86400)


@bp.get("/api/tv/adhan/<which>")
def api_tv_adhan(which):
    if not (tv_allowed() or current_user()):
        abort(403)
    f = adhan_dir() / f"{which}.mp3"
    if which not in ("main", "fajr") or not f.exists():
        abort(404)
    return send_file(f, conditional=True, mimetype="audio/mpeg")


@bp.patch("/api/admin/tv/users/<int:uid>")
@admin_required
def api_admin_tv_user(uid):
    u = user_row(uid)
    if not u:
        abort(404)
    d = body()
    db = get_db()
    if "display_name" in d:
        db.execute("UPDATE users SET display_name=? WHERE id=?", ((d["display_name"] or "").strip()[:40] or None, uid))
    if "tv_role" in d:
        if d["tv_role"] not in ROLES:
            abort(400)
        db.execute("UPDATE users SET tv_role=? WHERE id=?", (d["tv_role"], uid))
    if "birthdate" in d:
        b = (d["birthdate"] or "").strip()
        if b:
            try:
                date.fromisoformat(b)
            except ValueError:
                abort(400, "تاريخ الميلاد غير صالح")
        db.execute("UPDATE users SET birthdate=? WHERE id=?", (b or None, uid))
    if "avatar" in d:
        db.execute("UPDATE users SET avatar=? WHERE id=?", (int(d["avatar"]) % 12, uid))
    if "pin" in d:
        pin = str(d["pin"] or "").strip()
        if pin and not re.fullmatch(r"\d{4,8}", pin):
            abort(400, "الرمز يجب أن يكون من 4 إلى 8 أرقام")
        db.execute("UPDATE users SET tv_pin=? WHERE id=?", (generate_password_hash(pin) if pin else None, uid))
    db.commit()
    return jsonify(ok=True)


@bp.post("/api/admin/tv/users/<int:uid>/tiles")
@admin_required
def api_admin_tile_create(uid):
    u = user_row(uid)
    if not u:
        abort(404)
    d = body()
    title = (d.get("title") or "").strip()[:40]
    kind = d.get("kind") or "media"
    if not title or kind not in KINDS:
        abort(400, "اكتب اسماً للمربع")
    raw = (d.get("path") or "").strip()
    if kind in APP_KINDS and (not raw or raw in (SHARE_PATH[kind], "/shares" + SHARE_PATH[kind])):
        path = SHARE_PATH[kind]   # المجلد المشترك لكل العائلة
    else:
        path = norm_tile_path(u, raw) if kind not in NOFOLDER else None
    if kind not in NOFOLDER and not path:
        path = make_tile_folder(u, title)
    db = get_db()
    pos = db.execute("SELECT COALESCE(MAX(position),-1)+1 FROM tv_tiles WHERE user_id=?", (uid,)).fetchone()[0]
    cur = db.execute("INSERT INTO tv_tiles(user_id, title, kind, path, icon, color, position, created_at) VALUES (?,?,?,?,?,?,?,?)",
                     (uid, title, kind, path, d.get("icon") or {"photos": "photos", "cameras": "camera", "learn": "letters"}.get(kind, "star"),
                      d.get("color") or COLORS[pos % len(COLORS)], pos, now_iso()))
    db.commit()
    log_action("إضافة مربع للتلفاز", f"{display_name(u)}: {title}")
    return jsonify(ok=True, id=cur.lastrowid, path=path)


@bp.post("/api/admin/tv/users/<int:uid>/defaults")
@admin_required
def api_admin_tile_defaults(uid):
    u = user_row(uid)
    if not u:
        abort(404)
    role = body().get("role") or u["tv_role"]
    if role not in DEFAULT_TILES:
        abort(400, "اختر نوع الملف أولاً")
    db = get_db()
    have = {r["title"] for r in db.execute("SELECT title FROM tv_tiles WHERE user_id=?", (uid,))}
    pos = db.execute("SELECT COALESCE(MAX(position),-1)+1 FROM tv_tiles WHERE user_id=?", (uid,)).fetchone()[0]
    added = 0
    for title, kind, icon, color in DEFAULT_TILES[role]:
        if title in have:
            continue
        path = None if kind in NOFOLDER else SHARE_PATH[kind] if kind in APP_KINDS else make_tile_folder(u, title)
        db.execute("INSERT INTO tv_tiles(user_id, title, kind, path, icon, color, position, created_at) VALUES (?,?,?,?,?,?,?,?)",
                   (uid, title, kind, path, icon, COLORS[color % len(COLORS)], pos, now_iso()))
        pos += 1
        added += 1
    db.commit()
    return jsonify(ok=True, added=added)


@bp.patch("/api/admin/tv/tiles/<int:tid>")
@admin_required
def api_admin_tile_update(tid):
    db = get_db()
    t = db.execute("SELECT * FROM tv_tiles WHERE id=?", (tid,)).fetchone()
    if not t:
        abort(404)
    d = body()
    if "title" in d and (d["title"] or "").strip():
        db.execute("UPDATE tv_tiles SET title=? WHERE id=?", (d["title"].strip()[:40], tid))
    for k in ("icon", "color"):
        if k in d:
            db.execute(f"UPDATE tv_tiles SET {k}=? WHERE id=?", ((d[k] or "").strip() or None, tid))
    if "path" in d and t["kind"] not in NOFOLDER:
        owner = user_row(t["user_id"])
        if t["kind"] in APP_KINDS and (d["path"] or "").strip() in ("", SHARE_PATH[t["kind"]], "/shares" + SHARE_PATH[t["kind"]]):
            path = SHARE_PATH[t["kind"]]
        else:
            path = norm_tile_path(owner, d["path"]) or make_tile_folder(owner, d.get("title") or t["title"])
        db.execute("UPDATE tv_tiles SET path=? WHERE id=?", (path, tid))
    if "enabled" in d:
        db.execute("UPDATE tv_tiles SET enabled=? WHERE id=?", (int(bool(d["enabled"])), tid))
    if "move" in d:
        sib = db.execute("SELECT id, position FROM tv_tiles WHERE user_id=? ORDER BY position, id", (t["user_id"],)).fetchall()
        ids = [r["id"] for r in sib]
        i = ids.index(tid)
        j = i + (1 if d["move"] > 0 else -1)
        if 0 <= j < len(ids):
            ids[i], ids[j] = ids[j], ids[i]
        for n, x in enumerate(ids):
            db.execute("UPDATE tv_tiles SET position=? WHERE id=?", (n, x))
    db.commit()
    return jsonify(ok=True)


@bp.delete("/api/admin/tv/tiles/<int:tid>")
@admin_required
def api_admin_tile_delete(tid):
    db = get_db()
    db.execute("DELETE FROM tv_tiles WHERE id=?", (tid,))
    db.commit()
    return jsonify(ok=True)


# ----------------------------------------------------------------------------- الألعاب والتعليم
def _apps_in(d: Path) -> list[dict]:
    out = []
    try:
        entries = sorted(d.iterdir(), key=lambda x: x.name.casefold())
    except OSError:
        return out
    for x in entries:
        if not x.is_dir() or x.name.startswith((".", "#", "@")) or x.name == RECYCLE:
            continue
        sub = _only_sub(x)
        is_app = (x / "index.html").is_file() or bool(sub and (sub[0] / "index.html").is_file())
        out.append({"name": x.name, "app": is_app, "declared": app_type(x)})
    return out


@bp.get("/api/admin/tv/apps")
@admin_required
def api_admin_apps():
    """محتوى المجلدين «الألعاب» و«التعليم»، مع النوع المكتوب في app.json لكل تطبيق (إن وُجد)."""
    db = get_db()
    return jsonify(games=_apps_in(share_dir(db, paths(), "games")), learn=_apps_in(share_dir(db, paths(), "learn")),
                   names={k: v[0] for k, v in SHARES.items()})


# ----------------------------------------------------------------------------- البند 53: الألعاب المكررة
def _app_copies(db) -> dict:
    """كل نسخ التطبيقات في «الألعاب» و«التعليم»: مباشرة، أو داخل مجلد ZIP (مثل «الألعاب-22/…»)، أو داخل مجلد يغلّفها.
    الاسم دائماً اسم مجلد التطبيق نفسه (الذي فيه index.html). يرجع {الاسم: [{"unit": ما يُنقل إلى السلة، "kind"، "share"،
    "rank": 2 مباشرة في المجلد المشترك، 1 مغلّفة بمجلد وحدها، 0 داخل مجلد آخر، "app": مجلد التطبيق}]}."""
    out: dict = {}
    def entries(d: Path) -> list[Path]:
        try:
            return sorted((x for x in d.iterdir() if not x.name.startswith((".", "#", "@")) and x.name != RECYCLE), key=lambda x: x.name.casefold())
        except OSError:
            return []
    def scan(d: Path, kind: str, root: Path, rank: int, depth: int):
        if (d / "index.html").is_file():
            out.setdefault(d.name, []).append({"unit": d, "kind": kind, "share": root, "rank": rank, "app": d})
            return
        if depth >= 2:
            return
        inner = entries(d)
        subs = [x for x in inner if x.is_dir()]
        if len(subs) == 1 and (subs[0] / "index.html").is_file():   # مجلد يغلّف تطبيقاً واحداً (بعد فك ZIP)
            alone = len(inner) == 1
            out.setdefault(subs[0].name, []).append({"unit": d if alone else subs[0], "kind": kind, "share": root,
                                                     "rank": 1 if alone and rank == 2 else 0, "app": subs[0]})
            return
        for x in subs:
            scan(x, kind, root, 0, depth + 1)
    for kind in ("games", "learn"):
        root = share_dir(db, paths(), kind)
        for t in entries(root):
            if t.is_dir():
                scan(t, kind, root, 2, 0)
    return out


def _dupes(db) -> list[dict]:
    """لكل تطبيق له أكثر من نسخة: أي نسخة نُبقي، وأيها تُنقل إلى سلة المحذوفات.
    نُبقي النسخة المباشرة في المجلد الذي يقوله نوعها (حيث يضع النظام ألعابه)، ثم أي نسخة مباشرة، ثم الأحدث."""
    def score(c):
        declared = app_type(c["app"]) or app_type(c["unit"])
        right = (declared == "education") == (c["kind"] == "learn") if declared else c["kind"] == "games"
        try:
            mtime = (c["app"] / "index.html").stat().st_mtime
        except OSError:
            mtime = 0
        return (c["rank"] == 2 and right, c["rank"], right, mtime)
    out = []
    for name, copies in sorted(_app_copies(db).items(), key=lambda x: x[0].casefold()):
        if len(copies) < 2:
            continue
        copies = sorted(copies, key=score, reverse=True)
        rel = lambda c: f"{SHARES[c['kind']][0]}/{c['unit'].relative_to(c['share']).as_posix()}"
        out.append({"name": name, "keep": rel(copies[0]), "remove": [rel(c) for c in copies[1:]], "_remove": copies[1:]})
    return out


@bp.get("/api/admin/tv/apps/dupes")
@admin_required
def api_admin_apps_dupes():
    return jsonify(dupes=[{k: v for k, v in d.items() if not k.startswith("_")} for d in _dupes(get_db())])


@bp.post("/api/admin/tv/apps/dupes")
@admin_required
def api_admin_apps_dupes_apply():
    """ينقل النسخ المكررة إلى سلة المحذوفات في مجلدها المشترك (تُسترجع خلال مدة السلة). تقدّم الأطفال يتبع اللعبة باسمها."""
    from .bundled import _to_recycle
    moved, emptied = [], []
    for d in _dupes(get_db()):
        for c in d["_remove"]:
            parent = c["unit"].parent
            try:
                _to_recycle(c["share"], c["unit"])
                moved.append(f"{SHARES[c['kind']][0]}/{c['unit'].relative_to(c['share']).as_posix()}")
            except OSError:
                continue
            if parent != c["share"]:   # مجلد ZIP صار فارغاً: لا داعي لبقائه
                try:
                    if not any(parent.iterdir()):
                        parent.rmdir()
                        emptied.append(parent.name)
                except OSError:
                    pass
    if moved:
        log_action("إزالة الألعاب المكررة", f"{len(moved)} نسخة إلى سلة المحذوفات")
    return jsonify(ok=True, moved=moved, emptied=emptied, apps=api_admin_apps().get_json())


@bp.post("/api/admin/tv/apps/move")
@admin_required
def api_admin_apps_move():
    """نقل تطبيق بين «الألعاب» و«التعليم» (ويُكتب نوعه في app.json). تقدّم الأطفال يبقى كما هو."""
    d = body()
    name, to = str(d.get("name") or ""), d.get("to")
    if to not in SHARES or not name or "/" in name or "\\" in name or name in (".", "..") or name.startswith("."):
        abort(400)
    db = get_db()
    src_kind = "games" if to == "learn" else "learn"
    src = share_dir(db, paths(), src_kind) / name
    dst = share_dir(db, paths(), to) / name
    if not src.is_dir():
        abort(404, "التطبيق غير موجود")
    if dst.exists():
        abort(400, f"يوجد تطبيق بالاسم نفسه في «{SHARES[to][0]}»")
    src.rename(dst)
    set_app_type(dst, "education" if to == "learn" else "game")
    log_action("نقل تطبيق", f"{name} → {SHARES[to][0]}")
    return api_admin_apps()


# ----------------------------------------------------------------------------- البند 28: إضافة تطبيق من الكمبيوتر
APP_BAD = set('\\:*?"<>|')


def _safe_rel(name: str) -> Path | None:
    """مسار نسبي آمن داخل التطبيق (لا .. ولا مسار مطلق ولا ملفات مخفية للنظام)."""
    name = name.replace("\\", "/").lstrip("/")
    parts = [x for x in name.split("/") if x not in ("", ".")]
    if not parts or any(x == ".." or any(c in APP_BAD for c in x) or x.startswith("__MACOSX") for x in parts):
        return None
    return Path(*parts)


def _app_root(d: Path) -> Path | None:
    """المجلد الذي فيه index.html (التطبيق نفسه أو مجلد وحيد داخله)."""
    if (d / "index.html").is_file():
        return d
    subs = _only_sub(d)
    if subs and (subs[0] / "index.html").is_file():
        return subs[0]
    return None


@bp.post("/api/admin/tv/apps/upload")
@admin_required
def api_admin_apps_upload():
    """يرفع تطبيقاً (لعبة أو درساً) إلى «الألعاب» أو «التعليم»: ملف ZIP، أو مجلد كامل من الكمبيوتر.
    التطبيق صفحة ويب تعمل بلا إنترنت: مجلد فيه index.html."""
    import tempfile
    import zipfile
    to = request.form.get("to")
    if to not in SHARES:
        abort(400)
    files = request.files.getlist("files")
    rels = request.form.getlist("paths")
    if not files:
        abort(400, "اختر ملف ZIP أو مجلد التطبيق")
    db = get_db()
    dest_root = share_dir(db, paths(), to)
    work = Path(tempfile.mkdtemp(dir=paths().tmp))
    try:
        name = (request.form.get("name") or "").strip()
        if len(files) == 1 and files[0].filename.lower().endswith(".zip"):
            z = work / "app.zip"
            files[0].save(z)
            name = name or Path(files[0].filename).stem
            try:
                with zipfile.ZipFile(z) as zf:
                    total = 0
                    for info in zf.infolist():
                        rel = _safe_rel(info.filename)
                        if rel is None or info.is_dir():
                            continue
                        total += info.file_size
                        if total > 4 * 1024 ** 3:
                            abort(400, "التطبيق أكبر من 4 GB")
                        out = work / "x" / rel
                        out.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(info) as src, open(out, "wb") as dst:
                            shutil.copyfileobj(src, dst)
            except zipfile.BadZipFile:
                abort(400, "ملف ZIP تالف")
        else:   # مجلد كامل (المتصفح يرسل كل ملف مع مساره)
            for i, f in enumerate(files):
                rel = _safe_rel(rels[i] if i < len(rels) else f.filename)
                if rel is None:
                    continue
                if not name and len(rel.parts) > 1:
                    name = rel.parts[0]
                out = work / "x" / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                f.save(out)
        app = _app_root(work / "x") if (work / "x").is_dir() else None
        if app is None:
            abort(400, "لم نجد index.html في التطبيق. التطبيق المتوافق صفحة ويب: مجلد فيه index.html يعمل بلا إنترنت.")
        name = "".join("_" if c in APP_BAD or c == "/" else c for c in (name or app.name)).strip(" .")[:60] or "تطبيق"
        dst = dest_root / name
        if dst.exists():
            if request.form.get("replace") != "1":
                abort(409, f"يوجد تطبيق باسم «{name}». اختر «استبدال» أو غيّر الاسم.")
            shutil.rmtree(dst)
        shutil.move(str(app), str(dst))
        set_app_type(dst, "education" if to == "learn" else "game")
    finally:
        shutil.rmtree(work, ignore_errors=True)
    log_action("إضافة تطبيق", f"{name} → {SHARES[to][0]}")
    return api_admin_apps()


@bp.post("/api/admin/tv/kiosk")
@admin_required
def api_admin_kiosk():
    action = body().get("action")
    if action not in ("setup", "enable", "disable", "restart"):
        abort(400)
    ok, out = kiosk_helper("tv-" + action, timeout=3600)
    if not ok:
        abort(400, out or "error")
    log_action("وضع التلفاز على الشاشة", action)
    return jsonify(ok=True)


@bp.get("/api/admin/tv/display")
@admin_required
def api_admin_tv_display():
    ok, out = kiosk_helper("tv-modes", timeout=60)
    if not ok:
        return jsonify(error=out)
    return jsonify(json.loads(out))


@bp.post("/api/admin/tv/display")
@admin_required
def api_admin_tv_display_set():
    d = body()
    mode, screen = str(d.get("mode") or ""), str(d.get("screen") or "")
    if mode and not re.fullmatch(r"\d{3,4}x\d{3,4}", mode):
        abort(400)
    if screen and not re.fullmatch(r"[A-Za-z0-9_.-]{1,40}", screen):
        abort(400)
    ok, out = kiosk_helper("tv-mode-set", mode, screen, timeout=900) if screen else \
        kiosk_helper("tv-mode-set", *([mode] if mode else []), timeout=900)
    if not ok:
        abort(400, out or "error")
    return jsonify(ok=True)


CEC_STATUS = Path("/run/homenas/cec.json")


@bp.get("/api/admin/tv/cec")
@admin_required
def api_admin_tv_cec():
    """v1.9.7 (البند 5): حالة ريموت التلفاز عبر HDMI-CEC، كما تكتبها خدمة hsef-cec."""
    if os.environ.get("HSEF_EXTRAS_FAKE") == "1" and not CEC_STATUS.exists():
        return jsonify(supported=os.environ.get("FAKE_CEC", "0") == "1", enabled=True, adapter="Pulse-Eight USB-CEC Adapter",
                       connected=os.environ.get("FAKE_CEC", "0") == "1", tv="LG TV", last_key="01", last_at="20:15:02",
                       power_ignored=2, reason="" if os.environ.get("FAKE_CEC") == "1" else "no-adapter", service=True)
    try:
        d = json.loads(CEC_STATUS.read_text())
        d["service"] = True
    except (OSError, ValueError):
        d = {"supported": False, "service": False, "reason": "no-service"}
    return jsonify(d)


@bp.post("/api/admin/tv/cec")
@admin_required
def api_admin_tv_cec_set():
    on = bool(body().get("enabled"))
    ok, out = kiosk_helper("cec-set", "on" if on else "off", timeout=40)
    if not ok:
        abort(400, out or "error")
    log_action("ريموت التلفاز (HDMI-CEC)", "تشغيل" if on else "إيقاف")
    return jsonify(ok=True)


@bp.post("/api/admin/tv/screen")
@admin_required
def api_admin_tv_screen():
    """v1.9.7: اختيار الشاشة التي يظهر عليها وضع التلفاز. {name: "HDMI-A-2" | "auto", try: true} — التجربة 20 ثانية."""
    d = body()
    name = str(d.get("name") or "auto")
    if name != "auto" and not re.fullmatch(r"[A-Za-z0-9_.-]{1,40}", name):
        abort(400)
    ok, out = kiosk_helper("tv-screen-set", name, *(["20"] if d.get("try") else []), timeout=30)
    if not ok:
        abort(400, out or "error")
    if not d.get("try"):
        log_action("شاشة التلفاز", "تلقائي" if name == "auto" else name)
    return jsonify(ok=True)


# البند 11: نفس اختيار الشاشة والدقة من إعدادات التلفاز نفسه (للمدير على التلفاز)
@bp.get("/api/tv/admin/display")
def api_tv_admin_display():
    tv_admin()
    ok, out = kiosk_helper("tv-modes", timeout=60)
    return jsonify(json.loads(out)) if ok else jsonify(error=out)


@bp.post("/api/tv/admin/display")
def api_tv_admin_display_set():
    u = tv_admin()
    d = body()
    mode, screen = str(d.get("mode") or ""), str(d.get("screen") or "")
    if mode and not re.fullmatch(r"\d{3,4}x\d{3,4}", mode):
        abort(400)
    if screen and not re.fullmatch(r"[A-Za-z0-9_.-]{1,40}", screen):
        abort(400)
    ok, out = kiosk_helper("tv-mode-set", mode, screen, timeout=900) if screen else \
        kiosk_helper("tv-mode-set", *([mode] if mode else []), timeout=900)
    if not ok:
        abort(400, out or "error")
    log_action("دقة شاشة التلفاز (من التلفاز)", f"{screen or ''} {mode or 'تلقائي'}".strip(), u["username"])
    return jsonify(ok=True)


@bp.post("/api/tv/admin/screen")
def api_tv_admin_screen():
    u = tv_admin()
    d = body()
    name = str(d.get("name") or "auto")
    if name != "auto" and not re.fullmatch(r"[A-Za-z0-9_.-]{1,40}", name):
        abort(400)
    ok, out = kiosk_helper("tv-screen-set", name, *(["20"] if d.get("try") else []), timeout=30)
    if not ok:
        abort(400, out or "error")
    if not d.get("try"):
        log_action("شاشة التلفاز (من التلفاز)", "تلقائي" if name == "auto" else name, u["username"])
    return jsonify(ok=True)


@bp.get("/api/admin/tv/audio")
@admin_required
def api_admin_tv_audio():
    ok, out = kiosk_helper("tv-audio-status", timeout=300)
    if not ok:
        return jsonify(error=out)
    return jsonify(json.loads(out))


@bp.post("/api/admin/tv/audio")
@admin_required
def api_admin_tv_audio_set():
    d = body()
    if d.get("action") == "test":
        ok, out = kiosk_helper("tv-audio-test", timeout=60)
    else:
        ok, out = audio_set(d)
    if not ok:
        abort(400, out or "error")
    return jsonify(ok=True)


def audio_set(d) -> tuple[bool, str]:
    if d.get("action") == "auto":
        return kiosk_helper("tv-audio-set", "auto", "auto", timeout=60)
    card, prof = str(d.get("card") or ""), str(d.get("profile") or "")
    if not re.fullmatch(r"[\w.:+-]{1,200}", card) or not re.fullmatch(r"[\w.:+-]{1,200}", prof):
        abort(400)
    return kiosk_helper("tv-audio-set", card, prof, timeout=60)


# ----------------------------------------------------------------------------- واجهة التلفاز

def tv_allowed() -> bool:
    """التلفاز نفسه (متصفح على نفس الجهاز)، أو مدير مسجّل يعاين من كمبيوتره."""
    if request.remote_addr in ("127.0.0.1", "::1"):
        return True
    u = current_user()
    return bool(u and u["is_admin"])


def tv_guard():
    if not tv_allowed():
        abort(403, "واجهة التلفاز تعمل على الشاشة الموصولة بالسيرفر")


def tv_user():
    tv_guard()
    uid = session.get("tv_uid")
    u = user_row(uid) if uid else None
    if not u or u["disabled"] or (u["tv_role"] or "none") == "none":
        abort(401, "اختر المستخدم")
    return u


def profile_dict(u) -> dict:
    return {"id": u["id"], "name": display_name(u), "role": u["tv_role"], "avatar": u["avatar"] or 0,
            "photo_v": u["photo_v"] or 0, "has_pin": bool(u["tv_pin"]), "admin": bool(u["is_admin"]),
            "theme": (u["theme"] if "theme" in u.keys() else None) or "grape",
            **age_info(u["birthdate"])}


@bp.get("/tv")
def tv_page():
    if not tv_allowed():
        return render_template("tv_denied.html"), 403
    from . import __version__
    from .system import server_name
    local = request.remote_addr in ("127.0.0.1", "::1")
    return render_template("tv.html", server_name=server_name(), version=__version__, preview=not local, tv_lang=tv_lang())


@bp.get("/api/tv/profiles")
def api_tv_profiles():
    tv_guard()
    db = get_db()
    order = {"adult": 0, "kid": 1, "little": 2}
    rows = [u for u in db.execute("SELECT * FROM users WHERE disabled=0") if (u["tv_role"] or "none") != "none"]
    rows.sort(key=lambda u: (order.get(u["tv_role"], 9), u["id"]))
    setup = None
    if not db.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        from flask import current_app
        from .system import server_urls
        setup = {"urls": server_urls(current_app.config["NAS_CFG"].get("port", 80))}
    from .activation import status as act_status
    act = act_status(db)
    if setup is not None:   # شاشة الإعداد الأول: رقم الجهاز ورمز واتساب للتفعيل
        setup.update(device=act["display"], whatsapp=act["whatsapp"], seller=act["seller"], trial_days=act["trial_days"])
    from .stars import balance
    profiles = [profile_dict(u) | {"stars": balance(db, u["id"])} for u in rows]
    weather_now(tv_settings())  # يبدأ جلب الطقس في الخلفية
    db.commit()
    notice = None   # تنبيه صغير على شاشة «من يشاهد؟»: قبل الانتهاء بـ7 أيام، وبعده
    if setup is None and (act["state"] == "expired" or (act["warn"] and (act["days_left"] or 99) <= 7)):
        notice = {"state": act["state"], "days_left": act["days_left"], "was": act.get("was")}
    return jsonify(profiles=profiles, settings=tv_settings(), current=session.get("tv_uid"), setup=setup, activation=notice)


@bp.post("/api/tv/login")
def api_tv_login():
    tv_guard()
    d = body()
    u = user_row(int(d.get("id") or 0))
    if not u or u["disabled"] or (u["tv_role"] or "none") == "none":
        abort(404)
    # الرمز عند الدخول فقط (لمن له رمز)، والخروج حر للجميع
    if u["tv_pin"] and not check_password_hash(u["tv_pin"], str(d.get("pin") or "")):
        abort(403, "الرمز غير صحيح")
    session["tv_uid"] = u["id"]
    from . import welcome
    session["tv_daily"] = welcome.daily(u)  # كلمة ونص جديدان مع كل دخول
    return jsonify(ok=True)


@bp.post("/api/tv/leave")
def api_tv_leave():
    """العودة إلى شاشة اختيار المستخدم (بلا رمز، حتى للأطفال)."""
    tv_guard()
    session.pop("tv_uid", None)
    return jsonify(ok=True)


@bp.get("/api/tv/home")
def api_tv_home():
    u = tv_user()
    db = get_db()
    tiles = [tile_dict(t) for t in db.execute("SELECT * FROM tv_tiles WHERE user_id=? AND enabled=1 ORDER BY position, id",
                                              (u["id"],))]
    # الكاميرات تظهر وحدها للمدير ولمن يختارهم (بلا حاجة لإضافة مربع)، متى وُجدت كاميرا
    if not any(t["kind"] == "cameras" for t in tiles):
        from .cameras import viewers
        if (u["is_admin"] or u["id"] in viewers()) and db.execute("SELECT 1 FROM cameras WHERE enabled=1 LIMIT 1").fetchone():
            tiles.append({"id": "cams", "user_id": u["id"], "title": "الكاميرات", "kind": "cameras", "path": None,
                          "icon": "camera", "color": "#0f172a,#2563eb", "position": 999, "enabled": 1})
    from .kids import extra_tiles   # مهامي، رمضان، قصص بصوتنا، في مثل هذا اليوم
    tiles += extra_tiles(db, u)
    s = tv_settings()
    from . import welcome
    daily = session.get("tv_daily")
    if not daily:
        daily = session["tv_daily"] = welcome.daily(u)
    cards = s["home_cards"]
    return jsonify(user=profile_dict(u), tiles=tiles, settings=s, prayer=prayer_now(s), word=daily["word"],
                   text=daily.get("text") if s["daily_kinds"] else None, weather=weather_now(s),
                   family=home_family(db) if "family" in cards else None,
                   memory=home_memory(db, u) if "memory" in cards else None)


THEMES = ("grape", "apple", "orange", "strawberry", "lemon", "watermelon")


@bp.post("/api/tv/theme")
def api_tv_theme():
    """كل شخص يختار ثيم الفاكهة الذي يحبه."""
    u = tv_user()
    t = str(body().get("theme") or "")
    if t not in THEMES:
        abort(400)
    db = get_db()
    db.execute("UPDATE users SET theme=? WHERE id=?", (t, u["id"]))
    db.commit()
    return jsonify(ok=True, theme=t)


TV_LANGS = ("ar", "en", "fr", "tr", "nl")


def tv_lang() -> str:
    v = get_setting("tv_lang", "ar")
    return v if v in TV_LANGS else "ar"


PAD_KEYS = {"a", "b", "x", "y", "l1", "r1", "l2", "r2", "select", "start", "ls", "rs", "up", "down", "left", "right", "home"}


@bp.get("/api/tv/padmaps")
def api_tv_padmaps():
    """ترتيب أزرار الأيادي العامة (بلا ماركة) كما ضبطه «إعداد يد جديدة»."""
    tv_guard()
    try:
        maps = json.loads(get_setting("tv_padmaps") or "{}")
    except ValueError:
        maps = {}
    return jsonify(maps=maps if isinstance(maps, dict) else {})


@bp.post("/api/tv/padmaps")
def api_tv_padmaps_set():
    tv_guard()
    d = body()
    pid = str(d.get("id") or "").strip()[:200]
    if not pid:
        abort(400)
    try:
        maps = json.loads(get_setting("tv_padmaps") or "{}")
    except ValueError:
        maps = {}
    m = d.get("map")
    if m is None:
        maps.pop(pid, None)
    elif isinstance(m, dict):
        clean = {}
        for k, c in m.items():
            if k in PAD_KEYS and isinstance(c, dict) and c.get("t") in ("b", "a"):
                i = int(c.get("i") or 0)
                if 0 <= i < 64:
                    clean[k] = {"t": c["t"], "i": i} | ({"s": 1 if int(c.get("s") or 1) > 0 else -1} if c["t"] == "a" else {})
        if not {"a", "b"} <= clean.keys():
            abort(400, "ناقص: زر الموافقة وزر الرجوع")
        maps[pid] = clean
        while len(maps) > 30:
            maps.pop(next(iter(maps)))
    set_setting("tv_padmaps", json.dumps(maps))
    return jsonify(maps=maps)


@bp.get("/api/tv/settings")
def api_tv_settings():
    """التلفاز يسأل كل دقيقة: إن تغيّرت الإعدادات من لوحة التحكم تُطبَّق بلا إعادة تحميل."""
    tv_guard()
    return jsonify(settings=tv_settings())


@bp.get("/api/tv/clock")
def api_tv_clock():
    tv_guard()
    s = tv_settings()
    return jsonify(prayer=prayer_now(s), now=datetime.now().isoformat(timespec="seconds"),
                   adhan=s["adhan"] | {"files": adhan_files()}, weather=weather_now(s))


def my_tile(tid: int):
    u = tv_user()
    t = get_db().execute("SELECT * FROM tv_tiles WHERE id=? AND user_id=? AND enabled=1", (tid, u["id"])).fetchone()
    if not t:
        abort(404)
    return u, t


@bp.get("/api/tv/tile/<int:tid>/list")
def api_tv_tile_list(tid):
    u, t = my_tile(tid)
    if t["kind"] in NOFOLDER:
        abort(400)
    base = tile_folder(u, t)
    if base is None or not base.is_dir():
        return jsonify(tile=tile_dict(t), items=[], missing=True)
    folder = safe_sub(base, request.args.get("sub", ""))
    items = []
    covers = ("cover.jpg", "cover.png", "cover.jpeg", "icon.png", "folder.jpg")

    def game_entry(d: Path) -> str | None:
        """مسار اللعبة داخل المجلد: index.html فيه مباشرة، أو في مجلد وحيد بداخله (بعد فك الضغط)."""
        if (d / "index.html").is_file():
            return ""
        try:
            subs = [x for x in d.iterdir() if x.is_dir() and not x.name.startswith((".", "@")) and x.name != RECYCLE]
        except OSError:
            return None
        if len(subs) == 1 and (subs[0] / "index.html").is_file():
            return subs[0].name
        return None

    # ملفات لعبة موضوعة مباشرة في هذا المجلد
    if (folder / "index.html").is_file():
        items.append({"name": "", "type": "game", "self": True, "entry": "",
                      "cover": next((c for c in covers if (folder / c).is_file()), None)})
    with os.scandir(folder) as it:
        for e in it:
            if e.name.startswith((".", "@")) or e.name == RECYCLE:
                continue
            if e.is_dir():
                entry = game_entry(Path(e.path))
                gdir = Path(e.path) / entry if entry else Path(e.path)
                cover = next((c for c in covers if (gdir / c).is_file()), None)
                if entry is not None:
                    items.append({"name": e.name, "type": "game", "entry": entry,
                                  "cover": f"{entry}/{cover}" if (entry and cover) else cover})
                else:
                    items.append({"name": e.name, "type": "folder", "cover": cover})
            else:
                if items and items[0].get("self") and e.name in covers:
                    continue
                k = file_kind(e.name)
                if k:
                    items.append({"name": e.name, "type": k, "size": e.stat().st_size})
    items.sort(key=lambda x: (not x.get("self"), x["type"] not in ("folder", "game"), x["name"].casefold()))
    _tvv().used()
    vids = [folder / x["name"] for x in items if x["type"] == "video"]
    if vids:
        import threading
        threading.Thread(target=_tvv().prefetch, args=(vids,), daemon=True).start()
    return jsonify(tile=tile_dict(t), items=items, sub=request.args.get("sub", ""))


def tile_file(tid) -> Path:
    u, t = my_tile(tid)
    base = tile_folder(u, t)
    if base is None:
        abort(404)
    p = safe_sub(base, request.args.get("p", ""))
    if not p.is_file() or not file_kind(p.name) and p.suffix.lower() not in (".jpg", ".png", ".jpeg"):
        abort(404)
    return p


@bp.get("/api/tv/tile/<int:tid>/file")
def api_tv_tile_file(tid):
    p = tile_file(tid)
    _tvv().used()
    if file_kind(p.name) == "image" and p.suffix.lower() not in BROWSER_IMAGE_EXT:
        from .files import thumb_response  # صور الآيفون HEIC وغيرها: JPEG يعرضه التلفاز
        return thumb_response(p, True)
    return send_file(p, conditional=True, mimetype=mimetypes.guess_type(p.name)[0])


# ----------------------------------------------------------------------------- فيديو الآيفون وغيره: تحويل لصيغة يشغّلها التلفاز
def _tvv():
    from . import tvvideo
    return tvvideo.get(paths().cache)


def prep_sources(data_paths) -> list[Path]:
    """كل فيديوهات التلفاز: مجلدات مربعات الوسائط لكل الملفات، وفيديوهات «صوري» لمن له ملف على التلفاز."""
    from .core import connect
    out: list[Path] = []
    db = connect(data_paths.db)
    try:
        dirs = []
        for t in db.execute("SELECT t.path, u.username FROM tv_tiles t JOIN users u ON u.id=t.user_id "
                            "WHERE t.kind='media' AND t.enabled=1 AND u.disabled=0 AND t.path IS NOT NULL"):
            parts = [x for x in t["path"].split("/") if x and x != ".."]
            if not parts:
                continue
            if parts[0] == "home":
                base = data_paths.homes / t["username"]
            else:
                row = db.execute("SELECT path FROM folders WHERE name=?", (parts[0],)).fetchone()
                if not row:
                    continue
                base = Path(row["path"])
            d = base.joinpath(*parts[1:])
            if d.is_dir() and d not in dirs:
                dirs.append(d)
        for d in dirs:
            for r, ds, fs in os.walk(d):
                ds[:] = sorted(x for x in ds if not x.startswith((".", "#")))
                out += [Path(r) / f for f in sorted(fs) if file_kind(f) == "video"]
        for r in db.execute("SELECT m.rel_path, u.username FROM media m JOIN users u ON m.library='u:' || u.id "
                            "WHERE m.is_video=1 AND u.disabled=0 AND COALESCE(u.tv_role,'none')!='none' ORDER BY m.id DESC"):
            out.append(data_paths.homes / r["username"] / "Photos" / r["rel_path"])
        # البند 21: «كل الفيديو»: كل الملفات الشخصية وكل المجلدات المشتركة، لا مربعات التلفاز فقط
        row = db.execute("SELECT value FROM settings WHERE key='tv_prep_scope'").fetchone()
        if row and row["value"] == "all":
            roots = [data_paths.homes] + [Path(r["path"]) for r in db.execute("SELECT path FROM folders WHERE name<>'الكاميرات'")]
            seen = set(map(str, out))
            for d in roots:
                if not d.is_dir():
                    continue
                for r, ds, fs in os.walk(d):
                    ds[:] = sorted(x for x in ds if not x.startswith((".", "#", "@")))
                    for f in sorted(fs):
                        fp = Path(r) / f
                        if file_kind(f) == "video" and str(fp) not in seen:
                            seen.add(str(fp))
                            out.append(fp)
    finally:
        db.close()
    return out


def start_tv_prep(data_paths):
    """يبدأ «تجهيز الفيديو للتلفاز» في الخلفية (عند تشغيل السيرفر)."""
    from . import tvvideo
    from .core import connect

    def settings():
        db = connect(data_paths.db)
        try:
            g = lambda k, d: (db.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone() or {"value": d})["value"]
            return {"mode": g("tv_prep_mode", "idle"), "max_gb": float(g("tv_prep_max_gb", 0) or 0)}
        finally:
            db.close()
    tvvideo.get(data_paths.cache).start_prep(lambda: prep_sources(data_paths), settings)


@bp.get("/api/admin/tv/prep")
@admin_required
def api_admin_tv_prep():
    from .tvvideo import FFMPEG
    return jsonify(available=bool(FFMPEG), mode=get_setting("tv_prep_mode") or "idle", scope=get_setting("tv_prep_scope") or "tv",
                   max_gb=float(get_setting("tv_prep_max_gb") or 0), replace=_replace_job, **_tvv().prep_status())


@bp.post("/api/admin/tv/prep")
@admin_required
def api_admin_tv_prep_set():
    d = body()
    v = _tvv()
    if d.get("mode") in ("idle", "night", "off"):
        set_setting("tv_prep_mode", d["mode"])
    if "max_gb" in d:
        set_setting("tv_prep_max_gb", max(0.0, float(d["max_gb"] or 0)))
    if d.get("scope") in ("tv", "all"):
        set_setting("tv_prep_scope", d["scope"])
        v.rescan = True
        log_action("تجهيز الفيديو للتلفاز", "كل الفيديو" if d["scope"] == "all" else "فيديو مربعات التلفاز")
    if d.get("action") == "start":
        v.manual, v.rescan = True, True
        log_action("تجهيز الفيديو للتلفاز", "بدء الآن")
    elif d.get("action") == "stop":
        v.manual = False
    elif d.get("action") == "rescan":
        v.rescan = True
    v.prep_wake.set()
    return api_admin_tv_prep()


# ----------------------------------------------------------------------------- البند 21: استبدال الأصل بالنسخة المجهّزة
# النسخة المجهّزة (MP4 بدقة 1080p على الأكثر) تأخذ مكان الأصل في المجلد نفسه، والأصل يذهب إلى سلة المحذوفات
# (يمكن إرجاعه حتى تُفرَّغ السلة). يوفّر المساحة، لكن الجودة تصير 1080p والفيديو الملوّن الواسع (HDR) يصير عادياً.
_replace_job = {"running": False, "done": 0, "total": 0, "saved": 0, "current": "", "finished": None, "error": None}


def _recycle_dest(src: Path, data_paths, folders: list[Path]) -> Path | None:
    from .core import RECYCLE
    try:
        rel = src.resolve().relative_to(data_paths.homes.resolve())
        return data_paths.homes / rel.parts[0] / RECYCLE / Path(*rel.parts[1:])
    except ValueError:
        pass
    for base in folders:
        try:
            rel = src.resolve().relative_to(base.resolve())
            return base / RECYCLE / rel
        except ValueError:
            continue
    return None


def replace_candidates(data_paths) -> list[tuple[Path, Path]]:
    """(الأصل، النسخة المجهّزة) لكل فيديو جاهز ما زال أصله موجوداً داخل الملفات."""
    v = _tvv()
    out = []
    for key, src in list(v.srcmap.items()):
        f = Path(src)
        try:
            if f.is_file() and v.key(f) == key and v.out(key).is_file():
                out.append((f, v.out(key)))
        except OSError:
            continue
    return out


def _do_replace(data_paths, folders: list[Path], pairs: list[tuple[Path, Path]]):
    from .core import unique_path
    job = _replace_job
    try:
        for src, ready in pairs:
            job["current"] = src.name
            dest = _recycle_dest(src, data_paths, folders)
            if dest is None:
                continue
            try:
                st = src.stat()
                new = src.with_suffix(".mp4")
                if new != src and new.exists():
                    new = unique_path(new)
                tmp = src.with_name(f".{src.stem}.hnpart.mp4")
                shutil.copy2(ready, tmp)
                os.utime(tmp, (st.st_atime, st.st_mtime))      # يبقى تاريخ الفيديو كما هو في «صوري»
                dest = unique_path(dest)
                dest.parent.mkdir(parents=True, exist_ok=True)
                os.rename(src, dest)                             # الأصل إلى سلة المحذوفات
                os.replace(tmp, new)
                job["saved"] += max(0, st.st_size - new.stat().st_size)
                ready.unlink(missing_ok=True)
            except OSError as exc:
                job["error"] = str(exc)[:200]
            job["done"] += 1
    finally:
        job.update(running=False, current="", finished=datetime.now().isoformat(timespec="seconds"))
        from . import tvvideo
        tvvideo.get(data_paths.cache).rescan = True
        try:
            from .core import connect
            from .photos import indexer
            db = connect(data_paths.db)
            for d in {p.parent for p, _ in pairs}:
                try:
                    indexer().notify_path(db, d)
                except Exception:  # noqa: BLE001
                    pass
            db.execute("INSERT INTO logs(ts, username, ip, action, detail) VALUES (?,?,?,?,?)",
                       (datetime.now().isoformat(timespec="seconds"), "النظام", None, "استبدال الفيديو الأصلي بالمجهّز",
                        f"{job['done']} فيديو، وُفّر {job['saved'] // 1048576} MB"))
            db.commit()
            db.close()
        except Exception:  # noqa: BLE001
            pass


@bp.get("/api/admin/tv/prep/replace")
@admin_required
def api_admin_tv_replace_info():
    pairs = replace_candidates(paths())
    size_src = sum(s.stat().st_size for s, _ in pairs)
    size_ready = sum(r.stat().st_size for _, r in pairs)
    return jsonify(count=len(pairs), originals=size_src, prepared=size_ready, saving=max(0, size_src - size_ready), job=_replace_job)


@bp.post("/api/admin/tv/prep/replace")
@admin_required
def api_admin_tv_replace():
    if _replace_job["running"]:
        abort(409, "يعمل الآن")
    p = paths()
    pairs = replace_candidates(p)
    if not pairs:
        abort(400, "لا توجد فيديوهات مجهّزة بعد")
    folders = [Path(r["path"]) for r in get_db().execute("SELECT path FROM folders")]
    _replace_job.update(running=True, done=0, total=len(pairs), saved=0, current="", finished=None, error=None)
    import threading
    threading.Thread(target=_do_replace, args=(p, folders, pairs), daemon=True, name="tv-replace").start()
    log_action("استبدال الفيديو الأصلي بالمجهّز", f"{len(pairs)} فيديو (الأصل إلى سلة المحذوفات)")
    return jsonify(ok=True, job=_replace_job)


def _vinfo(src: Path, ready_url: str):
    _tvv().used()
    st = _tvv().status(src)
    if st["mode"] == "ready":
        st["url"] = ready_url
    return jsonify(st)


def _send_ready(src: Path):
    from . import tvvideo
    _tvv().used()
    st = _tvv().status(src)
    f = _tvv().ready_file(st.get("key", "")) if st["mode"] == "ready" else None
    if not f:
        abort(404)
    tvvideo.touch(f)
    return send_file(f, conditional=True, mimetype="video/mp4")


@bp.get("/api/tv/tile/<int:tid>/vinfo")
def api_tv_tile_vinfo(tid):
    p = tile_file(tid)
    return _vinfo(p, f"/api/tv/tile/{tid}/tvvideo?p={quote(request.args.get('p', ''))}")


@bp.get("/api/tv/tile/<int:tid>/tvvideo")
def api_tv_tile_tvvideo(tid):
    return _send_ready(tile_file(tid))


def library_file(mid) -> Path:
    u = tv_user()
    row = get_db().execute("SELECT * FROM media WHERE id=? AND library=?", (mid, f"u:{u['id']}")).fetchone()
    if not row:
        abort(404)
    p = (paths().homes / u["username"] / "Photos" / row["rel_path"]).resolve()
    if not p.is_file():
        abort(404)
    return p


@bp.get("/api/tv/photo/<int:mid>/vinfo")
def api_tv_photo_vinfo(mid):
    return _vinfo(library_file(mid), f"/api/tv/photo/{mid}/tvvideo")


@bp.get("/api/tv/photo/<int:mid>/tvvideo")
def api_tv_photo_tvvideo(mid):
    return _send_ready(library_file(mid))


@bp.get("/api/tv/tile/<int:tid>/thumb")
def api_tv_tile_thumb(tid):
    u, t = my_tile(tid)
    base = tile_folder(u, t)
    if base is None:
        abort(404)
    p = safe_sub(base, request.args.get("p", ""))
    from .files import thumb_response
    return thumb_response(p, request.args.get("s") == "big")


@bp.get("/tv/game/<int:tid>/", defaults={"sub": ""})
@bp.get("/tv/game/<int:tid>/<path:sub>")
def tv_game_file(tid, sub):
    u, t = my_tile(tid)
    if t["kind"] in NOFOLDER:
        abort(404)
    base = tile_folder(u, t)
    if base is None:
        abort(404)
    p = safe_sub(base, sub)
    if p.is_dir():
        p = p / "index.html"
    if not p.is_file():
        abort(404)
    newer = shared_kit(p)
    if newer:   # v1.9.7: مكتبة الألعاب المشتركة تأتي من السيرفر (تتحدّث مع التحديث، لأن مجلدات الألعاب لا تتحدّث)
        return send_file(newer, conditional=True, max_age=0)
    return send_file(p, conditional=True)


KIT_DIR = Path(__file__).resolve().parent.parent / "static" / "kit"
KIT_MARK = {"kit.js": b"// kit.js \xe2\x80\x94", "kit.css": b"/* kit.css \xe2\x80\x94"}   # «// kit.js —» و«/* kit.css —»


def shared_kit(p: Path) -> Path | None:
    """إن كان الملف نسخة من kit.js أو kit.css المشتركة (تُعرف من سطرها الأول) نعطي أحدث نسخة مع السيرفر.
    لعبة عدّلت نسختها وغيّرت سطرها الأول تبقى على نسختها."""
    mark = KIT_MARK.get(p.name)
    if not mark or not (KIT_DIR / p.name).is_file():
        return None
    try:
        with open(p, "rb") as f:
            head = f.read(len(mark))
    except OSError:
        return None
    return KIT_DIR / p.name if head == mark else None


@bp.get("/api/tv/photos")
def api_tv_photos():
    u = tv_user()
    off = max(0, request.args.get("offset", 0, type=int))
    rows = get_db().execute("SELECT id, name, is_video, taken_at FROM media WHERE library=? "
                            "ORDER BY taken_at DESC, id DESC LIMIT 120 OFFSET ?", (f"u:{u['id']}", off)).fetchall()
    return jsonify(items=[dict(r) for r in rows], next=off + len(rows) if len(rows) == 120 else None)


@bp.get("/api/tv/wallpaper")
def api_tv_wallpaper():
    """صور عشوائية من مكتبة المستخدم (المفضلة أولاً) للخلفية وإطار الصور."""
    u = tv_user()
    db = get_db()
    rows = db.execute("SELECT m.id FROM media m JOIN favorites f ON f.media_id=m.id AND f.user_id=? "
                      "WHERE m.library=? AND m.is_video=0 ORDER BY RANDOM() LIMIT 30", (u["id"], f"u:{u['id']}")).fetchall()
    if len(rows) < 10:
        rows += db.execute("SELECT id FROM media WHERE library=? AND is_video=0 ORDER BY RANDOM() LIMIT 30",
                           (f"u:{u['id']}",)).fetchall()
    ids = list(dict.fromkeys(r["id"] for r in rows))[:30]
    return jsonify(ids=ids)


@bp.get("/api/tv/photo/<int:mid>/<what>")
def api_tv_photo(mid, what):
    u = tv_user()
    row = get_db().execute("SELECT * FROM media WHERE id=? AND library=?", (mid, f"u:{u['id']}")).fetchone()
    if not row:
        abort(404)
    from .photos import send_thumb, send_view
    base = paths().homes / u["username"] / "Photos"
    p = (base / row["rel_path"]).resolve()
    if not p.exists():
        abort(404)
    if what == "thumb":
        return send_thumb(row, p)
    if what == "view":
        return send_view(row, p)
    abort(404)


# ----------------------------------------------------------------------------- الكتب (PDF) كصفحات

def _pdf_target(tid: int) -> Path:
    u, t = my_tile(tid)
    base = tile_folder(u, t)
    if base is None:
        abort(404)
    p = safe_sub(base, request.args.get("p", ""))
    if not p.is_file() or p.suffix.lower() != ".pdf":
        abort(404)
    return p


@bp.get("/api/tv/tile/<int:tid>/pdfinfo")
def api_tv_pdfinfo(tid):
    """عدد صفحات الكتاب؛ إن لم تتوفر أدوات poppler يعرض التلفاز الملف مباشرة."""
    p = _pdf_target(tid)
    import shutil as _sh
    if not (_sh.which("pdfinfo") and _sh.which("pdftoppm")):
        return jsonify(pages=None)
    try:
        r = subprocess.run(["pdfinfo", str(p)], capture_output=True, text=True, timeout=30)
        m = re.search(r"^Pages:\s+(\d+)", r.stdout, re.M)
        return jsonify(pages=int(m.group(1)) if m else None)
    except (subprocess.TimeoutExpired, OSError):
        return jsonify(pages=None)


@bp.get("/api/tv/tile/<int:tid>/page")
def api_tv_pdf_page(tid):
    p = _pdf_target(tid)
    page = max(1, request.args.get("n", 1, type=int))
    import hashlib
    st = p.stat()
    key = hashlib.sha1(f"{p}|{st.st_size}|{st.st_mtime}".encode()).hexdigest()
    out = paths().cache / "tvpdf" / key[:2] / key / f"{page}.jpg"
    if not out.exists():
        out.parent.mkdir(parents=True, exist_ok=True)
        stem = out.with_suffix("")
        try:
            subprocess.run(["pdftoppm", "-jpeg", "-jpegopt", "quality=85", "-scale-to", "1600", "-f", str(page),
                            "-l", str(page), "-singlefile", str(p), str(stem)], capture_output=True, timeout=120)
        except (subprocess.TimeoutExpired, OSError):
            abort(500)
        if not out.exists():
            abort(404)
    return send_file(out, mimetype="image/jpeg", max_age=86400 * 30)


# ----------------------------------------------------------------------------- إعدادات من التلفاز (للمدير فقط)

def tv_admin():
    u = tv_user()
    if not u["is_admin"]:
        abort(403, "للمدير فقط")
    if not u["tv_pin"]:
        abort(403, "ضع رمز دخول (PIN) لحساب المدير على التلفاز أولاً")
    return u


@bp.get("/api/tv/admin/net")
def api_tv_admin_net():
    tv_admin()
    from .sysadmin import available, helper
    if not available():
        return jsonify(available=False)
    return jsonify(available=True, net=helper("net-status", as_json=True))


@bp.post("/api/tv/admin/wifi/<action>")
def api_tv_admin_wifi(action):
    u = tv_admin()
    from .sysadmin import helper
    d = body()
    if action == "scan":
        return jsonify(networks=helper("wifi-scan", timeout=60, as_json=True))
    if action == "connect":
        ssid = str(d.get("ssid") or "").strip()
        if not ssid:
            abort(400)
        helper("wifi-connect", ssid, stdin=str(d.get("password") or ""), timeout=120)
        log_action("الاتصال بالوايفاي من التلفاز", ssid, u["username"])
        return jsonify(ok=True, net=helper("net-status", as_json=True))
    if action == "forget":
        helper("wifi-forget", timeout=60)
        return jsonify(ok=True)
    if action == "install":
        helper("wifi-install", timeout=3600)
        return jsonify(ok=True)
    abort(404)


@bp.get("/api/tv/saver")
def api_tv_saver():
    """نصوص شاشة التوقف «نص»."""
    tv_guard()
    s = tv_settings()
    return jsonify(kind=s["saver_kind"], text=s["saver_text"], texts=welcome.saver_texts())


@bp.post("/api/tv/admin/saver")
def api_tv_admin_saver():
    """اختيار شاشة التوقف من التلفاز نفسه."""
    u = tv_admin()
    k = body().get("kind")
    if k not in SAVER_KINDS:
        abort(400, "نوع غير معروف")
    set_setting("tv_saver_kind", k)
    log_action("شاشة توقف التلفاز", k, u["username"])
    return jsonify(ok=True, kind=k)


# البند 72: إعدادات أكثر من التلفاز نفسه (بالرمز PIN للمدير)، بالدالة نفسها التي تحفظ من لوحة التحكم
TV_SET_KEYS = ("zoom", "margin", "night_dim", "night_off", "saver_min", "pad_sleep", "wallpaper", "kids_wallpaper",
               "lang", "lite", "weather", "home_cards", "prayer", "adhan")


@bp.post("/api/tv/admin/settings")
def api_tv_admin_settings():
    u = tv_admin()
    d = {k: v for k, v in (body() or {}).items() if k in TV_SET_KEYS}
    if not d:
        abort(400, "لا شيء للحفظ")
    try:
        apply_tv_settings(d)
    except (TypeError, ValueError):
        abort(400, "قيمة غير صالحة")
    log_action("إعدادات التلفاز من التلفاز", "، ".join(sorted(d)), u["username"])
    return jsonify(ok=True, settings=tv_settings())


@bp.get("/api/tv/admin/about")
def api_tv_admin_about():
    """«عن الجهاز»: الإصدار، والاسم والعنوان في الشبكة، والمساحة، ومدة التشغيل. لا يتصل بالإنترنت."""
    tv_admin()
    from . import __version__
    from .system import mdns_name
    out = {"version": __version__, "name": mdns_name(), "appliance": APPLIANCE, "addresses": [], "uptime": None, "disk": None}
    if shutil.which("ip"):
        try:
            r = subprocess.run(["ip", "-4", "-o", "addr", "show", "scope", "global"], capture_output=True, text=True, timeout=5)
            out["addresses"] = [ln.split()[3].split("/")[0] for ln in r.stdout.splitlines() if len(ln.split()) > 3][:4]
        except (OSError, subprocess.SubprocessError):
            pass
    try:
        out["uptime"] = int(float(Path("/proc/uptime").read_text().split()[0]))
    except (OSError, ValueError, IndexError):
        pass
    try:
        du = shutil.disk_usage(paths().data)
        out["disk"] = {"total": du.total, "free": du.free}
    except OSError:
        pass
    return jsonify(out)


@bp.get("/api/tv/admin/update")
def api_tv_admin_update():
    """البحث عن تحديث: يتصل بـ GitHub فقط عند الضغط على «ابحث عن تحديث» (البند 57)."""
    tv_admin()
    from .system import update_info
    return jsonify(update_info())


@bp.post("/api/tv/admin/update")
def api_tv_admin_update_run():
    u = tv_admin()
    from .system import update_run
    update_run()
    log_action("تحديث النظام من التلفاز", "", u["username"])
    return jsonify(ok=True)


@bp.post("/api/tv/admin/power")
def api_tv_admin_power():
    """إعادة تشغيل التلفاز (المتصفح) أو الجهاز كله."""
    u = tv_admin()
    action = body().get("action")
    if not APPLIANCE or action not in ("tv", "reboot"):
        abort(400, "غير متاح على هذا الجهاز")
    log_action("إعادة تشغيل التلفاز" if action == "tv" else "إعادة تشغيل الجهاز", "من التلفاز", u["username"])
    if action == "tv":
        subprocess.Popen(["sudo", "-n", HELPER, "tv-restart"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        subprocess.Popen(["sudo", "-n", "/usr/bin/systemctl", "reboot"])
    return jsonify(ok=True)


@bp.get("/api/tv/admin/audio")
def api_tv_admin_audio():
    tv_admin()
    ok, out = kiosk_helper("tv-audio-status", timeout=120)
    if not ok:
        return jsonify(error=out or "error")
    return jsonify(json.loads(out))


@bp.post("/api/tv/admin/audio")
def api_tv_admin_audio_set():
    u = tv_admin()
    d = body()
    ok, out = kiosk_helper("tv-audio-test", timeout=60) if d.get("action") == "test" else audio_set(d)
    if not ok:
        abort(400, out or "error")
    if d.get("action") != "test":
        log_action("مخرج صوت التلفاز", d.get("profile") or d.get("action") or "", u["username"])
    return jsonify(ok=True)


@bp.post("/api/tv/pads/off")
def api_tv_pads_off():
    """البند 65: إطفاء القبضات الموصولة بالبلوتوث (بعد مدة بلا لعب، أو بزر «أطفئ القبضات»). لا يحتاج رمز المدير، لكن يحتاج فرداً مختاراً على التلفاز."""
    tv_user()
    from .sysadmin import available, helper
    if not available():
        return jsonify(off=[])
    return jsonify(helper("bt-pads-off", timeout=90, as_json=True) or {"off": []})


@bp.get("/api/tv/admin/bt")
def api_tv_admin_bt():
    tv_admin()
    from .sysadmin import available, helper
    if not available():
        return jsonify(available=False)
    return jsonify(available=True, **helper("bt-status", as_json=True))


@bp.get("/api/tv/admin/pad/diag")
def api_tv_admin_pad_diag():
    tv_admin()
    from .sysadmin import available, helper
    if not available():
        return jsonify(available=False)
    return jsonify(available=True, **helper("pad-diag", timeout=60, as_json=True))


@bp.post("/api/tv/admin/pad/generic")
def api_tv_admin_pad_generic():
    """التعريف العام لأيادي سويتش غير الأصلية (من شاشة «تشخيص اليد»)."""
    tv_admin()
    from .sysadmin import available, helper
    if not available():
        abort(400, "متاح على جهاز HOME ANAB المخصص فقط")
    return jsonify(helper("pad-generic", "on" if body().get("on") else "off", timeout=60, as_json=True))


@bp.post("/api/tv/admin/bt/<action>")
def api_tv_admin_bt_action(action):
    u = tv_admin()
    from .sysadmin import helper
    mac = str(body().get("mac") or "")
    if action == "install":
        helper("bt-install", timeout=1800)
    elif action == "scan":
        helper("bt-scan", timeout=60)
    elif action == "pairpad":   # البند 49: ابحث عن يد في وضع الربط واربطها وحدك
        r = helper("bt-pair-pad", timeout=150, as_json=True) or {}
        log_action("بلوتوث من التلفاز", f"ربط يد {r.get('name', '')} {r.get('mac', '')}", u["username"])
        return jsonify(available=True, paired=r, **helper("bt-status", as_json=True))
    elif action in ("pair", "remove", "disconnect"):   # البند 73: disconnect = فصل يد واحدة
        if not re.fullmatch(r"[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}", mac):
            abort(400)
        helper(f"bt-{action}", mac, timeout=150)
        log_action("بلوتوث من التلفاز", f"{action} {mac}", u["username"])
    else:
        abort(404)
    return jsonify(available=True, **helper("bt-status", as_json=True))
