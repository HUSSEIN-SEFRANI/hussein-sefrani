// HOME ANAB TV — واجهة التلفاز. تعمل بالأسهم و«موافق» و«رجوع» (ريموت أو لوحة مفاتيح)، والفأرة أيضاً.
import * as A from "./tv-art.js";
import * as F from "./tv-fruit.js";

const TV = window.__TV__ || {};
const stage = document.getElementById("stage");
let scale = 1;
let settings = { saver_min: 10, nosleep: true, words: ["ar", "fr", "en"], wallpaper: "animated" };
let me = null; // بيانات الرئيسية للمستخدم الحالي

// ============================================================== أدوات
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
function h(html) {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
const pad = (n) => String(n).padStart(2, "0");
const joinp = (a, b) => (a ? `${a}/${b}` : b);
const encPath = (p) => p.split("/").map(encodeURIComponent).join("/");

async function api(url, opts = {}) {
  const o = { credentials: "same-origin", ...opts };
  if (o.json !== undefined) {
    o.method = o.method || "POST";
    o.headers = { "Content-Type": "application/json" };
    o.body = JSON.stringify(o.json);
    delete o.json;
  }
  const r = await fetch(url, o);
  let data = {};
  try { data = await r.json(); } catch { /* لا شيء */ }
  if (!r.ok) {
    const err = new Error(data.error || `خطأ ${r.status}`);
    err.status = r.status;
    if (r.status === 401 && !url.includes("/login")) setTimeout(() => whoScreen(), 0);
    throw err;
  }
  return data;
}

function toast(msg, ms = 3000) {
  const t = h(`<div class="toast">${esc(msg)}</div>`);
  stage.appendChild(t);
  setTimeout(() => t.remove(), ms);
}

function fit() {
  const m = Math.max(0, Math.min(8, +(settings && settings.margin) || 0)) / 100;
  const z = Math.max(70, Math.min(130, +(settings && settings.zoom) || 100)) / 100;
  scale = Math.min((innerWidth * (1 - 2 * m)) / 1280, (innerHeight * (1 - 2 * m)) / 720) * z;
  stage.style.transform = `translate(${(innerWidth - 1280 * scale) / 2}px, ${(innerHeight - 720 * scale) / 2}px) scale(${scale})`;
}
addEventListener("resize", fit);
fit();

// ============================================================== التاريخ والوقت
// لغة الواجهة يختارها الأبوان (لوحة التحكم ← وضع التلفاز). النصوص العربية تُترجم في i18n.js
const AR = !window.I18N || I18N.lang === "ar";
/** اسم داخل جملة: نعزله (FSI…PDI) ليُترجم ما حوله ويبقى الاسم كما هو، وليُعرض صحيحاً بين الاتجاهين */
const nm = (s) => `\u2068${s}\u2069`;
const LOC = AR ? "ar-SY" : I18N.locale;
const NEXT_KEY = AR ? "ArrowLeft" : "ArrowRight", PREV_KEY = AR ? "ArrowRight" : "ArrowLeft";   // «التالي» حسب اتجاه القراءة
const unitText = (n, unit, unitDisplay = "long") => new Intl.NumberFormat(LOC, { style: "unit", unit, unitDisplay }).format(n);
const agoText = (n, unit) => new Intl.RelativeTimeFormat(LOC, { numeric: "auto" }).format(-n, unit);
/** مدة حتى موعد: «بعد 2 س و 5 د» بالعربية، و«2 hr 5 min» بغيرها */
const inText = (hh, mm, long = false) => AR ? `بعد ${hh ? `${hh} ${long ? "ساعة" : "س"} و ` : ""}${mm} ${long ? "دقيقة" : "د"}`
  : `· ${hh ? unitText(hh, "hour", "short") + " " : ""}${unitText(mm, "minute", "short")}`;
const fmtDate = new Intl.DateTimeFormat(`${LOC}-u-nu-latn`, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
const fmtDM = new Intl.DateTimeFormat(`${LOC}-u-nu-latn`, { day: "numeric", month: "long" });
let fmtHijri = null;
try { fmtHijri = new Intl.DateTimeFormat(`${AR ? "ar-SA" : LOC}-u-ca-islamic-umalqura-nu-latn`, { day: "numeric", month: "long", year: "numeric" }); } catch { /* غير مدعوم */ }
const hhmm = (d = new Date()) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const ageText = (n) => !AR ? unitText(n, "year") : (n === 1 ? "سنة واحدة" : n === 2 ? "سنتان" : n <= 10 ? `${n} سنوات` : `${n} سنة`);
const daysText = (n) => !AR ? unitText(n, "day") : (n === 1 ? "يوم واحد" : n === 2 ? "يومان" : n <= 10 ? `${n} أيام` : `${n} يوماً`);
const birthDM = (u) => fmtDM.format(new Date(2000, u.birth_month - 1, u.birth_day));

function tick() {
  const now = new Date();
  const t = hhmm(now), d = fmtDate.format(now), hj = fmtHijri ? fmtHijri.format(now) : "";
  stage.querySelectorAll(".js-tm").forEach((e) => { if (e.textContent !== t) e.textContent = t; });
  stage.querySelectorAll(".js-dt").forEach((e) => { if (e.textContent !== d) e.textContent = d; });
  stage.querySelectorAll(".js-hj").forEach((e) => { if (e.textContent !== hj) e.textContent = hj; });
  stage.querySelectorAll(".prayer").forEach(updatePrayer);
}
setInterval(tick, 1000);

// ============================================================== الشاشات والتركيز
const stack = [];
let cur = null;
const top = () => stack[stack.length - 1];

function mount(scr) {
  scr.el.classList.add("scr");
  stage.appendChild(scr.el);
  stack.push(scr);
  scr.onShow?.();
  focusInitial(scr);
  tick();
}
function push(scr) {
  const t = top();
  if (t) { t.el.hidden = true; t.onHide?.(); }
  mount(scr);
}
function pop() {
  const s = stack.pop();
  if (!s) return;
  s.destroy?.();
  s.el.remove();
  const t = top();
  if (t) {
    t.el.hidden = false;
    t.onShow?.();
    setFocus(t.focus && t.el.contains(t.focus) ? t.focus : focusables()[0]);
  }
}
function reset(scr) {
  while (stack.length) { const s = stack.pop(); s.destroy?.(); s.el.remove(); }
  cur = null;
  mount(scr);
}
function focusables() {
  const t = top();
  const root = t && (t.el.querySelector(".tv-modal") || t.el);   // البند 73: رسالة التأكيد مفتوحة = أزرارها فقط
  return root ? [...root.querySelectorAll(".f")].filter((e) => e.offsetParent !== null) : [];
}
function focusInitial(scr) {
  const el = scr.initial?.() || focusables()[0];
  setFocus(el || null);
}
function setFocus(el, scroll = true) {
  if (cur && cur !== el) cur.classList.remove("focus");
  cur = el;
  if (!el) return;
  const t = top();
  if (t) t.focus = el;
  el.classList.add("focus");
  if (scroll) ensureVisible(el);
  t?.onFocus?.(el);
}
function ensureVisible(el) {
  const hs = el.closest(".profiles");
  if (hs) {  // شريط أفقي
    const r = el.getBoundingClientRect(), c = hs.getBoundingClientRect(), p = 60 * scale;
    if (r.left < c.left + p) hs.scrollBy({ left: (r.left - c.left - p) / scale, behavior: "smooth" });
    else if (r.right > c.right - p) hs.scrollBy({ left: (r.right - c.right + p) / scale, behavior: "smooth" });
    return;
  }
  const sc = el.closest(".grid-wrap, .list, .opt-list");
  if (!sc) return;
  const r = el.getBoundingClientRect(), c = sc.getBoundingClientRect(), p = 34 * scale;
  if (r.top < c.top + p) sc.scrollBy({ top: (r.top - c.top - p) / scale, behavior: "smooth" });
  else if (r.bottom > c.bottom - p) sc.scrollBy({ top: (r.bottom - c.bottom + p) / scale, behavior: "smooth" });
}
function move(dir) {
  const list = focusables();
  if (!list.length) return;
  if (!cur || !list.includes(cur)) { setFocus(list[0]); return; }
  const a = cur.getBoundingClientRect();
  const ax = a.left + a.width / 2, ay = a.top + a.height / 2;
  let best = null, bs = Infinity;
  for (const el of list) {
    if (el === cur) continue;
    const b = el.getBoundingClientRect();
    const dx = b.left + b.width / 2 - ax, dy = b.top + b.height / 2 - ay;
    const main = { left: -dx, right: dx, up: -dy, down: dy }[dir];
    const off = dir === "left" || dir === "right" ? Math.abs(dy) : Math.abs(dx);
    if (main <= 4) continue;
    const score = main + off * 2.5;
    if (score < bs) { bs = score; best = el; }
  }
  if (best) setFocus(best);
}
function back() {
  const t = top();
  if (!t) return;
  if (t.back) t.back();
  else if (stack.length > 1) pop();
}

// ============================================================== مستوى الصوت (لكل الفيديو والصوت)
let vol = 0.8, muted = false;
try { const v = parseFloat(localStorage.getItem("tvvol")); if (v >= 0 && v <= 1) vol = v; } catch { /* */ }
const VOL_ICON = (m) => `<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5L6 9H3v6h3l5 4z" fill="#fff"/>${m ? '<path d="M17 9l5 6M22 9l-5 6"/>' : '<path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>'}</svg>`;
function applyVol(m) { m.volume = vol; m.muted = muted; }
document.addEventListener("play", (e) => applyVol(e.target), true);
let volEl = null, volT = 0;
function showVol() {
  stage.querySelectorAll("video, audio").forEach(applyVol);
  try { localStorage.setItem("tvvol", vol); } catch { /* */ }
  if (!volEl) { volEl = h(`<div class="volosd"><div class="vi"></div><div class="vb"><i></i></div><div class="vp"></div></div>`); stage.appendChild(volEl); }
  volEl.querySelector(".vi").innerHTML = VOL_ICON(muted || vol === 0);
  volEl.querySelector(".vb i").style.height = `${muted ? 0 : Math.round(vol * 100)}%`;
  volEl.querySelector(".vp").textContent = muted ? "صامت" : `${Math.round(vol * 100)}%`;
  volEl.classList.add("show");
  clearTimeout(volT);
  volT = setTimeout(() => volEl.classList.remove("show"), 1800);
}
function volUp() { muted = false; vol = Math.min(1, Math.round((vol + 0.1) * 10) / 10); showVol(); }
function volDown() { vol = Math.max(0, Math.round((vol - 0.1) * 10) / 10); showVol(); }
function volMute() { muted = !muted; showVol(); }
const VOL_KEYS = { AudioVolumeUp: volUp, VolumeUp: volUp, "+": volUp, "=": volUp, AudioVolumeDown: volDown, VolumeDown: volDown, "-": volDown,
  AudioVolumeMute: volMute, VolumeMute: volMute, m: volMute, M: volMute };

const BACK_KEYS = new Set(["Escape", "Backspace", "BrowserBack", "GoBack"]);
document.addEventListener("keydown", (e) => {
  activity();
  if (saverEl) { hideSaver(); e.preventDefault(); return; }
  const t = top();
  if (VOL_KEYS[e.key] && !(t && t.typing)) { VOL_KEYS[e.key](); e.preventDefault(); return; }
  if (e.key === "Home" && me && !(t && t.isGame)) { homeScreen(); e.preventDefault(); return; }
  if (t?.key && t.key(e) === true) { e.preventDefault(); return; }
  const k = e.key;
  // البند 72: في صفوف الإعدادات ← → تغيّر القيمة (التالي حسب اتجاه القراءة)
  if ((k === "ArrowLeft" || k === "ArrowRight") && cur?._step && top()?.el.contains(cur)) { cur._step(k === NEXT_KEY ? 1 : -1); e.preventDefault(); return; }
  if (k === "ArrowLeft") move("left");
  else if (k === "ArrowRight") move("right");
  else if (k === "ArrowUp") move("up");
  else if (k === "ArrowDown") move("down");
  else if (k === "Enter" || k === " ") cur?.click();
  else if (BACK_KEYS.has(k)) back();
  else return;
  e.preventDefault();
});
stage.addEventListener("mouseover", (e) => {
  const f = e.target.closest(".f");
  if (f && f !== cur && top()?.el.contains(f)) setFocus(f, false);
});
let mouseT = 0;
addEventListener("mousemove", () => {
  activity();
  if (saverEl) hideSaver();
  document.body.classList.remove("nomouse");
  clearTimeout(mouseT);
  mouseT = setTimeout(() => document.body.classList.add("nomouse"), 3000);
});
addEventListener("contextmenu", (e) => { e.preventDefault(); back(); });

// ============================================================== قطع مشتركة
function nightBg() {
  return `<div class="layer"><div class="blob drift1" style="width:620px;height:620px;background:#2563eb;opacity:.45;top:-220px;right:-140px"></div>
  <div class="blob drift2" style="width:560px;height:560px;background:#f97316;opacity:.35;bottom:-260px;left:-120px"></div>
  <div class="blob drift1" style="width:420px;height:420px;background:#14b8a6;opacity:.3;bottom:-120px;right:320px;animation-delay:-5s"></div>
  <div class="star" style="top:110px;left:210px;width:6px;height:6px;background:#fde68a"></div>
  <div class="star" style="top:180px;left:980px;width:5px;height:5px;background:#fff;animation-delay:1s"></div>
  <div class="star" style="top:70px;left:640px;width:4px;height:4px;background:#bae6fd;animation-delay:2s"></div></div>`;
}
function skyBg() {
  return `<div class="layer"><div class="sun" style="top:70px;left:180px;width:150px;height:150px;background:#fff3c4;box-shadow:0 0 90px 30px rgba(255,236,170,.65)"></div>
  <div class="cloud" style="top:120px;left:420px;width:260px;opacity:.85">${A.CLOUD}</div>
  <div class="cloud" style="top:60px;left:820px;width:180px;opacity:.7;animation-duration:34s">${A.CLOUD}</div>
  <svg style="position:absolute;bottom:0;left:0" width="1280" height="380" viewBox="0 0 1280 380" preserveAspectRatio="none" aria-hidden="true">
    <path d="M0 210 C160 140 300 170 460 120 C640 64 800 150 980 110 C1110 82 1200 120 1280 100 L1280 380 L0 380 Z" fill="#5b8bd6" opacity=".55"/>
    <path d="M0 260 C200 200 360 250 560 200 C760 152 900 240 1100 196 C1190 176 1240 190 1280 184 L1280 380 L0 380 Z" fill="#3a6bb8" opacity=".8"/>
    <path d="M0 310 C220 270 420 320 640 280 C860 240 1020 300 1280 270 L1280 380 L0 380 Z" fill="#1f4a8f"/></svg></div>`;
}
function kidsBg() {
  return `<div class="layer">
  <svg style="position:absolute;top:22px;left:36px" width="120" height="120" viewBox="0 0 120 120" aria-hidden="true"><g class="sunray"><g stroke="#fbbf24" stroke-width="7" stroke-linecap="round"><path d="M60 4v14M60 102v14M4 60h14M102 60h14M20 20l10 10M90 90l10 10M20 100l10-10M90 30l10-10"/></g></g><circle cx="60" cy="60" r="28" fill="#fde047"/><circle cx="51" cy="57" r="3.5" fill="#92400e"/><circle cx="69" cy="57" r="3.5" fill="#92400e"/><path d="M50 68 Q60 77 70 68" stroke="#92400e" stroke-width="3.5" fill="none" stroke-linecap="round"/></svg>
  <div class="cloud" style="top:150px;left:480px;width:210px">${A.CLOUD}</div>
  <div class="cloud" style="top:110px;left:860px;width:150px;animation-duration:22s">${A.CLOUD}</div></div>`;
}
// ---------------------------------------------------------------- خلفيات إضافية: سيارات، إسلامية، صورة من اختيار الأهل
function carSvg(color, w = 210) {
  return `<svg width="${w}" height="${Math.round(w * 0.46)}" viewBox="0 0 220 100" aria-hidden="true">
    <ellipse cx="114" cy="92" rx="100" ry="6" fill="#000" opacity=".25"/>
    <path d="M12 72 Q12 52 38 48 L68 45 Q90 18 120 17 L150 17 Q174 19 188 45 L202 49 Q216 53 216 72 L216 80 L12 80 Z" fill="${color}"/>
    <path d="M12 72 L216 72 L216 80 L12 80 Z" fill="#000" opacity=".15"/>
    <path d="M78 46 Q96 25 122 25 L132 25 L132 46 Z M140 25 L150 25 Q167 27 178 46 L140 46 Z" fill="#dbeafe" opacity=".92"/>
    <circle cx="58" cy="80" r="16" fill="#1f2937"/><circle cx="58" cy="80" r="7" fill="#cbd5e1"/>
    <circle cx="172" cy="80" r="16" fill="#1f2937"/><circle cx="172" cy="80" r="7" fill="#cbd5e1"/>
    <rect x="203" y="57" width="12" height="7" rx="3" fill="#fef08a"/><rect x="12" y="58" width="9" height="7" rx="3" fill="#f87171"/></svg>`;
}
function carsBg(kids = false) {
  const lane = (y, list, rev = false) => list.map(([c, dur, delay, w]) =>
    `<div class="car${rev ? " rev" : ""}" style="bottom:${y}px;animation-duration:${dur}s;animation-delay:-${delay}s">${carSvg(c, w)}</div>`).join("");
  const city = kids ? "" : Array.from({ length: 22 }, (_, i) => {
    const w = 46 + ((i * 37) % 40), hgt = 90 + ((i * 53) % 150), x = i * 60 - 10;
    const win = Array.from({ length: Math.floor(hgt / 26) }, (_, j) => (i + j) % 3 ? `<rect x="${x + 10}" y="${470 - hgt + 14 + j * 26}" width="8" height="10" fill="#fde68a" opacity=".8"/><rect x="${x + w - 18}" y="${470 - hgt + 14 + j * 26}" width="8" height="10" fill="#fde68a" opacity=".55"/>` : "").join("");
    return `<rect x="${x}" y="${470 - hgt}" width="${w}" height="${hgt + 10}" fill="#1e1b4b" opacity=".9"/>${win}`;
  }).join("");
  const hills = kids ? `<path d="M0 470 C200 400 380 440 560 410 C760 376 940 450 1280 400 L1280 480 L0 480 Z" fill="#86efac"/>
    <circle cx="180" cy="430" r="34" fill="#22c55e"/><rect x="176" y="440" width="8" height="40" fill="#92400e"/>
    <circle cx="1090" cy="420" r="40" fill="#16a34a"/><rect x="1086" y="430" width="9" height="50" fill="#92400e"/>` : "";
  return `<div class="layer">
    <svg style="position:absolute;inset:0" width="1280" height="720" viewBox="0 0 1280 720" aria-hidden="true">
      ${kids ? "" : `<circle cx="980" cy="440" r="90" fill="#fdba74" opacity=".85"/>`}${city}${hills}
      <rect x="0" y="480" width="1280" height="240" fill="${kids ? "#64748b" : "#1f2937"}"/>
      <rect x="0" y="480" width="1280" height="8" fill="${kids ? "#e2e8f0" : "#475569"}"/>
      <rect x="0" y="712" width="1280" height="8" fill="${kids ? "#e2e8f0" : "#475569"}"/>
      <g class="dashes"><rect x="0" y="596" width="2600" height="8" fill="url(#dash)"/></g>
      <defs><pattern id="dash" width="120" height="8" patternUnits="userSpaceOnUse"><rect width="64" height="8" fill="#fde68a"/></pattern></defs></svg>
    ${lane(14, [["#ef4444", 13, 0, 200], ["#3b82f6", 13, 6.5, 190]])}
    ${lane(122, [["#22c55e", 16, 3, 170], ["#f59e0b", 16, 11, 175]], true)}</div>`;
}
function mosqueSvg(fill, glow, kids) {
  const arch = (x, y, w, h) => `<path d="M${x} ${y + h} L${x} ${y + w / 2} Q${x} ${y} ${x + w / 2} ${y} Q${x + w} ${y} ${x + w} ${y + w / 2} L${x + w} ${y + h} Z" fill="${glow}"/>`;
  const minaret = (x) => `<rect x="${x}" y="300" width="34" height="420" fill="${fill}"/><rect x="${x - 8}" y="360" width="50" height="12" rx="4" fill="${fill}"/>
    <path d="M${x - 4} 300 L${x + 17} 236 L${x + 38} 300 Z" fill="${kids ? "#f59e0b" : fill}"/><circle cx="${x + 17}" cy="230" r="5" fill="${kids ? "#f59e0b" : glow}"/>
    ${arch(x + 10, 400, 14, 26)}${arch(x + 10, 470, 14, 26)}`;
  return `<svg class="mosque" style="position:absolute;inset:0" width="1280" height="720" viewBox="0 0 1280 720" aria-hidden="true">
    ${minaret(270)}${minaret(976)}
    <path d="M360 720 L360 520 L920 520 L920 720 Z" fill="${fill}"/>
    <path d="M500 520 Q500 380 640 350 Q780 380 780 520 Z" fill="${kids ? "#fbbf24" : fill}"/>
    <path d="M630 350 L640 312 L650 350 Z" fill="${kids ? "#f59e0b" : fill}"/><path d="M646 300 a12 12 0 1 1 -10 -18 a9 9 0 1 0 10 18 Z" fill="${kids ? "#f59e0b" : glow}"/>
    <path d="M380 520 Q380 455 440 440 Q500 455 500 520 Z" fill="${kids ? "#fcd34d" : fill}"/>
    <path d="M780 520 Q780 455 840 440 Q900 455 900 520 Z" fill="${kids ? "#fcd34d" : fill}"/>
    ${[400, 470, 560, 690, 780, 850].map((x) => arch(x, 580, 30, 60)).join("")}${arch(615, 600, 50, 120)}</svg>`;
}
function islamicBg(kids = false) {
  const lantern = (x, len, d) => `<div class="lantern" style="left:${x}px;animation-delay:-${d}s"><i style="height:${len}px"></i>
    <svg width="46" height="78" viewBox="0 0 46 78" aria-hidden="true"><path d="M23 0 L32 12 L14 12 Z" fill="#b45309"/><rect x="10" y="12" width="26" height="6" rx="2" fill="#d97706"/>
    <path d="M10 18 Q4 40 12 62 L34 62 Q42 40 36 18 Z" fill="#fbbf24" opacity=".95"/><path d="M17 22 Q14 40 18 58 L28 58 Q32 40 29 22 Z" fill="#fff7d6"/>
    <rect x="9" y="62" width="28" height="6" rx="2" fill="#d97706"/><path d="M16 68 L30 68 L23 78 Z" fill="#b45309"/></svg></div>`;
  const stars = kids ? "" : Array.from({ length: 26 }, (_, i) => `<div class="star" style="top:${(i * 47) % 300 + 20}px;left:${(i * 97) % 1240 + 20}px;width:${2 + (i % 3)}px;height:${2 + (i % 3)}px;background:#fef9c3;animation-delay:${(i % 5) * 0.6}s"></div>`).join("");
  return `<div class="layer">
    <svg class="geo" style="position:absolute;inset:0" width="1280" height="720" aria-hidden="true"><defs>
      <pattern id="star8" width="80" height="80" patternUnits="userSpaceOnUse"><g fill="none" stroke="${kids ? "#0f766e" : "#fde68a"}" stroke-width="1.4">
        <rect x="22" y="22" width="36" height="36"/><rect x="22" y="22" width="36" height="36" transform="rotate(45 40 40)"/><circle cx="40" cy="40" r="7"/></g></pattern></defs>
      <rect width="1280" height="720" fill="url(#star8)" opacity="${kids ? ".10" : ".07"}"/></svg>
    ${stars}
    ${kids ? "" : `<div class="crescent"></div>`}
    ${mosqueSvg(kids ? "#ffffff" : "#0b1730", kids ? "#99f6e4" : "#fbbf24", kids)}
    ${lantern(120, 40, 0)}${lantern(1110, 70, 1.4)}${kids ? "" : lantern(1190, 20, 0.7)}</div>`;
}
function customBg(who) {
  const v = (settings.walls || {})[who];
  return v ? `<div class="layer wallimg ${who}" style="background-image:url('/api/tv/wall/${who}?v=${v}')"></div>` : skyBg();
}
function brand(size = 54) {
  return `<div class="brand">${F.LOGO(Math.round(size * 0.8))}<div class="t2">منزل العنب</div></div>`;
}
// ============================================================== نجوم العائلة
async function fillBalance(el) {
  try { const r = await api("/api/tv/stars"); el.querySelectorAll(".js-sb").forEach((b) => { b.textContent = r.my_balance ?? ""; }); } catch { /* لا شيء */ }
}
const STAR_REASONS = {
  give: ["ترتيب الغرفة 🧹", "المساعدة في البيت 🏠", "الصلاة في وقتها 🕌", "قراءة القرآن 📖", "إنهاء الواجبات 📚", "إنهاء الطعام 🍽️", "النوم مبكراً 😴", "الكلام اللطيف 💬", "مشاركة الإخوة 🤝"],
  take: ["عدم سماع الكلام", "الشجار", "التأخر عن النوم", "عدم ترتيب الأغراض", "الكلام غير اللطيف"],
  transfer: ["هدية 🎁", "شكراً لمساعدتك 🙏", "لأنك لطيف 💖", "تهنئة 🎉", "أردّ ما استلفته 🤝"],
};
function starBurst() {
  const fx = h(`<div class="starburst">${Array.from({ length: 26 }, (_, i) => `<i class="emo" style="left:${(i * 37) % 100}%;animation-delay:${(i % 7) * 0.12}s">${i % 3 ? "⭐" : "🌟"}</i>`).join("")}</div>`);
  stage.appendChild(fx); setTimeout(() => fx.remove(), 3200);
}
function ago(ts) {
  const m = Math.round((Date.now() - new Date(ts).getTime()) / 60000);
  if (m >= 1 && !AR) return m < 60 ? agoText(m, "minute") : m < 1440 ? agoText(Math.round(m / 60), "hour") : agoText(Math.round(m / 1440), "day");
  return m < 1 ? "الآن" : m < 60 ? `قبل ${m} د` : m < 1440 ? `قبل ${Math.round(m / 60)} س` : `قبل ${Math.round(m / 1440)} يوم`;
}
function starsLine(x) {
  const n = `<b class="sv">⭐ ${x.amount}</b>`;
  const what = x.kind === "transfer" ? `${nm(esc(x.from || "?"))} ← ${nm(esc(x.to || "?"))} ${n}` : x.kind === "give" ? `${nm(esc(x.by || "?"))} أعطى ${nm(esc(x.to || "?"))} ${n}`
    : x.kind === "learn" ? `📚 ${nm(esc(x.to || "?"))} أنهى درساً ${n}` : x.kind === "game" ? `🎮 ${nm(esc(x.to || "?"))} ربح ${n}` : `${nm(esc(x.by || "?"))} خصم من ${nm(esc(x.to || "?"))} ${n}`;
  return `<div class="sl f ${x.kind}"><span>${what}</span><i>${esc(x.reason)}</i><small>${ago(x.ts)}</small></div>`;
}
async function starsScreen() {
  let r;
  try { r = await api("/api/tv/stars"); } catch (e) { toast(e.message); return; }
  const el = h(`<div class="bg-dark stars-scr"><div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>الرئيسية</span></button>
    <div class="ti emo" style="background:linear-gradient(135deg,#fef3c7,#f59e0b);font-size:34px">⭐</div><h1>نجوم العائلة</h1></div>
    <div class="sp-row"></div><div class="sp-acts"></div><div class="sp-log list"></div>
    ${hints([["موافق", "اختيار"], ["⬇", "السجل"], ["رجوع", "الرئيسية"]])}</div>`);
  const draw = (d) => {
    r = d;
    const top1 = Math.max(...d.people.map((p) => p.balance));
    el.querySelector(".sp-row").innerHTML = [...d.people].sort((a, b) => b.balance - a.balance).map((p) => `<div class="sp${p.id === d.me ? " me" : ""}">
      ${p.balance === top1 && top1 > 0 ? `<span class="crown emo">👑</span>` : ""}<div class="ring">${face(p)}</div><b>${esc(p.name)}</b><div class="bal"><span class="emo">⭐</span> ${p.balance}</div></div>`).join("");
    // الأب والأم: «أعطِ» لا تنقص من رصيدهما، و«أهدِ من رصيدي» تنقل من رصيدهما
    const acts = [], meP = d.people.find((p) => p.id === d.me), parent = meP && meP.parent;
    if (d.can_manage) acts.push(`<button class="btn gold f" data-a="give">⭐ أعطِ نجوماً</button><button class="btn f" data-a="take">➖ اخصم نجوماً</button>`);
    else if (parent) acts.push(`<button class="btn gold f" data-a="needpin">⭐ أعطِ نجوماً</button>`);
    if (d.my_balance != null) acts.push(`<button class="btn ${parent ? "" : "gold "}f" data-a="transfer">🎁 أهدِ من رصيدي (${d.my_balance})</button>`);
    el.querySelector(".sp-acts").innerHTML = acts.join("");
    el.querySelector(".sp-log").innerHTML = d.log.length ? `<h3 class="sl-h">السجل</h3>${d.log.map(starsLine).join("")}` : `<p class="set-msg">لا توجد حركات بعد. كل شخص يبدأ بـ ${d.start} نجوم ⭐</p>`;
    el.querySelectorAll("[data-a]").forEach((b) => b.addEventListener("click", () => {
      if (b.dataset.a === "needpin") { toast("لتعطي نجوماً من التلفاز ضع رمز دخول (PIN) لحسابك: لوحة التحكم ← وضع التلفاز. أو من الهاتف: «نجوم العائلة»", 7000); return; }
      starFlow(b.dataset.a, r, draw);
    }));
  };
  draw(r);
  el.querySelector(".js-back").addEventListener("click", pop);
  push({ el, isStars: true, initial: () => el.querySelector("[data-a]") || el.querySelector(".js-back") });
}
function choiceScreen(title, items, onPick, cols = 4) {
  const el = h(`<div class="bg-dark"><div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>رجوع</span></button><h1>${title}</h1></div>
    <div class="choice-grid" style="grid-template-columns:repeat(${cols},1fr)">${items.map((it, i) => `<button class="choice f" data-i="${i}">${it.html}</button>`).join("")}</div>
    ${hints([["موافق", "اختيار"], ["رجوع", "رجوع"]])}</div>`);
  el.querySelector(".js-back").addEventListener("click", pop);
  el.querySelectorAll(".choice").forEach((b) => b.addEventListener("click", () => onPick(items[+b.dataset.i].value)));
  push({ el, initial: () => el.querySelector(".choice") });
}
function starFlow(kind, r, redraw) {
  const meP = r.people.find((p) => p.id === r.me);
  const verb = { transfer: "أهدِ من رصيدك", give: "أعطِ نجوماً", take: "اخصم نجوماً" }[kind];
  const people = r.people.filter((p) => kind !== "transfer" || p.id !== r.me);
  const backToStars = () => { while (stack.length > 1 && !top().isStars) pop(); };
  choiceScreen(`${verb}: لمن؟`, people.map((p) => ({ value: p, html: `<div class="ring">${face(p)}</div><b>${esc(p.name)}</b><small>⭐ ${p.balance}</small>` })), (to) => {
    const max = kind === "transfer" ? meP.balance : kind === "take" ? to.balance : 100;
    const amounts = [1, 2, 3, 5, 10, 20].filter((n) => n <= max);
    if (!amounts.length) {
      toast(kind !== "transfer" ? "الرصيد صفر" : r.can_manage ? "رصيدك صفر. لتعطي نجوماً دون أن ينقص رصيدك اختر «⭐ أعطِ نجوماً»" : "رصيدك صفر، لا تستطيع الإهداء الآن", 6000);
      return;
    }
    choiceScreen(`${verb} لـ ${nm(esc(to.name))}: كم نجمة؟`, amounts.map((n) => ({ value: n, html: `<span class="big">${n}</span><span class="emo">${"⭐".repeat(Math.min(n, 5))}</span>` })), (amount) => {
      const reasons = STAR_REASONS[kind].map((t) => ({ value: t, html: `<b>${esc(t)}</b>` }));
      reasons.push({ value: null, html: `<b>✏️ سبب آخر…</b>` });
      choiceScreen("ما السبب؟", reasons, (reason) => {
        const send = async (why, pin) => {
          const url = kind === "transfer" ? "/api/tv/stars/transfer" : "/api/tv/stars/adjust";
          const d = await api(url, { json: { to: to.id, amount, reason: why, kind, pin } });
          backToStars(); redraw(d); starBurst();
          toast(kind === "take" ? `خُصمت ${amount} من ${nm(to.name)}` : `⭐ ${amount} لـ ${nm(to.name)}`, 3500);
        };
        const withPin = (why) => {
          if (kind === "transfer" && r.has_pin) pinScreen({ title: "رمزك للتأكيد", sub: `${amount} ⭐ ← ${to.name}`, face: face(meP) }, (pin) => send(why, pin));
          else send(why).catch((e) => toast(e.message, 5000));
        };
        if (reason) withPin(reason);
        else oskScreen({ title: "اكتب السبب", okLabel: "تم" }, (txt) => { if (txt && txt.trim()) withPin(txt.trim()); });
      }, 3);
    }, 6);
  }, Math.min(6, Math.max(3, people.length)));
}

// ثيم الفاكهة: الدالية أعلى الشاشة ولون التوهج
function vineLayer(theme, hang) { return `<div class="vinelayer">${F.vine(theme, hang ? { hang } : undefined)}</div>`; }
function setTheme(theme) { stage.style.setProperty("--glow1", F.themeOf(theme).glow); stage.style.setProperty("--accent", F.themeOf(theme).accent); }

function themeScreen() {
  const cur = (me && me.user && me.user.theme) || "grape";
  const el = h(`<div class="bg-dark"><div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>الرئيسية</span></button>
    <div class="ti emo" style="background:linear-gradient(135deg,#faf5ff,#e9d5ff);font-size:34px">${F.themeOf(cur).emoji}</div><h1>ثيمي: اختر فاكهتك</h1></div>
    <div class="theme-grid">${Object.entries(F.THEMES).map(([k, t]) => `<button class="theme-card f${k === cur ? " on" : ""}" data-k="${k}" style="--c:${t.accent}">
      <div class="tv-prev">${F.vine(k, { hang: [640] })}</div><div class="tm">${F.mascot(k, 96)}</div><b>${t.name}</b>${k === cur ? "<i>✓ ثيمي الآن</i>" : ""}</button>`).join("")}</div>
    ${hints([["موافق", "اختيار"], ["رجوع", "الرئيسية"]])}</div>`);
  el.querySelector(".js-back").addEventListener("click", pop);
  el.querySelectorAll(".theme-card").forEach((b) => b.addEventListener("click", async () => {
    try { await api("/api/tv/theme", { json: { theme: b.dataset.k } }); } catch (e) { toast(e.message); return; }
    toast(`صار ثيمك: ${F.themeOf(b.dataset.k).name} ${F.themeOf(b.dataset.k).emoji}`, 3000);
    homeScreen();
  }));
  push({ el, initial: () => el.querySelector(".theme-card.on") || el.querySelector(".theme-card") });
}

// البند 52: الأزرار الأربعة اليمنى بالموقع لا بالرمز (✕○□△ في بلايستيشن، B A Y X في نينتندو، وغيرها في الأيادي غير الأصلية):
// السفلي «موافق»، الأيمن «رجوع»، الأيسر والعلوي فعلان إضافيان. والأسهم أو العصا اليسرى للتوجيه دائماً، في كل الأيادي.
const FACE_NAME = { down: "الزر السفلي", right: "الزر الأيمن", left: "الزر الأيسر", up: "الزر العلوي" };
function faceIcon(pos, size = 28) {
  const at = { up: [12, 5], left: [5, 12], right: [19, 12], down: [12, 19] };
  return `<svg class="face" width="${size}" height="${size}" viewBox="0 0 24 24" role="img" aria-label="${FACE_NAME[pos]}">${Object.entries(at).map(([k, [x, y]]) =>
    `<circle cx="${x}" cy="${y}" r="${k === pos ? 4.8 : 3.3}" fill="${k === pos ? "#fde68a" : "rgba(255,255,255,.32)"}"/>`).join("")}</svg>`;
}
const okPos = () => (padPrefs.swap ? "right" : "down"), backPos = () => (padPrefs.swap ? "down" : "right");
function hints(list) {
  return `<div class="hints">${list.map(([k, t]) => `<span><b>${k}</b>${t}</span>`).join("")}</div>`;
}

function prayerCard(p, topPx) {
  if (!p) return "";
  if (!p.times) {
    return `<div class="card glass prayer" style="top:${topPx}px"><h3>مواقيت الصلاة</h3>
      <div class="cd">اختر مدينتك من لوحة تحكم السيرفر ← وضع التلفاز</div></div>`;
  }
  const rows = p.times.map((t) => `<div class="row" data-k="${t.key}" data-t="${t.time}" data-n="${esc(t.name)}"><span>${esc(t.name)}</span><span class="ltr">${t.time}</span></div>`).join("");
  return `<div class="card glass prayer" style="top:${topPx}px"><div class="hd"><h3>مواقيت الصلاة</h3><span class="city">${esc(p.city || "")}</span></div>
    <div class="grid">${rows}</div><div class="cd"></div></div>`;
}
function updatePrayer(card) {
  const rows = [...card.querySelectorAll(".row[data-t]")];
  if (!rows.length) return;
  const now = new Date(), nowM = now.getHours() * 60 + now.getMinutes();
  const mins = (t) => { const [a, b] = t.split(":").map(Number); return a * 60 + b; };
  const cand = rows.filter((r) => r.dataset.k !== "sunrise");
  let nx = cand.find((r) => mins(r.dataset.t) > nowM);
  let diff;
  if (nx) diff = mins(nx.dataset.t) - nowM;
  else { nx = cand[0]; diff = 24 * 60 - nowM + mins(nx.dataset.t); }
  rows.forEach((r) => r.classList.toggle("nx", r === nx));
  const hh = Math.floor(diff / 60), mm = diff % 60;
  const txt = `${nx.dataset.n} ${inText(hh, mm)}`;
  const cd = card.querySelector(".cd");
  if (cd && cd.textContent !== txt) cd.textContent = txt;
}
function wordCard(w, topPx, kids = false) {
  if (!w) return "";
  const langs = settings.words || ["ar", "fr", "en"];
  const tr = [["fr", "FR"], ["en", "EN"]].filter(([k]) => langs.includes(k))
    .map(([k, l]) => (kids ? `<b>${esc(w[k])}</b>` : `<span><b>${esc(w[k])}</b><small>${l}</small></span>`)).join("");
  const art = (size) => (w.emoji ? `<span class="emo" style="font-size:${Math.round(size * 0.82)}px;line-height:1">${w.emoji}</span>` : A.wordArt(w.icon, size));
  if (kids) {
    return `<div class="kcard" style="top:${topPx}px;left:40px">${art(66)}<div><div class="lbl">كلمة اليوم</div>
      <div class="big" translate="no">${esc(w.ar)}</div><div class="tr" translate="no">${tr}</div></div></div>`;
  }
  return `<div class="card glass word" style="top:${topPx}px">${art(76)}<div style="flex:1"><div class="lbl">كلمة اليوم</div>
    <div class="ar" translate="no">${esc(w.ar)}</div><div class="tr" translate="no">${tr}</div></div></div>`;
}

// الطقس ونص اليوم (حديث، آية، حكمة، مثل) في الصفحة الرئيسية
function weatherLine(w) {
  if (!w) return "";
  const range = w.max != null && w.min != null ? ` · <bdi dir="ltr">${w.min}° / ${w.max}°</bdi>` : "";
  return `<span class="emo">${w.icon}</span> <b><bdi dir="ltr">${w.temp}°</bdi></b> <small>${esc(w.desc || "")}${w.city ? ` · ${esc(w.city)}` : ""}${range}</small>`;
}
const TEXT_ICON = { hadith: "🕌", ayah: "📖", proverb: "📜", wisdom: "💡" };
const letters = (t) => t.replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, "").length;
function textBody(t) {
  if (t.kind === "ayah") return `<span class="qr">﴿${esc(t.text)}﴾</span>`;
  return t.kind === "hadith" ? `«${esc(t.text)}»` : esc(t.text);
}
// البند 63: بطاقات الشاشة الرئيسية للبالغين، يختارها المدير (لوحة التحكم ← وضع التلفاز ← صفحة كل شخص).
// عمودان: الأيسر (48، عرض 340) والأوسط (404، عرض 460)، من 112 حتى 525. كل بطاقة تأخذ مكانها المفضّل، أو الآخر، أو لا تظهر.
function calendarCard() {
  const now = new Date(), occ = nextOccasions(1)[0];
  return `<div class="card glass hcal"><div class="hd2"><span class="emo">📅</span><div>
    <div class="lbl">${WEEK_AR[now.getDay()]} ${now.getDate()}</div>${fmtHijri ? `<b class="js-hj"></b>` : ""}</div></div>
    ${occ ? `<div class="occ">${occ.ic} ${occ.name}: <b>${occDays(occ.days)}</b></div>` : ""}</div>`;
}
function familyCard(f) {
  if (!f || (!f.birthdays.length && !f.stars.length)) return "";
  const bd = f.birthdays.map((b) => `<div>🎂 <b>${esc(b.name)}</b> ${b.in === 0 ? "اليوم! 🎉" : `${occDays(b.in)} (${b.age} ${b.age >= 3 && b.age <= 10 ? "سنوات" : "سنة"})`}</div>`).join("");
  const st = f.stars.length ? `<div>⭐ ${f.stars.map((s) => `<b>${esc(s.name)}</b> ${s.stars}`).join(" · ")}</div>` : "";
  return `<div class="card glass hfam"><div class="lbl">العائلة</div>${bd}${st}</div>`;
}
function memoryCard(m) {
  if (!m) return "";
  return `<div class="card glass hmem"><img src="/api/tv/media/${m.id}/thumb" alt="">
    <div class="cap">📸 في مثل هذا اليوم · ${m.ago === 1 ? "قبل سنة" : m.ago === 2 ? "قبل سنتين" : `قبل ${m.ago} ${m.ago <= 10 ? "سنوات" : "سنة"}`} (${m.year})</div></div>`;
}
function homeCards(d, hasPrayer) {
  const list = settings.home_cards || ["prayer", "text", "word"];
  const one = {
    prayer: () => (hasPrayer ? prayerCard(d.prayer, 0) : ""), text: () => textCard(d.text), word: () => wordCard(d.word, 0),
    calendar: calendarCard, family: () => familyCard(d.family), memory: () => memoryCard(d.memory),
  };
  return list.map((k) => (one[k] ? one[k]() : "").replace(/^<div class="/, `<div data-hk="${k}" style="visibility:hidden" class="`)).join("");
}
// الأماكن تُحسب بعد العرض من الطول الحقيقي لكل بطاقة: عمود أيسر وأوسط، وتحت الساعة مكان لبطاقة صغيرة
function layoutHome(box) {
  if (!box || !box.isConnected || box.closest("[hidden]")) return;
  const cols = { L: { x: 48, w: 340, y: 112, max: 999 }, C: { x: 404, w: 460, y: 112, max: 999 }, R: { x: 884, w: 350, y: 346, max: 150 } };
  for (const c of box.querySelectorAll("[data-hk]")) {
    const k = c.dataset.hk, pref = k === "text" ? ["C", "L"] : k === "memory" ? ["C", "L", "R"] : ["L", "C", "R"];
    let done = false;
    c.style.display = "";
    c.style.transition = "none";   // الوضع الخفيف يضع مدة انتقال لكل شيء، فيُقاس الطول القديم
    for (const n of pref) {
      const col = cols[n];
      c.style.left = `${col.x}px`; c.style.width = `${col.w}px`; c.style.top = `${col.y}px`;
      if (k === "memory") c.style.height = n === "C" ? "224px" : n === "L" ? "200px" : "150px";
      const hh = c.offsetHeight;
      if (hh <= col.max && col.y + hh <= 525) { col.y += hh + 14; done = true; break; }
    }
    c.style.visibility = done ? "" : "hidden";
    c.style.display = done ? "" : "none";
  }
}
function textCard(t, kids = false, cls = "", style = "") {
  if (!t) return "";
  const icon = TEXT_ICON[t.kind] || "✨";
  const long = letters(t.text) > (kids ? 42 : 55) ? " long" : "";
  return `<div class="tcard ${kids ? "kid" : "glass"} ${t.kind}${long} ${cls}"${style ? ` style="${style}"` : ""}><div class="lbl"><span class="emo">${icon}</span> ${esc(t.label)}</div>
    <div class="tx" translate="no">${textBody(t)}</div>
    ${t.source ? `<div class="src" translate="no">${esc(t.source)}</div>` : ""}${t.explain && (kids || t.kind === "proverb") ? `<div class="ex" translate="no">${esc(t.explain)}</div>` : ""}</div>`;
}

// صورة الشخص الحقيقية إن رُفعت، وإلا الرسم المختار
function face(p) {
  return p.photo_v ? `<img src="/api/users/${p.id}/photo?v=${p.photo_v}" alt="" style="width:100%;height:100%;object-fit:cover;display:block">` : A.avatar(p.avatar);
}

// ============================================================== من يشاهد؟
let qrReady = null;
function loadQR() {
  if (window.HSEF_QR) return Promise.resolve();
  qrReady = qrReady || ["/static/vendor/qrcode.js", "/static/js/qr.js"].reduce((p, src) => p.then(() => new Promise((res, rej) => {
    const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s);
  })), Promise.resolve());
  return qrReady;
}

async function whoScreen(boot = false) {
  stopBg();   // البند 62
  stopKidWatch();
  let d;
  try { d = await api("/api/tv/profiles"); } catch (e) { toast(e.message); return; }
  settings = d.settings || settings;
  applyPrefs();
  if (boot && d.current && d.profiles.some((p) => p.id === d.current)) return homeScreen();
  me = null;
  const cards = d.profiles.map((p) => {
    let sub = "";
    if (p.role === "kid" || p.role === "little") {
      if (p.birthday_today) sub = `<span class="chip">عيد ميلاد سعيد!</span>`;
      else if (p.birth_month) sub = `${A.cake(20)} ${esc(birthDM(p))}`;
      else if (p.role === "little") sub = `<span class="chip">وضع الأطفال</span>`;
    } else if (p.has_pin) sub = `<span style="display:flex">${A.LOCK}</span>`;
    const age = (p.role === "kid" || p.role === "little") && p.age != null ? `<div class="sub">عمري ${ageText(p.age)}</div>` : "";
    return `<button class="pf f" data-id="${p.id}"><div class="ring">${face(p)}</div>
      <div class="nm baloo">${esc(p.name)}</div><div class="pf-stars"><span class="emo">⭐</span> ${p.stars ?? 0}</div><div class="sub">${sub}</div>${age}</button>`;
  }).join("");
  setTheme("grape");
  const el = h(`<div class="who bg-night">${nightBg()}${vineLayer("grape")}
    <div class="topbar">${brand()}<div style="text-align:left"><div class="baloo js-tm" style="font-weight:700;font-size:34px;line-height:1;direction:ltr"></div><div class="js-dt" style="font-size:14px;color:#bfd3f2"></div></div></div>
    ${d.setup ? "" : "<h1>من يشاهد الآن؟</h1>"}
    ${d.setup ? `<div class="empty-who"><b style="font-size:30px;color:#fff">أهلاً بك في HOME ANAB!</b><br>لإنشاء حساب المدير افتح من هاتفك أو كمبيوترك:<br>
      ${d.setup.urls.map((u) => `<bdi dir="ltr"><b style="font-size:30px;color:#fde68a">${esc(u)}</b></bdi>`).join("<br>")}
      <div style="display:flex;gap:18px;align-items:center;justify-content:center;margin-top:18px"><span class="tv-qr" style="width:132px;height:132px;border-radius:12px;background:#fff;padding:4px;flex:none"><img src="/static/img/whatsapp-qr.png" alt="" style="width:100%;height:100%"></span>
      <span style="text-align:right">${d.setup.device ? `رقم هذا الجهاز: <bdi dir="ltr"><b style="font-size:30px;color:#fde68a;letter-spacing:1px">${esc(d.setup.device)}</b></bdi><br>
        تجربة مجانية ${d.setup.trial_days} يوماً. للتفعيل امسح الرمز وأرسل رقم الجهاز للبائع عبر واتساب<br>` : "للتواصل مع المطوّر عبر واتساب<br>"}<bdi dir="ltr"><b>+32 494 49 94 30</b></bdi></span></div></div>`
    : d.profiles.length ? `<div class="pf-wrap"><div class="profiles">${cards}</div><div class="pf-arrow r">›</div><div class="pf-arrow l">‹</div></div>` : `<div class="empty-who">لا توجد ملفات على التلفاز بعد.<br>من الكمبيوتر افتح لوحة التحكم ← <b>وضع التلفاز</b> واختر نوع كل مستخدم (بالغ أو طفل).</div>`}
    ${d.activation ? `<div class="act-note">${d.activation.state === "expired"
      ? (d.activation.was === "trial" ? "انتهت التجربة المجانية" : "انتهى تفعيل HOME ANAB") + ": كل شيء يعمل، لكن التحديثات متوقفة. جدّد من لوحة التحكم ← التفعيل"
      : `باقي ${d.activation.days_left} ${d.activation.days_left === 1 ? "يوم" : "أيام"} على انتهاء التفعيل. جدّد من لوحة التحكم ← التفعيل`}</div>` : ""}
    ${hints([["← →", "للتنقل"], ["موافق", "للدخول"]])}</div>`);
  if (d.setup && d.setup.whatsapp) {   // رمز QR فيه رقم الجهاز (يُرسم محلياً بدون إنترنت)
    loadQR().then(() => { const q = el.querySelector(".tv-qr"); if (q) { q.innerHTML = window.HSEF_QR(d.setup.whatsapp); const s = q.querySelector("svg"); if (s) { s.style.width = "100%"; s.style.height = "100%"; } } }).catch(() => {});
  }
  const byId = Object.fromEntries(d.profiles.map((p) => [String(p.id), p]));
  el.querySelectorAll(".pf").forEach((b) => b.addEventListener("click", () => chooseProfile(byId[b.dataset.id])));
  // شريط واحد يمرَّر يميناً ويساراً، مع سهمين عند وجود أشخاص خارج الشاشة
  const row = el.querySelector(".profiles");
  const arrows = () => {
    if (!row) return;
    const c = row.getBoundingClientRect(), cards = row.querySelectorAll(".pf");
    const xs = [...cards].map((x) => x.getBoundingClientRect());
    el.querySelector(".pf-arrow.l").classList.toggle("on", xs.some((r) => r.left < c.left - 2));
    el.querySelector(".pf-arrow.r").classList.toggle("on", xs.some((r) => r.right > c.right + 2));
  };
  row?.addEventListener("scroll", arrows);
  reset({ el, back() {}, refresh: null, onFocus: () => setTimeout(arrows, 350) });
  setTimeout(arrows, 50);
}

async function chooseProfile(p) {
  if (p.has_pin) {
    pinScreen({ title: `أهلاً ${nm(p.name)}`, sub: "أدخل رمزك", avatar: p.avatar, face: face(p) }, async (pin) => {
      await api("/api/tv/login", { json: { id: p.id, pin } });
      await homeScreen();
    });
    return;
  }
  try {
    await api("/api/tv/login", { json: { id: p.id } });
    await homeScreen();
  } catch (e) { toast(e.message); }
}

// ============================================================== الرمز
function pinScreen(opt, submit) {
  let pin = "";
  const keys = [1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<button class="key f" data-k="${n}">${n}</button>`).join("");
  const ava = opt.face ? `<div class="ava">${opt.face}</div>` : opt.avatar != null ? `<div class="ava">${A.avatar(opt.avatar)}</div>`
    : `<div class="ava" style="background:#facc15;display:flex;align-items:center;justify-content:center;color:#713f12">${A.LOCK.replace(/18/g, "96")}</div>`;
  const el = h(`<div class="bg-night">${nightBg()}
    <div class="pin-wrap"><div class="pin-who">${ava}<h2>${esc(opt.title)}</h2><p>${esc(opt.sub || "")}</p>
      <div class="dots"></div><div class="pin-err"></div></div>
      <div class="keypad">${keys}<button class="key f" data-k="del" aria-label="مسح">${A.BACKSP}</button><button class="key f" data-k="0">0</button>
      <button class="key ok f" data-k="ok" aria-label="دخول">${A.CHECK}</button></div></div>
    ${hints([["0-9", "الأرقام"], ["موافق", "اختيار"], ["رجوع", "إلغاء"]])}</div>`);
  const dots = el.querySelector(".dots"), err = el.querySelector(".pin-err");
  const draw = () => {
    const n = Math.max(4, pin.length);
    dots.innerHTML = Array.from({ length: n }, (_, i) => `<i class="${i < pin.length ? "on" : ""}"></i>`).join("");
  };
  let busy = false;
  const go = async () => {
    if (busy || pin.length < 4) { if (pin.length < 4) err.textContent = "الرمز 4 أرقام على الأقل"; return; }
    busy = true;
    try { await submit(pin); } catch (e) {
      err.textContent = e.message;
      dots.classList.remove("bad"); void dots.offsetWidth; dots.classList.add("bad");
      pin = ""; draw();
    } finally { busy = false; }
  };
  const press = (k) => {
    err.textContent = "";
    if (k === "del") pin = pin.slice(0, -1);
    else if (k === "ok") return go();
    else if (pin.length < 8) pin += k;
    draw();
    if (pin.length === 8) go();
  };
  el.querySelectorAll(".key").forEach((b) => b.addEventListener("click", () => press(b.dataset.k)));
  draw();
  push({
    el,
    initial: () => el.querySelector('[data-k="5"]'),
    key(e) {
      if (/^[0-9]$/.test(e.key)) { press(e.key); setFocus(el.querySelector('[data-k="ok"]')); return true; }
      if (e.key === "Backspace" && pin) { press("del"); return true; }
      return false;
    },
  });
}

// ============================================================== الرئيسية
async function homeScreen() {
  let d;
  try { d = await api("/api/tv/home"); } catch (e) { if (e.status !== 401) toast(e.message); return; }
  me = d;
  settings = d.settings || settings;
  applyPrefs();
  const scr = d.user.role === "adult" ? adultHome(d) : kidsHome(d);
  scr.home = true;
  reset(scr);
  startKidWatch();
}

// ============================================================== وقت الشاشة ووقت النوم (حسابات الأطفال)
// يضبطها الأهل من تطبيق «العائلة»: وقت شاشة يومي لكل طفل، ووقت نوم يُقفل فيه الحساب حتى الصباح،
// وتنبيه قبل 5 دقائق، و«وقت إضافي» 15 دقيقة برمز الأب أو الأم
let kidTimer = 0, kidWarned = {}, kidLocked = false;
function stopKidWatch() { clearInterval(kidTimer); kidTimer = 0; kidLocked = false; }
function startKidWatch() {
  stopKidWatch();
  kidWarned = {};
  if (!isKid()) return;
  const tickKid = async (beat) => {
    if (!isKid()) { stopKidWatch(); return; }
    if (document.hidden || saverEl) beat = false;   // شاشة التوقف لا تُحسب من وقت الشاشة
    let st;
    try { st = await api(beat ? "/api/tv/kid/beat" : "/api/tv/kid/status", beat ? { json: {} } : undefined); } catch { return; }
    kidStatus(st);
  };
  tickKid(false);
  kidTimer = setInterval(() => tickKid(true), 30000);
}
function kidStatus(st) {
  if (!st) return;
  if (st.locked) { if (!kidLocked) kidLockScreen(st); return; }
  kidLocked = false;
  if (st.warn && !kidWarned[st.warn]) {
    kidWarned[st.warn] = 1;
    toast(st.warn === "bed" ? "🌙 باقي 5 دقائق على وقت النوم" : "⏳ باقي 5 دقائق من وقت الشاشة اليوم", 9000);
  }
}
function kidLockScreen(st) {
  kidLocked = true;
  const bed = st.reason === "bed";
  const el = h(`<div class="bg-night kidlock">${nightBg()}
    <div class="kl"><div class="emo">${bed ? "🌙" : "⏳"}</div>
      <h1>${bed ? "حان وقت النوم" : "انتهى وقت الشاشة اليوم"}</h1>
      <p>${bed ? "تصبح على خير! نلتقي غداً صباحاً ☀️" : "أحسنت! حان وقت اللعب بعيداً عن الشاشة، أو القراءة، أو مساعدة ماما وبابا."}</p>
      <div class="kl-btns"><button class="btn f js-extra">⏱️ وقت إضافي (رمز الأب أو الأم)</button><button class="btn f js-switch">تبديل المستخدم</button></div></div></div>`);
  el.querySelector(".js-switch").addEventListener("click", () => { stopKidWatch(); leave(); });
  el.querySelector(".js-extra").addEventListener("click", () => pinScreen({ title: "رمز الأب أو الأم", sub: "15 دقيقة إضافية" }, async (pin) => {
    await api("/api/tv/kid/extra", { json: { pin } });
    kidLocked = false;
    toast("⏱️ 15 دقيقة إضافية", 4000);
    await homeScreen();
  }));
  reset({ el, back() {}, initial: () => el.querySelector(".js-extra") });
}

function adultHome(d) {
  const u = d.user;
  const wp = settings.wallpaper === "custom" && !(settings.walls || {}).adult ? "animated" : settings.wallpaper;
  const bgCls = { photos: "bg-photos", dark: "bg-night", cars: "bg-cars", islamic: "bg-islamic", custom: "bg-custom" }[wp] || "bg-sky";
  const bgHtml = wp === "photos" ? `<div class="layer photolayer"></div>` : wp === "dark" ? nightBg() : wp === "cars" ? carsBg()
    : wp === "islamic" ? islamicBg() : wp === "custom" ? customBg("adult") : skyBg();
  const dock = d.tiles.length ? d.tiles.map((t) => `<button class="dk f" data-id="${t.id}"><div class="ic" style="background:${A.gradient(t.color)}">${A.icon(t.icon)}${t.count ? `<b class="tcount">${t.count}</b>` : ""}</div><span>${esc(t.title)}</span></button>`).join("")
    : `<div class="dock-empty">أضف مربعات لهذا الحساب من لوحة التحكم ← وضع التلفاز</div>`;
  const setTile = `<button class="dk f js-stars"><div class="ic emo" style="background:linear-gradient(135deg,#fef3c7,#f59e0b)">⭐</div><span>النجوم <b class="js-sb"></b></span></button>`
    + `<button class="dk f js-chk"><div class="ic emo" style="background:linear-gradient(135deg,#dcfce7,#22c55e)">✅</div><span>مهام الأطفال <b class="js-chn"></b></span></button>`
    + `<button class="dk f js-theme"><div class="ic emo" style="background:linear-gradient(135deg,#faf5ff,#e9d5ff)">${F.themeOf(u.theme).emoji}</div><span>ثيمي</span></button>`
    + (u.admin ? `<button class="dk f js-settings"><div class="ic" style="background:linear-gradient(135deg,#64748b,#1e293b)">${GEAR}</div><span>الإعدادات</span></button>` : "");
  const hasPrayer = d.prayer && settings.prayer;
  setTheme(u.theme);
  const el = h(`<div class="${bgCls}">${bgHtml}${vineLayer(u.theme, [490, 620, 750])}
    <div class="topbar"><div style="display:flex;align-items:center;gap:12px">${F.GRAPE(54)}
      <div class="user-pill glass"><div class="mini">${face(u)}</div><span style="font-weight:700;font-size:16px">${esc(u.name)}</span></div></div>
      <button class="pill glass f js-switch">تبديل المستخدم</button></div>
    <div class="clockbig"><div class="tm js-tm"></div><div class="dt js-dt"></div><div class="hj js-hj"></div><div class="wx js-wx">${weatherLine(d.weather)}</div></div>
    <div class="cards">${homeCards(d, hasPrayer)}</div>
    <nav class="dock glass">${dock}${setTile}</nav></div>`);
  const tiles = Object.fromEntries(d.tiles.map((t) => [String(t.id), t]));
  el.querySelector(".js-settings")?.addEventListener("click", settingsScreen);
  el.querySelector(".js-theme").addEventListener("click", themeScreen);
  el.querySelector(".js-stars").addEventListener("click", starsScreen);
  el.querySelector(".js-chk").addEventListener("click", choresConfirmScreen);
  fillBalance(el);
  let lastPending = -1;
  const fillPending = async () => {   // رقم أحمر بعدد المهام التي تنتظر التأكيد، وتنبيه عند مهمة جديدة
    let r;
    try { r = await api("/api/tv/chores/pending"); } catch { return; }
    const b = el.querySelector(".js-chn");
    b.textContent = r.count ? r.count : "";
    b.classList.toggle("badge", r.count > 0);
    if (lastPending >= 0 && r.count > lastPending && r.items[0]) toast(`🧹 ${nm(r.items[0].kid)} أنهى: ${r.items[0].title} (تنتظر تأكيدك)`, 7000);
    lastPending = r.count;
  };
  fillPending();
  const pendTimer = setInterval(fillPending, 60000);
  el.querySelectorAll(".dk[data-id]").forEach((b) => b.addEventListener("click", () => openTile(tiles[b.dataset.id])));
  el.querySelector(".js-switch").addEventListener("click", leave);
  const scr = {
    el,
    initial: () => el.querySelector(".dk"),
    back: () => setFocus(el.querySelector(".js-switch")),
    onShow: () => { fillBalance(el); fillPending(); layoutHome(el.querySelector(".cards")); },
    destroy: () => clearInterval(pendTimer),
    refresh(c) {
      d.prayer = c.prayer;
      el.querySelector(".cards").innerHTML = homeCards(d, hasPrayer);
      layoutHome(el.querySelector(".cards")); tick();
      el.querySelector(".js-wx").innerHTML = weatherLine(c.weather);
    },
  };
  if (wp === "photos") photoWallpaper(el.querySelector(".photolayer"), scr);
  requestAnimationFrame(() => layoutHome(el.querySelector(".cards")));
  setTimeout(() => layoutHome(el.querySelector(".cards")), 300);   // بعد تحميل الخطوط
  return scr;
}

async function photoWallpaper(layer, scr) {
  let ids = [];
  try { ids = (await api("/api/tv/wallpaper")).ids; } catch { return; }
  if (!ids.length) { layer.innerHTML = skyBg(); layer.parentElement.classList.add("bg-sky"); return; }
  let i = 0, timer = 0;
  const a = h(`<div class="ph"></div>`), b = h(`<div class="ph"></div>`);
  layer.append(a, b);
  let front = a;
  const show = () => {
    const next = front === a ? b : a;
    const img = new Image();
    img.onload = () => {
      next.style.backgroundImage = `url("${img.src}")`;
      next.classList.add("show");
      front.classList.remove("show");
      front = next;
    };
    img.src = `/api/tv/photo/${ids[i++ % ids.length]}/view`;
  };
  show();
  timer = setInterval(show, 20000);
  const prev = scr.destroy;
  scr.destroy = () => { clearInterval(timer); prev?.(); };
}

function kidsHome(d) {
  const u = d.user;
  const n = d.tiles.length;
  const perRow = n <= 4 ? Math.max(n, 1) : n <= 8 ? 4 : n <= 10 ? 5 : 6;
  const rows = Math.ceil(Math.max(n, 1) / perRow);
  const avail = 344;
  const rowH = Math.min(210, (avail - (rows - 1) * 14) / rows);
  const boxH = Math.round(rowH - 40);
  const boxW = Math.round(Math.min(250, (1200 - (perRow - 1) * 26) / perRow, boxH * 1.75));
  const tiles = n ? d.tiles.map((t) => `<button class="kt f" data-id="${t.id}"><div class="box" style="--w:${boxW}px;--h:${boxH}px;background:${A.gradient(t.color)}">${A.icon(t.icon)}${t.count ? `<b class="tcount">${t.count}</b>` : ""}</div>
      <div class="lb">${esc(t.title)}</div></button>`).join("")
    : `<div style="font-size:24px;font-weight:700;color:#1e3a8a;text-align:center">لا يوجد شيء هنا بعد.<br>اطلب من ماما أو بابا إضافة المربعات.</div>`;
  let bday = "";
  if (u.birthday_today) {
    bday = `<div class="kcard bday">${A.cake(64)}<div><div class="big">عيد ميلاد سعيد!</div><div class="info">صار عمري ${ageText(u.age)} 🎈</div></div></div>`;
  } else if (u.birth_month) {
    bday = `<div class="kcard bday">${A.cake(56)}<div><div class="lbl">عيد ميلادي</div><div class="big">${esc(birthDM(u))}</div>
      <div class="info">عمري ${ageText(u.age)} · ${AR ? `باقي ${daysText(u.birthday_in)}` : new Intl.RelativeTimeFormat(LOC).format(u.birthday_in, "day")}</div></div></div>`;
  }
  const confetti = u.birthday_today ? `<div class="confetti">${Array.from({ length: 40 }, (_, i) =>
    `<i style="left:${(i * 37) % 100}%;background:${["#f43f5e", "#facc15", "#22c55e", "#3b82f6", "#a855f7"][i % 5]};animation-duration:${4 + (i % 5)}s;animation-delay:-${(i * 0.7) % 6}s"></i>`).join("")}</div>` : "";
  const greet = u.birthday_today ? `عيد ميلاد سعيد يا ${nm(esc(u.name))}!` : `مرحباً يا ${nm(esc(u.name))}!`;
  const exitTxt = "تبديل المستخدم";
  setTheme(u.theme);
  const kw = settings.kids_wallpaper === "custom" && !(settings.walls || {}).kids ? "garden" : settings.kids_wallpaper;
  const kBg = kw === "cars" ? ["kcars", carsBg(true)] : kw === "islamic" ? ["kislamic", islamicBg(true)] : kw === "custom" ? ["kcustom", customBg("kids")] : ["", kidsBg()];
  const el = h(`<div class="kids bg-kids ${kBg[0]}">${kBg[1]}${vineLayer(u.theme, [480, 610])}${confetti}
    <div class="mascot">${F.mascot(u.theme, 150)}</div>
    <div class="kgreet"><div class="h">${greet}</div><div class="s">ماذا نشاهد اليوم؟</div></div>
    <div class="kclock"><div class="tm js-tm"></div><div class="dt js-dt"></div><div class="wx js-wx">${weatherLine(d.weather)}</div></div>
    ${bday}<div class="kwords">${wordCard(d.word, 180, true)}</div>${textCard(d.text, true)}
    <div class="ktiles">${tiles}</div>
    <button class="kexit f">${exitTxt}</button>
    <div class="kbar"><button class="kstars f"><span class="emo">⭐</span> نجومي <b class="js-sb"></b></button><button class="ktheme f"><span class="emo">${F.themeOf(u.theme).emoji}</span> ثيمي</button></div>
    <div class="knote">${u.role === "little" ? "" : "فقط ما اختاره ماما وبابا"}</div></div>`);
  const byId = Object.fromEntries(d.tiles.map((t) => [String(t.id), t]));
  el.querySelectorAll(".kt").forEach((b) => b.addEventListener("click", () => openTile(byId[b.dataset.id])));
  el.querySelector(".kexit").addEventListener("click", leave);
  el.querySelector(".ktheme").addEventListener("click", themeScreen);
  el.querySelector(".kstars").addEventListener("click", starsScreen);
  fillBalance(el);
  return {
    el,
    initial: () => el.querySelector(".kt"),
    back() {},
    onShow: () => fillBalance(el),
    refresh(c) { el.querySelector(".js-wx").innerHTML = weatherLine(c.weather); },
  };
}

async function leave() {
  try { await api("/api/tv/leave", { json: {} }); } catch (e) { toast(e.message); return; }
  whoScreen();
}

// ============================================================== تصفح المربعات
function openTile(t) {
  if (t.kind === "photos") photosScreen(t);
  else if (t.kind === "cameras") camerasScreen(t);
  else if (t.kind === "chores") choresScreen(t);
  else if (t.kind === "ramadan") ramadanScreen(t);
  else if (t.kind === "stories") storiesScreen(t);
  else if (t.kind === "onthisday") onThisDayScreen(t);
  else if (t.kind === "messages") appScreen("/tv/letters/", "الرسائل");   // البند 46
  else browseScreen(t, "");
}
const isKid = () => me && me.user.role !== "adult";
const fileUrl = (t, p) => `/api/tv/tile/${t.id}/file?p=${encodeURIComponent(p)}`;
const thumbUrl = (t, p) => `/api/tv/tile/${t.id}/thumb?p=${encodeURIComponent(p)}`;
const vinfoUrl = (t, p) => `/api/tv/tile/${t.id}/vinfo?p=${encodeURIComponent(p)}`;
// فيديو الآيفون (HEVC) وغيره: يسأل السيرفر هل يُشغَّل كما هو أم يحتاج تحويلاً، وينتظر التحويل مع عرض التقدم
const PREP = `<div class="prep" hidden><div class="spin"></div><b>جارٍ تجهيز الفيديو للتلفاز…</b><span class="pp"></span>
  <small>فيديو الآيفون يُحوَّل مرة واحدة فقط، ثم يعمل فوراً في كل مرة</small></div>`;
async function videoSource(infoUrl, directUrl, alive, prep) {
  for (;;) {
    let r;
    try { r = await api(infoUrl); } catch { return directUrl; }
    if (!alive()) return undefined;
    if (r.mode === "direct") { prep.hidden = true; return directUrl; }
    if (r.mode === "ready") { prep.hidden = true; return r.url; }
    if (r.mode === "error") { prep.hidden = true; return null; }
    prep.hidden = false;
    prep.querySelector(".pp").textContent = r.position > 1 ? `في الانتظار: قبله ${r.position - 1}` : `${r.progress || 0}%`;
    await new Promise((res) => setTimeout(res, 2000));
    if (!alive()) return undefined;
  }
}

function header(t, title, crumb, extra = "") {
  return `<div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>${crumb ? "رجوع" : "الرئيسية"}</span></button>
    <div class="ti" style="background:${A.gradient(t.color)}">${A.icon(t.icon)}</div><h1>${esc(title)}</h1>
    ${crumb ? `<span class="crumb">${esc(crumb)}</span>` : ""}<div class="sp"></div>${extra}</div>`;
}
function folderLabel(t) {
  const who = me?.user?.name || "";
  return (t.path || "").replace(/^\/home\b/, who);
}

async function browseScreen(t, sub) {
  let d;
  try { d = await api(`/api/tv/tile/${t.id}/list?sub=${encodeURIComponent(sub)}`); } catch (e) { toast(e.message); return; }
  const items = d.items;
  const media = items.filter((x) => x.type === "video" || x.type === "audio");
  const extra = media.length > 1 ? `<button class="btn gold f js-all">${A.PLAY}تشغيل الكل</button>` : "";
  const kid = isKid();
  const grad = A.gradient(t.color);
  const cards = items.map((x, i) => {
    const p = joinp(sub, x.name);
    let th;
    if (x.type === "video" || x.type === "image") {
      th = `<img loading="lazy" src="${thumbUrl(t, p)}" alt="">${x.type === "video" ? `<span class="tag">${A.PLAY}</span>` : ""}`;
    } else if (x.type === "folder" || x.type === "game") {
      th = x.cover ? `<img loading="lazy" src="${fileUrl(t, x.self ? joinp(sub, x.cover) : joinp(p, x.cover))}" alt="">` : A.icon(x.type === "game" ? "games" : "folder");
    } else if (x.type === "pdf") {
      th = `<img loading="lazy" src="/api/tv/tile/${t.id}/page?p=${encodeURIComponent(p)}&n=1" alt="" style="object-fit:contain;background:#fff">`;
    } else th = A.icon("audio");
    const bg = x.type === "folder" || x.type === "game" || x.type === "audio" ? `style="background:${grad}"` : "";
    const nm = x.self ? "▶ العب" : x.type === "folder" || x.type === "game" ? x.name : x.name.replace(/\.[^.]+$/, "");
    return `<button class="it f" data-i="${i}"><div class="th" ${bg}>${th}</div><div class="nm">${esc(nm)}</div></button>`;
  }).join("");
  const emptyMsg = kid ? "لا يوجد شيء هنا بعد.<br>اطلب من ماما أو بابا أن يضعوا لك أشياء جميلة 🌟" : "هذا المجلد فارغ.<br>ضع الملفات فيه من الكمبيوتر أو الهاتف:";
  const el = h(`<div class="${kid ? "bg-kidsdark" : "bg-dark"}" style="--glow1:${t.color ? t.color.split(",")[0] + "55" : ""}">
    ${header(t, t.title, sub, extra)}
    ${items.length ? `<div class="grid-wrap ${kid ? "kidgrid" : ""}"><div class="grid" style="--cols:${kid ? 4 : 5}">${cards}</div></div>`
      : `<div class="empty">${A.icon(t.icon)}<div>${emptyMsg}</div><div class="path ltr">${esc(folderLabel(t) + (sub ? "/" + sub : ""))}</div></div>`}
    ${hints([["موافق", "تشغيل"], ["رجوع", sub ? "المجلد السابق" : "الرئيسية"]])}</div>`);
  el.querySelector(".js-back").addEventListener("click", pop);
  el.querySelector(".js-all")?.addEventListener("click", () => {
    const vids = media.filter((x) => x.type === "video");
    if (vids.length) videoScreen(t, vids.map((x) => joinp(sub, x.name)), 0);
    else audioScreen(t, media.map((x) => joinp(sub, x.name)), 0);
  });
  el.querySelectorAll(".it").forEach((b) => b.addEventListener("click", () => {
    const x = items[+b.dataset.i];
    const p = joinp(sub, x.name);
    if (x.type === "folder") browseScreen(t, p);
    else if (x.type === "game") gameScreen(t, x.self ? sub : joinp(p, x.entry || ""));
    else if (x.type === "pdf") bookScreen(t, p);
    else {
      const same = items.filter((y) => y.type === x.type);
      const idx = same.indexOf(x);
      const paths = same.map((y) => joinp(sub, y.name));
      if (x.type === "video") videoScreen(t, paths, idx);
      else if (x.type === "audio") audioScreen(t, paths, idx);
      else viewerScreen(paths.map((q) => ({ src: fileUrl(t, q), name: q.split("/").pop().replace(/\.[^.]+$/, "") })), idx);
    }
  }));
  push({ el, initial: () => el.querySelector(".it") || el.querySelector(".js-back") });
}

// ============================================================== الفيديو
function videoScreen(t, paths, idx) {
  stopBg();   // البند 62
  const el = h(`<div class="player"><video autoplay playsinline></video>${PREP}
    <div class="bigplay" hidden>${A.PAUSE}</div><div class="counter"></div>
    <div class="osd"><div class="tt"></div><div class="bar"><i></i></div><div class="row"><span class="ct">0:00</span><span class="du">0:00</span></div>
    <div class="keys"><span><b>موافق</b>إيقاف/تشغيل</span><span><b>← →</b>ترجيع/تقديم</span><span><b>↑ ↓</b>الصوت</span><span><b>M</b>كتم</span><span><b>⏮ ⏭</b>السابق/التالي</span><span><b>رجوع</b>خروج</span></div></div></div>`);
  const v = el.querySelector("video"), osd = el.querySelector(".osd"), bar = el.querySelector(".bar i");
  const big = el.querySelector(".bigplay"), counter = el.querySelector(".counter");
  const fmt = (s) => (isFinite(s) ? `${Math.floor(s / 60)}:${pad(Math.floor(s % 60))}` : "0:00");
  let hideT = 0;
  const showOsd = () => {
    osd.classList.remove("hide"); counter.style.opacity = 1;
    clearTimeout(hideT);
    hideT = setTimeout(() => { if (!v.paused) { osd.classList.add("hide"); counter.style.opacity = 0; } }, 3500);
  };
  let loadTok = 0;
  const load = async (i) => {
    idx = i;
    const tok = ++loadTok;
    v.removeAttribute("src"); v.load();
    el.querySelector(".tt").textContent = paths[i].split("/").pop().replace(/\.[^.]+$/, "");
    counter.textContent = paths.length > 1 ? `${i + 1} / ${paths.length}` : "";
    showOsd();
    const src = await videoSource(vinfoUrl(t, paths[i]), fileUrl(t, paths[i]), () => tok === loadTok && el.isConnected, el.querySelector(".prep"));
    if (src === undefined) return;
    if (!src) { toast("تعذر تجهيز هذا الفيديو للتلفاز"); setTimeout(next, 2500); return; }
    v.src = src;
    v.play().catch(() => {});
  };
  const next = () => (idx + 1 < paths.length ? load(idx + 1) : pop());
  v.addEventListener("timeupdate", () => {
    bar.style.width = `${(v.currentTime / v.duration) * 100 || 0}%`;
    el.querySelector(".ct").textContent = fmt(v.currentTime);
    el.querySelector(".du").textContent = fmt(v.duration);
  });
  v.addEventListener("play", () => { big.hidden = true; showOsd(); });
  v.addEventListener("pause", () => { if (!v.ended) { big.hidden = false; showOsd(); } });
  v.addEventListener("ended", next);
  v.addEventListener("error", () => { toast("لا يمكن تشغيل هذا الملف على التلفاز"); setTimeout(next, 2500); });
  v.addEventListener("click", () => (v.paused ? v.play() : v.pause()));
  push({
    el,
    busy: () => !v.paused,
    destroy() { clearTimeout(hideT); v.pause(); v.removeAttribute("src"); v.load(); },
    key(e) {
      const k = e.key;
      if (k === "Enter" || k === " " || k === "MediaPlayPause") { v.paused ? v.play() : v.pause(); return true; }
      if (k === "ArrowRight" || k === "MediaFastForward") { v.currentTime = Math.min(v.duration || 0, v.currentTime + 10); showOsd(); return true; }
      if (k === "ArrowLeft" || k === "MediaRewind") { v.currentTime = Math.max(0, v.currentTime - 10); showOsd(); return true; }
      if (k === "ArrowUp") { volUp(); return true; }
      if (k === "ArrowDown") { volDown(); return true; }
      if (k === "MediaTrackNext" || k === "PageDown") { if (idx + 1 < paths.length) load(idx + 1); else showOsd(); return true; }
      if (k === "MediaTrackPrevious" || k === "PageUp") { if (idx > 0) load(idx - 1); else { v.currentTime = 0; showOsd(); } return true; }
      return false;
    },
  });
  load(idx);
}

// ============================================================== الصوتيات (أناشيد، قرآن، تسجيلات)
// أربع طرق عرض (تُحفظ لكل مربع): قائمة، أسطوانة دوّارة، موجات صوتية، شاشة كبيرة. مع تكرار وتشغيل عشوائي
const AUDIO_VIEWS = [["list", "📋", "قائمة"], ["vinyl", "💿", "أسطوانة"], ["waves", "🌊", "موجات"], ["big", "🖥️", "شاشة كبيرة"]];
// البند 62: الموسيقى تستمر بعد الخروج من تطبيق الصوت، مع إشعار صغير أعلى الشاشة.
// تتوقف عند فتح فيديو أو لعبة أو تطبيق أو كاميرا أو قصة، أو تبديل المستخدم. والضغط على الإشعار (أو فتح المربع نفسه) يرجع إلى المشغّل.
let bgPlay = null;
function stopBg() {
  if (!bgPlay) return;
  const b = bgPlay; bgPlay = null;
  clearInterval(b.timer);
  try { b.au.pause(); b.au.removeAttribute("src"); b.au.load(); } catch { /* */ }
  b.au.remove(); b.pill.remove();
}
function startBg(t, paths, au, cur, reopen) {
  stopBg();
  const pill = h(`<button class="bgmusic" aria-label="الموسيقى قيد التشغيل"><span class="eq"><i></i><i></i><i></i></span><span class="tt"></span><b class="st"></b></button>`);
  const draw = () => {
    pill.querySelector(".tt").textContent = cur();
    pill.querySelector(".st").textContent = au.paused ? "⏸ متوقفة" : "🎵 قيد التشغيل";
    pill.classList.toggle("paused", au.paused);
  };
  au.hidden = true;
  stage.appendChild(au); stage.appendChild(pill);
  bgPlay = { t, au, pill, timer: setInterval(draw, 1000), reopen };
  pill.addEventListener("click", () => { const r = bgPlay?.reopen; if (r) r(); });
  draw();
  toast("🎵 الموسيقى مستمرة. افتح المربع نفسه للتحكم بها");
}
document.addEventListener("keydown", (e) => {
  if (!bgPlay) return;
  if (e.key === "MediaPlayPause" && !top()?.busy?.()) { bgPlay.au.paused ? bgPlay.au.play().catch(() => {}) : bgPlay.au.pause(); }
  else if (e.key === "MediaStop") stopBg();
});

function audioScreen(t, paths, idx) {
  // نفس المربع والموسيقى مستمرة: نكمل من حيث وصلت
  const resume = bgPlay && bgPlay.t.id === t.id && bgPlay.paths?.join("\n") === paths.join("\n") ? { i: bgPlay.idx(), at: bgPlay.au.currentTime } : null;
  if (resume) idx = resume.i;
  stopBg();
  const names = paths.map((p) => p.split("/").pop().replace(/\.[^.]+$/, ""));
  const vkey = `hsef-aview-${t.id}`;
  let view = "list", repeat = "all", shuffle = false;
  try { view = localStorage.getItem(vkey) || "list"; repeat = localStorage.getItem("hsef-arep") || "all"; shuffle = localStorage.getItem("hsef-ashuf") === "1"; } catch { /* */ }
  const list = names.map((n, i) => `<button class="trk f" data-i="${i}"><span class="n">${i + 1}</span><span class="x">${esc(n)}</span></button>`).join("");
  const c1 = (t.color || "#a855f7,#ec4899").split(",")[0];
  const el = h(`<div class="bg-dark audio" style="--glow1:${c1}66;--ac:${c1}">
    ${header(t, t.title, "")}
    <div class="cover" style="background:${A.gradient(t.color)}">${A.icon(t.icon)}</div>
    <div class="vinyl"><div class="disc"><div class="lbl" style="background:${A.gradient(t.color)}">${A.icon(t.icon)}</div></div><div class="arm"></div></div>
    <canvas class="waves" width="1280" height="420"></canvas>
    <div class="bigtt"></div>
    <div class="now"><div class="tt"></div><div class="bar"><i></i></div><div class="tms"><span class="cur">0:00</span><span class="dur"></span></div>
      <div class="vbtns"><button class="btn f js-vd">${VOL_ICON(false).replace(/34/g, "24")} −</button><button class="btn f js-vm">${VOL_ICON(true).replace(/34/g, "24")}</button><button class="btn f js-vu">${VOL_ICON(false).replace(/34/g, "24")} +</button></div>
      <div class="vbtns"><button class="btn f js-view"></button><button class="btn f js-rep"></button><button class="btn f js-shuf"></button></div></div>
    <div class="list">${list}</div><audio autoplay preload="auto"></audio>
    ${hints([["موافق", "تشغيل"], ["+ −", "الصوت"], [faceIcon("up"), "طريقة العرض"], [faceIcon("left"), "تكرار"], ["رجوع", "خروج"]])}</div>`);
  const au = el.querySelector("audio"), bar = el.querySelector(".now .bar i"), cover = el.querySelector(".cover");
  const fmt = (x) => (isFinite(x) ? `${Math.floor(x / 60)}:${pad(Math.floor(x % 60))}` : "");
  const save = () => { try { localStorage.setItem(vkey, view); localStorage.setItem("hsef-arep", repeat); localStorage.setItem("hsef-ashuf", shuffle ? "1" : "0"); } catch { /* */ } };
  // الموجات: محلّل الصوت يُنشأ مرة واحدة عند أول عرض لها
  let an = null, stopWaves = null;
  const startWaves = () => {
    if (stopWaves) return;
    try {
      if (!an) {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const src = ctx.createMediaElementSource(au);
        an = ctx.createAnalyser(); an.fftSize = 128;
        src.connect(an); an.connect(ctx.destination);
        au.addEventListener("play", () => ctx.resume().catch(() => {}));
      }
    } catch { an = null; }
    const cv = el.querySelector("canvas.waves"), g = cv.getContext("2d");
    const data = new Uint8Array(64);
    stopWaves = frameLoop((dt, ts) => {
      g.clearRect(0, 0, 1280, 420);
      if (an) an.getByteFrequencyData(data);
      const n = 48, w = 1280 / n;
      for (let i = 0; i < n; i++) {
        const v = an && !au.paused ? data[Math.min(63, Math.floor(i * 1.2))] / 255 : 0.08 + 0.05 * Math.sin(ts * 2 + i / 3);
        const hh = Math.max(6, v * 380);
        g.fillStyle = `hsla(${(i * 7 + ts * 20) % 360}, 85%, 62%, .9)`;
        g.beginPath(); g.roundRect?.(i * w + 4, 210 - hh / 2, w - 8, hh, 8); g.fill();
      }
    }, 30);
  };
  const setView = (v) => {
    view = AUDIO_VIEWS.some(([k]) => k === v) ? v : "list";
    el.dataset.view = view;
    const [, ic, lb] = AUDIO_VIEWS.find(([k]) => k === view);
    el.querySelector(".js-view").textContent = `${ic} ${lb}`;
    if (view === "waves") startWaves(); else if (stopWaves) { stopWaves(); stopWaves = null; }
    save();
  };
  const drawModes = () => {
    el.querySelector(".js-rep").textContent = repeat === "one" ? "🔂 تكرار المقطع" : repeat === "all" ? "🔁 تكرار الكل" : "➡️ بلا تكرار";
    el.querySelector(".js-shuf").textContent = shuffle ? "🔀 عشوائي" : "⏭️ بالترتيب";
    el.querySelector(".js-shuf").classList.toggle("on", shuffle);
    save();
  };
  const load = (i) => {
    idx = i;
    au.src = fileUrl(t, paths[i]);
    au.play().catch(() => {});
    el.querySelector(".now .tt").textContent = names[i];
    el.querySelector(".bigtt").textContent = names[i];
    el.querySelectorAll(".trk").forEach((b) => b.classList.toggle("cur", +b.dataset.i === i));
  };
  const nextIdx = () => {
    if (repeat === "one") return idx;
    if (shuffle && paths.length > 1) { let j; do { j = Math.floor(Math.random() * paths.length); } while (j === idx); return j; }
    return idx + 1 < paths.length ? idx + 1 : repeat === "all" ? 0 : -1;
  };
  au.addEventListener("timeupdate", () => {
    bar.style.width = `${(au.currentTime / au.duration) * 100 || 0}%`;
    el.querySelector(".tms .cur").textContent = fmt(au.currentTime);
    el.querySelector(".tms .dur").textContent = fmt(au.duration);
  });
  au.addEventListener("play", () => { cover.classList.add("playing"); el.classList.add("playing"); });
  au.addEventListener("pause", () => { cover.classList.remove("playing"); el.classList.remove("playing"); });
  au.addEventListener("ended", () => { const j = nextIdx(); if (j >= 0) load(j); });
  au.addEventListener("error", () => { toast("لا يمكن تشغيل هذا الملف"); if (idx + 1 < paths.length) setTimeout(() => load(idx + 1), 1500); });
  // الخروج بزر «رجوع»: إن كان الصوت يعمل يستمر في الخلفية
  let keep = false;
  const leave = () => { keep = !au.paused; pop(); };
  el.querySelector(".js-back").addEventListener("click", leave);
  el.querySelector(".js-vd").addEventListener("click", volDown);
  el.querySelector(".js-vu").addEventListener("click", volUp);
  el.querySelector(".js-vm").addEventListener("click", volMute);
  el.querySelector(".js-view").addEventListener("click", () => { const i = AUDIO_VIEWS.findIndex(([k]) => k === view); setView(AUDIO_VIEWS[(i + 1) % AUDIO_VIEWS.length][0]); });
  el.querySelector(".js-rep").addEventListener("click", () => { repeat = { all: "one", one: "none", none: "all" }[repeat] || "all"; drawModes(); });
  el.querySelector(".js-shuf").addEventListener("click", () => { shuffle = !shuffle; drawModes(); });
  el.querySelectorAll(".trk").forEach((b) => b.addEventListener("click", () => {
    const i = +b.dataset.i;
    if (i === idx) (au.paused ? au.play() : au.pause()); else load(i);
  }));
  push({
    el,
    initial: () => (view === "list" ? el.querySelector(`.trk[data-i="${idx}"]`) : el.querySelector(".js-view")),
    busy: () => !au.paused,
    back: leave,
    destroy() {
      stopWaves?.();
      if (keep) {
        startBg(t, paths, au, () => names[idx], () => { if (bgPlay) audioScreen(t, paths, idx); });
        bgPlay.paths = paths; bgPlay.idx = () => idx;
        return;
      }
      au.pause(); au.removeAttribute("src"); au.load();
    },
    key(e) {
      if (e.key === " " || e.key === "MediaPlayPause") { au.paused ? au.play() : au.pause(); return true; }
      if (e.key === "v" || e.key === "V" || e.key === "ContextMenu") { el.querySelector(".js-view").click(); return true; }
      if (e.key === "F2") { el.querySelector(".js-rep").click(); return true; }
      if (e.key === "MediaTrackNext") { const j = nextIdx(); if (j >= 0) load(j); return true; }
      if (e.key === "MediaTrackPrevious" && idx > 0) { load(idx - 1); return true; }
      return false;
    },
  });
  setView(view);
  drawModes();
  load(idx);
  if (resume && resume.at > 1) au.addEventListener("loadedmetadata", () => { try { au.currentTime = resume.at; } catch { /* */ } }, { once: true });
}

// ============================================================== عارض الصور وعرض الشرائح
function viewerScreen(items, idx, slideshow = false) {
  const el = h(`<div class="player"><div class="pimg"></div><div class="pimg"></div><video playsinline style="display:none"></video>${PREP}
    <div class="counter"></div>
    <div class="osd hide"><div class="tt"></div><div class="keys"><span><b>← →</b>التالي/السابق</span><span><b>موافق</b>عرض شرائح</span><span><b>رجوع</b>خروج</span></div></div></div>`);
  const [l1, l2] = el.querySelectorAll(".pimg");
  const v = el.querySelector("video"), counter = el.querySelector(".counter"), osd = el.querySelector(".osd");
  let front = l1, timer = 0, hideT = 0, playing = slideshow, showTok = 0;
  const showOsd = (ms = 3000) => { osd.classList.remove("hide"); counter.style.opacity = 1; clearTimeout(hideT); hideT = setTimeout(() => { osd.classList.add("hide"); if (playing) counter.style.opacity = 0; }, ms); };
  const schedule = () => { clearTimeout(timer); if (playing && !items[idx].video) timer = setTimeout(() => go(1), 6500); };
  const show = (i) => {
    idx = (i + items.length) % items.length;
    const it = items[idx];
    counter.textContent = `${idx + 1} / ${items.length}`;
    el.querySelector(".tt").textContent = it.name || "";
    const tok = ++showTok;
    if (it.video) {
      l1.classList.remove("show"); l2.classList.remove("show");
      v.style.display = ""; v.removeAttribute("src"); v.load();
      clearTimeout(timer);
      (it.info ? videoSource(it.info, it.src, () => tok === showTok && el.isConnected, el.querySelector(".prep")) : Promise.resolve(it.src)).then((src) => {
        if (src === undefined) return;
        if (!src) { toast("تعذر تجهيز هذا الفيديو للتلفاز"); return; }
        v.src = src; v.play().catch(() => {});
      });
      return;
    }
    el.querySelector(".prep").hidden = true;
    v.pause(); v.style.display = "none";
    const next = front === l1 ? l2 : l1;
    const img = new Image();
    img.onload = () => {
      next.style.background = `#000 url("${img.src}") center/contain no-repeat`;
      next.classList.remove("kb"); void next.offsetWidth;
      if (playing) next.classList.add("kb");
      next.classList.add("show"); front.classList.remove("show"); front = next;
      schedule();
      const pre = items[(idx + 1) % items.length];
      if (pre && !pre.video) new Image().src = pre.src;
    };
    img.onerror = () => { if (playing) timer = setTimeout(() => go(1), 1000); };
    img.src = it.src;
  };
  const go = (d) => show(idx + d);
  v.addEventListener("ended", () => { if (playing) go(1); });
  push({
    el,
    busy: () => playing || !v.paused,
    destroy() { clearTimeout(timer); clearTimeout(hideT); v.pause(); },
    key(e) {
      const k = e.key;
      if (k === NEXT_KEY) { go(1); showOsd(); return true; }
      if (k === PREV_KEY) { go(-1); showOsd(); return true; }
      if (k === "Enter" || k === " " || k === "MediaPlayPause") {
        if (items[idx].video && !playing) { v.paused ? v.play() : v.pause(); return true; }
        playing = !playing; toast(playing ? "عرض الشرائح" : "إيقاف عرض الشرائح", 1500); schedule(); return true;
      }
      if (k === "ArrowUp") { if (items[idx].video) volUp(); else showOsd(); return true; }
      if (k === "ArrowDown") { if (items[idx].video) volDown(); else showOsd(); return true; }
      return false;
    },
  });
  show(idx);
  showOsd();
}

// ============================================================== مكتبة الصور
async function photosScreen(t) {
  let items = [], nextOff = 0;
  const load = async () => {
    const d = await api(`/api/tv/photos?offset=${nextOff}`);
    items = items.concat(d.items);
    nextOff = d.next;
    return d.items;
  };
  try { await load(); } catch (e) { toast(e.message); return; }
  const fmtMonth = new Intl.DateTimeFormat(`${LOC}-u-nu-latn`, { month: "long", year: "numeric" });
  let lastMonth = "";
  const cell = (x, i) => {
    let head = "";
    const m = (x.taken_at || "").slice(0, 7);
    if (m && m !== lastMonth) {
      lastMonth = m;
      const [y, mo] = m.split("-").map(Number);
      head = `<div class="monthh">${esc(fmtMonth.format(new Date(y, mo - 1, 1)))}</div>`;
    }
    return `${head}<button class="it f" data-i="${i}"><div class="th"><img loading="lazy" src="/api/tv/photo/${x.id}/thumb" alt="">${x.is_video ? `<span class="tag">${A.PLAY}</span>` : ""}</div></button>`;
  };
  const kid = isKid();
  const el = h(`<div class="${kid ? "bg-kidsdark" : "bg-dark"} photos">
    ${header(t, t.title, "", items.length ? `<button class="btn gold f js-show">${A.PLAY}عرض شرائح</button>` : "")}
    ${items.length ? `<div class="grid-wrap"><div class="grid" style="--cols:6">${items.map(cell).join("")}</div></div>`
      : `<div class="empty">${A.icon("photos")}<div>لا توجد صور بعد.<br>ارفع الصور من الهاتف إلى تطبيق «الصور» في السيرفر.</div></div>`}
    ${hints([["موافق", "عرض الصورة"], ["رجوع", "الرئيسية"]])}</div>`);
  const grid = el.querySelector(".grid");
  const toView = () => items.map((x) => ({ src: `/api/tv/photo/${x.id}/view`, video: !!x.is_video, name: "", info: x.is_video ? `/api/tv/photo/${x.id}/vinfo` : null }));
  const bind = (root) => root.querySelectorAll(".it:not([data-b])").forEach((b) => {
    b.dataset.b = 1;
    b.addEventListener("click", () => viewerScreen(toView(), +b.dataset.i));
  });
  bind(el);
  el.querySelector(".js-back").addEventListener("click", pop);
  el.querySelector(".js-show")?.addEventListener("click", () => viewerScreen(toView(), 0, true));
  let loading = false;
  push({
    el,
    initial: () => el.querySelector(".it") || el.querySelector(".js-back"),
    async onFocus(f) {
      if (loading || nextOff == null || !f.dataset.i || +f.dataset.i < items.length - 18) return;
      loading = true;
      try {
        const start = items.length;
        const more = await load();
        grid.insertAdjacentHTML("beforeend", more.map((x, j) => cell(x, start + j)).join(""));
        bind(grid);
      } catch { /* تجاهل */ } finally { loading = false; }
    },
  });
}

// ============================================================== الكاميرات
// مربع «الكاميرات»: الصور الحية لكل الكاميرات، ثم البث المباشر بملء الشاشة، والتسجيلات بالأيام
let hlsLoad = null;
async function playHls(video, src) {
  if (video.canPlayType("application/vnd.apple.mpegurl")) { video.src = src; video.play().catch(() => {}); return () => { video.removeAttribute("src"); video.load(); }; }
  if (!window.Hls) {
    hlsLoad = hlsLoad || new Promise((res, rej) => { const s = document.createElement("script"); s.src = "/static/vendor/hls.light.min.js"; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
    await hlsLoad;
  }
  if (!window.Hls || !window.Hls.isSupported()) throw new Error("hls");
  const hls = new window.Hls({ liveSyncDurationCount: 2, maxBufferLength: 8 });
  hls.loadSource(src); hls.attachMedia(video);
  hls.on(window.Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}));
  hls.on(window.Hls.Events.ERROR, (_, d) => { if (d.fatal) { if (d.type === window.Hls.ErrorTypes.NETWORK_ERROR) setTimeout(() => hls.startLoad(), 2000); else hls.recoverMediaError(); } });
  return () => hls.destroy();
}
const CAM_STATE = { rec: ["● يسجّل", "ok"], live: ["مباشر", "ok"], connecting: ["يتصل…", "warn"], error: ["لا يعمل", "bad"], off: ["متوقفة", ""] };

// البند 23: هل يشغّل هذا التلفاز فيديو H.265 (كاميرات كثيرة ترسله)؟ إن لم يكن: صور تتجدد بدل البث.
const HEVC_OK = (() => { try { return !!(window.MediaSource && MediaSource.isTypeSupported('video/mp4; codecs="hvc1.1.6.L93.B0"')); } catch { return false; } })();
const camVideoOk = (c) => c.live && !(c.codec || "").startsWith("mjpeg") && (HEVC_OK || !/^(hevc|h265)/.test(c.codec || ""));
const CAM_LAYOUTS = [["grid", "▦ بجانب بعضها"], ["seq", "▶ واحدة تلو الأخرى"], ["big", "◧ كبيرة وصغيرة"]];
const camLayout = () => { try { return localStorage.getItem("cam_layout") || "grid"; } catch { return "grid"; } };

// كل الكاميرات تظهر معاً في الشاشة: عدد الأعمدة وعرضها حسب عددها
function camGridStyle(n) {
  const cols = n <= 1 ? 1 : n <= 4 ? 2 : n <= 9 ? 3 : 4, rows = Math.ceil(n / cols);
  const W = 1220 - 28 - (cols - 1) * 22, H = 560 - 28 - (rows - 1) * 22;
  const cw = Math.floor(Math.min(W / cols, (H / rows - 40) * 16 / 9));
  return `--cols:${cols};--cw:${cw}px`;
}
async function camerasScreen(t) {
  let d;
  try { d = await api("/api/cameras"); } catch (e) { toast(e.message); return; }
  const cams = d.cameras.filter((c) => c.enabled);
  const snap = (c) => `/api/cameras/${c.id}/snap?t=${Date.now()}`;
  let layout = camLayout();
  const lay = () => `<button class="btn f js-lay">${(CAM_LAYOUTS.find((x) => x[0] === layout) || CAM_LAYOUTS[0])[1]}</button>`;
  const el = h(`<div class="bg-dark cams">
    ${header(t, t.title, "", cams.length > 1 ? lay() : "")}
    <div class="cam-body"></div>
    ${hints([["موافق", "مشاهدة مع الصوت"], ["⬆", "طريقة العرض"], ["رجوع", "الرئيسية"]])}</div>`);
  const body = el.querySelector(".cam-body");
  let timer = 0, stops = [];
  const stopAll = () => { clearInterval(timer); stops.forEach((f) => f()); stops = []; };
  const tile = (c, i, cls = "") => `<button class="cam-it f ${cls}" data-i="${i}">
      <div class="shot"><img src="${snap(c)}" alt="" onerror="this.style.opacity=0" onload="this.style.opacity=1"><video muted autoplay playsinline hidden></video>${A.icon("camera")}</div>
      <div class="nm"><b>${esc(c.name)}</b><span class="st ${(CAM_STATE[c.state] || [])[1] || ""}">${(CAM_STATE[c.state] || [c.state])[0]}</span>${c.audio ? '<span class="st" title="فيها صوت">🔊</span>' : ""}</div></button>`;
  const draw = () => {
    stopAll();
    if (!cams.length) { body.innerHTML = `<div class="empty">${A.icon("camera")}<div>لا توجد كاميرات بعد.<br>أضفها من الهاتف أو الكمبيوتر: تطبيق «الكاميرات».</div></div>`; return; }
    if (layout === "big" && cams.length > 1) {
      body.innerHTML = `<div class="cam-big">${tile(cams[0], 0, "main")}<div class="cam-side">${cams.slice(1).map((c, i) => tile(c, i + 1)).join("")}</div></div>`;
    } else {
      body.innerHTML = `<div class="cam-grid" style="${camGridStyle(cams.length)}">${cams.map((c, i) => tile(c, i)).join("")}</div>`;
    }
    body.querySelectorAll(".cam-it").forEach((b) => b.addEventListener("click", () => camLiveScreen(cams, +b.dataset.i, false)));
    // بث حي صامت داخل المربعات (حتى 4 كاميرات، أو الكبيرة فقط)؛ والباقي صور تتجدد كل ثانية
    const live = layout === "big" ? [0] : cams.length <= 4 ? cams.map((_, i) => i) : [];
    live.forEach(async (i) => {
      const c = cams[i]; if (!camVideoOk(c)) return;
      const b = body.querySelector(`.cam-it[data-i="${i}"]`), v = b.querySelector("video"), im = b.querySelector("img");
      try { const s = await playHls(v, `/api/cameras/${c.id}/live/live.m3u8`); stops.push(s); v.hidden = false; v.onplaying = () => { im.style.display = "none"; }; } catch { /* صور */ }
    });
    timer = setInterval(() => body.querySelectorAll(".cam-it").forEach((b) => { const im = b.querySelector("img"); if (im.style.display !== "none") im.src = snap(cams[+b.dataset.i]); }), 1000);
    if (layout === "seq" && openSeq) { openSeq = false; setTimeout(() => { if (el.isConnected && top() && top().el === el) camLiveScreen(cams, 0, true); }, 50); }
  };
  let openSeq = true;   // «واحدة تلو الأخرى» تفتح مرة واحدة، و«رجوع» منها يُظهر كل الكاميرات
  el.querySelector(".js-back").addEventListener("click", pop);
  const lb = el.querySelector(".js-lay");
  const nextLayout = () => {
    const i = CAM_LAYOUTS.findIndex((x) => x[0] === layout);
    layout = CAM_LAYOUTS[(i + 1) % CAM_LAYOUTS.length][0];
    try { localStorage.setItem("cam_layout", layout); } catch { /* لا شيء */ }
    if (lb) lb.textContent = CAM_LAYOUTS.find((x) => x[0] === layout)[1];
    openSeq = layout === "seq";
    draw();
  };
  if (lb) lb.addEventListener("click", nextLayout);
  push({ el, busy: () => true, initial: () => el.querySelector(".cam-it") || el.querySelector(".js-back"),
    onHide() { stopAll(); }, onShow() { if (!stops.length) draw(); }, destroy() { stopAll(); } });
  draw();
}

function camLiveScreen(cams, idx, auto = false) {
  stopBg();   // البند 62
  const SEQ_SEC = 10;
  const el = h(`<div class="player cam-live"><video autoplay playsinline></video><img class="cam-img" alt="" hidden>
    <div class="osd"><div class="tt"></div><div class="keys"><span><b>← →</b>كاميرا أخرى</span><span><b>موافق</b>التسجيلات</span><span><b>⬆</b>${auto ? "إيقاف التبديل" : "تبديل تلقائي"}</span><span><b>رجوع</b>كل الكاميرات</span></div></div></div>`);
  const v = el.querySelector("video"), img = el.querySelector(".cam-img"), osd = el.querySelector(".osd");
  let stop = null, timer = 0, hideT = 0, seqT = 0;
  const showOsd = () => { osd.classList.remove("hide"); clearTimeout(hideT); hideT = setTimeout(() => osd.classList.add("hide"), 4000); };
  const keysHtml = () => `<span><b>← →</b>كاميرا أخرى</span><span><b>موافق</b>التسجيلات</span><span><b>⬆</b>${auto ? "إيقاف التبديل" : "تبديل تلقائي"}</span><span><b>رجوع</b>كل الكاميرات</span>`;
  const show = async (i) => {
    idx = (i + cams.length) % cams.length;
    const c = cams[idx];
    if (stop) { stop(); stop = null; }
    clearInterval(timer); clearTimeout(seqT);
    if (auto && cams.length > 1) seqT = setTimeout(() => show(idx + 1), SEQ_SEC * 1000);
    // الصوت: مسموع في المشاهدة الكاملة إن كانت الكاميرا ترسله
    v.muted = !c.audio;
    el.querySelector(".tt").textContent = `${c.name}  ·  ${idx + 1} / ${cams.length}  ·  ${c.audio ? "🔊 مع الصوت" : "🔇 بلا صوت"}${auto ? `  ·  تتبدل كل ${SEQ_SEC} ث` : ""}`;
    el.querySelector(".keys").innerHTML = keysHtml();
    showOsd();
    if (camVideoOk(c)) {
      try { img.hidden = true; v.style.display = ""; stop = await playHls(v, `/api/cameras/${c.id}/live/live.m3u8`); return; } catch { /* صور */ }
    }
    v.style.display = "none"; img.hidden = false;
    const mj = (c.codec || "").startsWith("mjpeg");
    const tick = () => { img.src = `/api/cameras/${c.id}/snap?t=${Date.now()}`; };
    tick(); timer = setInterval(tick, mj ? 400 : 1000);
  };
  push({
    el, busy: () => true,
    key(e) {
      if (e.key === NEXT_KEY) { show(idx + 1); return true; }
      if (e.key === PREV_KEY) { show(idx - 1); return true; }
      if (e.key === "Enter" || e.key === " ") { camRecScreen(cams[idx]); return true; }
      if (e.key === "ArrowUp") { auto = !auto; show(idx); return true; }
      if (e.key === "ArrowDown") { showOsd(); return true; }
      return false;
    },
    onHide() { if (stop) { stop(); stop = null; } clearInterval(timer); clearTimeout(seqT); timer = 0; },
    onShow() { if (!stop && !timer) show(idx); },
    destroy() { if (stop) stop(); clearInterval(timer); clearTimeout(hideT); clearTimeout(seqT); },
  });
  show(idx);
  el.addEventListener("click", () => camRecScreen(cams[idx]));
}

async function camRecScreen(c) {
  let dd;
  try { dd = await api(`/api/cameras/${c.id}/days`); } catch (e) { toast(e.message); return; }
  if (!dd.days.length) { toast(c.record === false ? "التسجيل متوقف لهذه الكاميرا. شغّله من تطبيق «الكاميرات»" : "لا توجد تسجيلات لهذه الكاميرا بعد"); return; }
  const fmtDay = (s) => { try { return new Date(s + "T12:00").toLocaleDateString(`${LOC}-u-nu-latn`, { weekday: "long", day: "numeric", month: "long" }); } catch { return s; } };
  const el = h(`<div class="bg-dark cams">
    <div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>رجوع</span></button>
      <div class="ti" style="background:linear-gradient(135deg,#0f172a,#2563eb)">${A.icon("camera")}</div><h1>تسجيلات ${nm(esc(c.name))}</h1></div>
    <div class="cam-days">${dd.days.map((x) => `<button class="btn f day" data-d="${x.day}">${esc(fmtDay(x.day))}</button>`).join("")}</div>
    <div class="cam-segs"></div>
    ${hints([["موافق", "تشغيل"], ["رجوع", "البث المباشر"]])}</div>`);
  el.querySelector(".js-back").addEventListener("click", pop);
  const segs = el.querySelector(".cam-segs");
  const load = async (day, b) => {
    el.querySelectorAll(".day").forEach((x) => x.classList.toggle("gold", x === b));
    let r;
    try { r = await api(`/api/cameras/${c.id}/rec?day=${day}`); } catch (e) { toast(e.message); return; }
    const items = r.items.slice().reverse();   // الأحدث أولاً (والمقطع الذي يُسجَّل الآن يُشغَّل أيضاً)
    segs.innerHTML = items.length ? items.map((x, i) => `<button class="btn f seg" data-i="${i}">${x.time}${x.busy ? " ●" : ""}</button>`).join("") : `<p class="set-msg">لا توجد مقاطع.</p>`;
    const list = items.map((x) => { const u = `/api/cameras/${c.id}/rec/${encodeURIComponent(x.name)}`; return { src: u, video: true, info: `${u}/vinfo`, name: `${c.name} · ${fmtDay(day)} ${x.time}` }; });
    segs.querySelectorAll(".seg").forEach((s) => s.addEventListener("click", () => viewerScreen(list, +s.dataset.i)));
  };
  el.querySelectorAll(".day").forEach((b) => b.addEventListener("click", () => { load(b.dataset.d, b); setFocus(segs.querySelector(".seg") || b); }));
  push({ el, busy: () => true, initial: () => el.querySelector(".day") });
  await load(dd.days[0].day, el.querySelector(".day"));
}

// ============================================================== الألعاب
// اليد داخل اللعبة: إذا لم يرَ إطار اللعبة يد التحكم بنفسه (يحدث في بعض الأجهزة)، نعطيه ما تراه شاشة التلفاز
// البند 51: الخروج من اللعبة بزر PS (أو «رجوع» في الريموت) بعد رسالة تأكيد، واللعبة متوقفة خلفها
let padsBlocked = false;   // أثناء رسالة الخروج: اللعبة لا ترى الأيادي
window.hsefPadSwap = () => { try { return !!padPrefs.swap; } catch { return false; } };   // للألعاب (kit.js). البند 52: نفس الموقع في كل الأيادي
function freezeGame(fr, on) {   // نوقف رسم اللعبة (requestAnimationFrame) ثم نكمله من حيث توقف
  try {
    const w = fr.contentWindow;
    if (on && !w.__hsefRaf) {
      const real = w.requestAnimationFrame.bind(w), held = [];
      w.__hsefRaf = { real, held };
      w.requestAnimationFrame = (cb) => { held.push(cb); return 0; };
      w.document.querySelectorAll("video, audio").forEach((m) => { if (!m.paused) { m.pause(); m.dataset.hsefPaused = "1"; } });
    } else if (!on && w.__hsefRaf) {
      const { real, held } = w.__hsefRaf;
      w.requestAnimationFrame = real; w.__hsefRaf = null;
      held.splice(0).forEach((cb) => real(cb));
      w.document.querySelectorAll("[data-hsef-paused]").forEach((m) => { delete m.dataset.hsefPaused; m.play().catch(() => {}); });
    }
  } catch { /* لعبة من مصدر آخر */ }
}
function whenPadsReleased(fn, t0 = performance.now()) {   // لا تصل ضغطة «أكمل» نفسها إلى اللعبة
  let held = false;
  try { held = [...(navigator.getGamepads ? navigator.getGamepads() : [])].some((g) => g && g.connected && g.buttons.some((x) => x && x.pressed)); } catch { /* */ }
  if (!held || performance.now() - t0 > 1500) fn(); else requestAnimationFrame(() => whenPadsReleased(fn, t0));
}
function askGameExit(scr, fr) {
  if (scr.asking) return;
  scr.asking = true; padsBlocked = true;
  freezeGame(fr, true);
  fr.inert = true;
  try { fr.contentWindow.blur(); } catch { /* */ }
  window.focus();
  const box = h(`<div class="gexit"><div class="gx-card"><div class="gx-ic">🚪</div><b>الخروج من اللعبة؟</b>
    <div class="gx-row"><button class="gx-btn f js-stay">▶️ أكمل اللعب</button><button class="gx-btn out f js-out">نعم، اخرج</button></div>
    <small><b dir="ltr">PS</b> <span>للخروج</span> · <b>${faceIcon(backPos(), 22)}</b> <span>للعودة إلى اللعبة</span></small></div></div>`);
  scr.el.appendChild(box);
  scr.closeAsk = (out) => {
    if (!scr.asking) return;
    box.remove(); scr.asking = false; scr.closeAsk = null;
    if (out) { padsBlocked = false; pop(); return; }
    fr.inert = false;
    freezeGame(fr, false);
    whenPadsReleased(() => { padsBlocked = false; });
    try { fr.contentWindow.focus(); } catch { /* */ }
  };
  box.querySelector(".js-stay").addEventListener("click", () => scr.closeAsk?.(false));
  box.querySelector(".js-out").addEventListener("click", () => scr.closeAsk?.(true));
  setFocus(box.querySelector(".js-stay"));
}

function shareGamepads(fr) {
  try {
    const nav = fr.contentWindow.navigator;
    const own = nav.getGamepads ? nav.getGamepads.bind(nav) : () => [];
    Object.defineProperty(nav, "getGamepads", {
      configurable: true,
      value: () => {
        if (padsBlocked) return [];
        let a = [];
        try { a = [...own()]; } catch { /* */ }
        if (a.some((g) => g && g.connected)) return a;
        try { return navigator.getGamepads ? [...navigator.getGamepads()] : a; } catch { return a; }
      },
    });
  } catch { /* لعبة من مصدر آخر */ }
}

// «تعلّم ثم العب» ووقت اللعب: يسأل السيرفر قبل فتح اللعبة، ونبضة كل 30 ثانية أثناء اللعب
const gameName = (t, path) => (path || "").split("/").filter(Boolean).pop() || t.title;
function blockedScreen(t, c) {
  const learn = c.learn_games || [];
  const title = c.reason === "limit" ? "انتهى وقت اللعب اليوم 🌙" : `تعلّم أولاً ${c.learn_need} ${c.learn_need === 1 ? "دقيقة" : "دقائق"} 📚`;
  const sub = c.reason === "limit" ? "يمكنك أن تتعلّم شيئاً جديداً، أو تستمع إلى قصة." : "بعدها تُفتح الألعاب الأخرى وحدها.";
  const el = h(`<div class="bg-dark kscr">${header(t, t.title, "")}
    <div class="kmsg"><b>${esc(title)}</b><span>${esc(sub)}</span></div>
    ${learn.length ? `<div class="kgrid">${learn.map((g, i) => `<button class="kcard f" data-i="${i}"><span class="ic">${A.icon("letters")}</span><b>${esc(g)}</b></button>`).join("")}</div>` : ""}
    ${hints([["موافق", "تعلّم"], ["رجوع", "رجوع"]])}</div>`);
  el.querySelector(".js-back").addEventListener("click", pop);
  // التطبيقات التعليمية في مربع «التعليم» (مجلده المشترك)، لا في مربع الألعاب
  const lt = c.learn_tile ? { ...t, id: c.learn_tile, kind: "learn" } : t;
  el.querySelectorAll(".kcard").forEach((b) => b.addEventListener("click", () => { pop(); gameScreen(lt, learn[+b.dataset.i]); }));
  push({ el, initial: () => el.querySelector(".kcard") || el.querySelector(".js-back") });
}

// v1.9.7: تقدّم الطفل محفوظ في المتصفح باسم فيه رقم المربع (/tv/game/<رقم>/<اللعبة>/). إذا نُقلت اللعبة إلى مربع
// آخر (مثل «الألعاب» ← «التعليم») يتغير الرقم: ننسخ التقدّم القديم إلى الاسم الجديد قبل فتحها، لكل الألعاب
function carryProgress(tid, path) {
  try {
    const norm = (x) => { let d = x; try { d = decodeURIComponent(x); } catch { /* */ } return d.replace(/(\/index\.html)?\/?$/, ""); };
    const want = norm(path || "");
    const re = /^(.*?:)\/tv\/game\/(\d+)\/(.*)$/;
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i));
    for (const k of keys) {
      const m = k && k.match(re);
      if (!m || m[2] === String(tid) || norm(m[3]) !== want) continue;
      const nk = `${m[1]}/tv/game/${tid}/${m[3]}`;
      if (localStorage.getItem(nk) === null) localStorage.setItem(nk, localStorage.getItem(k));
    }
  } catch { /* */ }
}

async function gameScreen(t, path) {
  stopBg();   // البند 62
  const gname = gameName(t, path);
  carryProgress(t.id, path);
  if (isKid()) {
    let c = null;
    try { c = await api(`/api/tv/play/check?game=${encodeURIComponent(gname)}`); } catch { /* السيرفر القديم: نفتح */ }
    if (c && !c.allowed) { blockedScreen(t, c); return; }
  }
  const el = h(`<div class="game"><iframe src="/tv/game/${t.id}/${path ? `${encPath(path)}/` : ""}" allow="autoplay; fullscreen; gamepad" title="${esc(path)}"></iframe>
    <div class="exit">للخروج من اللعبة: <b dir="ltr">PS</b> · زر «رجوع» في الريموت</div></div>`);
  const fr = el.querySelector("iframe");
  let scr = null;
  const onKey = (e) => { activity(); if (e.key === "Escape" || e.key === "BrowserBack" || e.key === "GoBack") { e.preventDefault(); if (scr) askGameExit(scr, fr); } };
  fr.addEventListener("load", () => {
    shareGamepads(fr);
    try {
      fr.contentWindow.addEventListener("keydown", onKey);
      fr.contentWindow.addEventListener("mousemove", activity);
      fr.contentWindow.focus();
    } catch { /* لعبة من مصدر آخر */ }
  });
  setTimeout(() => { const x = el.querySelector(".exit"); if (x) x.style.opacity = 0; }, 5000);
  const beat = setInterval(async () => {
    try {
      const r = await api("/api/tv/play/beat", { json: { game: gname } });
      if (r.stop && top() && top().el === el) { pop(); blockedScreen(t, r); }
    } catch { /* */ }
  }, 30000);
  scr = {
    el,
    busy: () => true,
    isGame: true,
    askExit: () => askGameExit(scr, fr),
    destroy() { clearInterval(beat); padsBlocked = false; },
    key(e) {
      if (scr.asking) { if (BACK_KEYS.has(e.key)) { scr.closeAsk(false); return true; } return false; }   // الأسهم وموافق للرسالة
      if (e.key === "Escape" || BACK_KEYS.has(e.key)) { askGameExit(scr, fr); return true; }
      return false;
    },
  };
  push(scr);
  setTimeout(() => { try { fr.contentWindow.focus(); } catch { /* */ } }, 300);
}

// البند 46: تطبيق مدمج في النظام (مثل «الرسائل») داخل إطار، و«رجوع» يخرج منه ويحدّث الشاشة الرئيسية
function appScreen(url, title) {
  stopBg();   // البند 62
  const el = h(`<div class="game"><iframe src="${url}" allow="autoplay; fullscreen; gamepad" title="${esc(title)}"></iframe>
    <div class="exit">للخروج اضغط «رجوع» (Esc)</div></div>`);
  const fr = el.querySelector("iframe");
  const onKey = (e) => { activity(); if (e.key === "Escape" || e.key === "BrowserBack" || e.key === "GoBack") { e.preventDefault(); pop(); } };
  fr.addEventListener("load", () => {
    shareGamepads(fr);
    try { fr.contentWindow.addEventListener("keydown", onKey); fr.contentWindow.addEventListener("mousemove", activity); fr.contentWindow.focus(); } catch { /* */ }
  });
  setTimeout(() => { const x = el.querySelector(".exit"); if (x) x.style.opacity = 0; }, 5000);
  push({ el, busy: () => true, isGame: true, key(e) { if (e.key === "Escape" || BACK_KEYS.has(e.key)) { pop(); return true; } return false; } });
  setTimeout(() => { try { fr.contentWindow.focus(); } catch { /* */ } }, 300);
}

// ============================================================== مهامي اليوم
const CHORE_ST = { done: ["⏳", "ينتظر تأكيد ماما أو بابا"], confirmed: ["✅", "أُضيفت النجوم"] };
async function choresScreen(t) {
  let items;
  try { items = (await api("/api/tv/chores")).items; } catch (e) { toast(e.message); return; }
  const el = h(`<div class="bg-dark kscr">${header(t, t.title, "")}<div class="kgrid chores"></div>
    ${hints([["موافق", "فعلتها"], ["رجوع", "الرئيسية"]])}</div>`);
  const grid = el.querySelector(".kgrid");
  const draw = (keep) => {
    grid.innerHTML = items.length ? items.map((c, i) => {
      const st = CHORE_ST[c.status];
      return `<button class="kcard f ${c.status || ""}" data-i="${i}"><span class="emo">${esc(c.icon)}</span><b>${esc(c.title)}</b>
        <span class="kst">${st ? `${st[0]} ${st[1]}` : `اضغط عندما تنتهي · ⭐ ${c.stars}`}</span></button>`;
    }).join("") : `<div class="empty">لا توجد مهام اليوم.</div>`;
    grid.querySelectorAll(".kcard").forEach((b) => b.addEventListener("click", async () => {
      const c = items[+b.dataset.i];
      if (c.status === "confirmed") { toast("أحسنت! أُضيفت النجوم ⭐"); return; }
      try { items = (await api(`/api/tv/chores/${c.id}/done`, { method: "POST" })).items; } catch (e) { toast(e.message); return; }
      if (!c.status) toast("أحسنت! 👏 ماما أو بابا سيؤكدان ويضيفان النجوم");
      draw(+b.dataset.i);
    }));
    if (keep !== undefined) setFocus(grid.querySelectorAll(".kcard")[keep] || grid);
  };
  el.querySelector(".js-back").addEventListener("click", pop);
  draw();
  push({ el, initial: () => el.querySelector(".kcard") || el.querySelector(".js-back") });
}

// ============================================================== تأكيد مهام الأطفال (للأب والأم برمزهم)
async function choresConfirmScreen() {
  let r;
  try { r = await api("/api/tv/chores/pending"); } catch (e) { toast(e.message); return; }
  if (!r.has_pin) { toast("لتأكيد مهام الأطفال من التلفاز ضع رمز دخول (PIN) لحسابك: لوحة التحكم ← وضع التلفاز", 8000); return; }
  if (!r.count) { toast("لا توجد مهام تنتظر التأكيد 👍", 4000); return; }
  pinScreen({ title: "رمزك للتأكيد", sub: "مهام الأطفال", face: face(me.user) }, async (pin) => {
    const first = await api("/api/tv/chores/pending", { json: { pin } });   // يتحقق من الرمز
    pop();
    const el = h(`<div class="bg-dark kscr"><div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>الرئيسية</span></button>
      <div class="ti" style="background:linear-gradient(135deg,#22c55e,#15803d)"><span class="emo">✅</span></div><h1>مهام الأطفال</h1></div>
      <div class="kgrid chk"></div>${hints([["موافق", "اختيار"], ["رجوع", "الرئيسية"]])}</div>`);
    const grid = el.querySelector(".kgrid");
    const draw = (res) => {
      grid.innerHTML = res.items.length ? res.items.map((c) => `<div class="kcard ${c.id}"><span class="emo">${esc(c.icon)}</span><b>${esc(c.title)}</b>
        <span class="kst"><bdi translate="no">${esc(c.kid)}</bdi> · ⭐ ${c.stars}</span>
        <div class="acts"><button class="btn f" data-ok="${c.id}">✓ تأكيد</button><button class="btn f" data-no="${c.id}">✗ رفض</button></div></div>`).join("")
        : `<div class="empty">لا توجد مهام تنتظر التأكيد 👍</div>`;
      grid.querySelectorAll("[data-ok],[data-no]").forEach((b) => b.addEventListener("click", async () => {
        const ok = !!b.dataset.ok;
        try { draw(await api("/api/tv/chores/pending", { json: { pin, id: +(b.dataset.ok || b.dataset.no), action: ok ? "confirm" : "reject" } })); }
        catch (e) { toast(e.message); return; }
        toast(ok ? "أُضيفت النجوم ⭐" : "رجعت المهمة للطفل ليعيدها", 3000);
        setFocus(grid.querySelector(".f") || el.querySelector(".js-back"));
      }));
    };
    el.querySelector(".js-back").addEventListener("click", pop);
    draw(first);
    push({ el, initial: () => grid.querySelector(".f") || el.querySelector(".js-back") });
  });
}

// ============================================================== في مثل هذا اليوم
async function onThisDayScreen(t) {
  let items;
  try { items = (await api("/api/tv/onthisday")).items; } catch (e) { toast(e.message); return; }
  if (!items.length) { toast("لا توجد صور من هذا اليوم في السنوات السابقة"); return; }
  const ago = (n) => !AR ? agoText(n, "year") : n === 1 ? "قبل سنة" : n === 2 ? "قبل سنتين" : n <= 10 ? `قبل ${n} سنوات` : `قبل ${n} سنة`;
  viewerScreen(items.map((x) => ({ src: `/api/tv/media/${x.id}/view`, name: `في مثل هذا اليوم · ${ago(x.ago)} (${x.year})` })), 0, true);
}

// ============================================================== قصص بصوت العائلة
async function storiesScreen(t) {
  let items;
  try { items = (await api("/api/tv/stories")).items; } catch (e) { toast(e.message); return; }
  const el = h(`<div class="bg-dark kscr">${header(t, t.title, "")}
    <div class="kgrid">${items.map((x, i) => `<button class="kcard f" data-i="${i}"><span class="emo">🎧</span><b>${esc(x.title)}</b>
      <span class="kst">${x.by ? `بصوت ${nm(esc(x.by))}` : ""}</span></button>`).join("") || `<div class="empty">لا توجد قصص بعد.</div>`}</div>
    ${hints([["موافق", "استمع"], ["رجوع", "الرئيسية"]])}</div>`);
  el.querySelector(".js-back").addEventListener("click", pop);
  el.querySelectorAll(".kcard").forEach((b) => b.addEventListener("click", () => storyPlayer(t, items[+b.dataset.i])));
  push({ el, initial: () => el.querySelector(".kcard") || el.querySelector(".js-back") });
}
function storyPlayer(t, x) {
  stopBg();   // البند 62
  const el = h(`<div class="bg-dark kplay" style="--glow1:#ec489966">
    <div class="cover" style="background:${A.gradient(t.color)}"><span class="emo">🎧</span></div>
    <h1>${esc(x.title)}</h1><div class="by">${x.by ? `بصوت ${nm(esc(x.by))}` : ""}</div>
    <div class="bar"><i></i></div><div class="tm"></div>
    <audio src="/api/tv/stories/${x.id}/audio" autoplay></audio>
    ${hints([["موافق", "إيقاف/تشغيل"], ["← →", "10 ثوانٍ"], ["رجوع", "القصص"]])}</div>`);
  const au = el.querySelector("audio"), bar = el.querySelector(".bar i"), tm = el.querySelector(".tm");
  const fmt = (n) => `${Math.floor(n / 60)}:${String(Math.floor(n % 60)).padStart(2, "0")}`;
  au.addEventListener("timeupdate", () => {
    if (au.duration) bar.style.width = `${(100 * au.currentTime) / au.duration}%`;
    tm.textContent = `${fmt(au.currentTime)} / ${au.duration ? fmt(au.duration) : "…"}`;
  });
  au.addEventListener("error", () => toast("تعذر تشغيل التسجيل"));
  push({
    el, busy: () => !au.paused,
    destroy() { au.pause(); au.removeAttribute("src"); },
    key(e) {
      activity();
      if (e.key === "Enter" || e.key === " ") { au.paused ? au.play() : au.pause(); return true; }
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        const d = (e.key === "ArrowLeft") === (document.dir === "rtl") ? 10 : -10;
        au.currentTime = Math.max(0, Math.min(au.duration || 0, au.currentTime + d)); return true;
      }
      if (e.key === "Escape" || BACK_KEYS.has(e.key)) { pop(); return true; }
      return false;
    },
  });
}

// ============================================================== رمضان
function hijriParts() {
  try {
    const f = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura-nu-latn", { day: "numeric", month: "numeric", year: "numeric" });
    const o = Object.fromEntries(f.formatToParts(new Date()).filter((p) => p.type !== "literal").map((p) => [p.type, parseInt(p.value, 10)]));
    return { y: o.year, m: o.month, d: o.day };
  } catch { return null; }
}
async function ramadanScreen(t) {
  const hj = hijriParts();
  const q = hj ? `?hy=${hj.y}&hd=${hj.d}` : "";
  let d;
  try { d = await api(`/api/tv/ramadan${q}`); } catch (e) { toast(e.message); return; }
  let hdate = "";
  try { hdate = new Intl.DateTimeFormat(`${AR ? "ar-SA" : LOC}-u-ca-islamic-umalqura${AR ? "" : "-nu-latn"}`, { day: "numeric", month: "long", year: "numeric" }).format(new Date()); } catch { /* */ }
  const el = h(`<div class="bg-dark kscr ramadan">${header(t, t.title, "", `<span class="hd">${esc(hdate)}</span>`)}
    <div class="rtop"><div class="rcount"><span class="lbl"></span><b class="clock"></b></div>
      <div class="rchal"><span class="lbl">🌙 تحدّي اليوم</span><b class="ctext"></b><button class="btn f js-ch"></button></div></div>
    <div class="lbl kh-l">📖 ختمة العائلة: <b class="kh-n"></b> من 30 جزءاً</div>
    <div class="khatma"></div>
    ${hints([["موافق", "قرأتُ هذا الجزء"], ["رجوع", "الرئيسية"]])}</div>`);
  const times = Object.fromEntries(((me && me.prayer && me.prayer.times) || []).map((x) => [x.key, x.time]));
  const at = (hm, addDay = 0) => { const [H, M] = (hm || "00:00").split(":").map(Number); const x = new Date(); x.setHours(H, M, 0, 0); x.setDate(x.getDate() + addDay); return x; };
  const tick = () => {
    const now = new Date();
    let label = "", target = null;
    if (times.maghrib && now < at(times.maghrib)) { label = "🍽️ الإفطار بعد"; target = at(times.maghrib); }
    else if (times.fajr) { label = "🌅 السحور ينتهي (الفجر) بعد"; target = now < at(times.fajr) ? at(times.fajr) : at(times.fajr, 1); }
    el.querySelector(".rcount .lbl").textContent = label || "رمضان كريم 🌙";
    if (!target) el.querySelector(".clock").innerHTML = `<small style="font-size:20px;color:#e2e8f0;letter-spacing:0">لعرض وقت الإفطار والسحور اضبط أوقات الصلاة من لوحة التحكم ← وضع التلفاز</small>`;
    if (target) {
      const s = Math.max(0, Math.round((target - now) / 1000));
      el.querySelector(".clock").textContent = `${Math.floor(s / 3600)}:${String(Math.floor((s % 3600) / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
    }
  };
  const draw = (keep) => {
    el.querySelector(".ctext").textContent = d.challenge.text;
    const cb = el.querySelector(".js-ch");
    cb.textContent = d.challenge.done ? "✅ فعلتها اليوم" : "فعلتها ⭐ +2";
    cb.classList.toggle("gold", !d.challenge.done);
    el.querySelector(".kh-n").textContent = d.khatma.filter((k) => k.user_id).length;
    const kh = el.querySelector(".khatma");
    kh.innerHTML = d.khatma.map((k) => `<button class="juz f ${k.user_id ? "done" : ""}" data-j="${k.juz}"><b>${k.juz}</b><span>${k.user_id ? esc(k.name) : ""}</span></button>`).join("");
    kh.querySelectorAll(".juz").forEach((b) => b.addEventListener("click", async () => {
      try { d = await api("/api/tv/ramadan/khatma", { json: { hy: d.hy, juz: +b.dataset.j } }); } catch (e) { toast(e.message); return; }
      draw(+b.dataset.j);
    }));
    if (keep) setFocus(kh.querySelector(`[data-j="${keep}"]`));
  };
  el.querySelector(".js-back").addEventListener("click", pop);
  el.querySelector(".js-ch").addEventListener("click", async () => {
    if (d.challenge.done) return;
    try { const r = await api("/api/tv/ramadan/challenge", { method: "POST" }); if (r.added) toast(`أحسنت! ⭐ +${r.added}`); } catch (e) { toast(e.message); return; }
    d.challenge.done = true; draw();
  });
  draw(); tick();
  const timer = setInterval(tick, 1000);
  push({ el, busy: () => true, initial: () => el.querySelector(".js-ch"), destroy() { clearInterval(timer); } });
}

// ============================================================== الكتب (PDF): صفحات تُقلب بالأسهم
async function bookScreen(t, path) {
  let pages = null;
  try { pages = (await api(`/api/tv/tile/${t.id}/pdfinfo?p=${encodeURIComponent(path)}`)).pages; } catch (e) { toast(e.message); return; }
  if (!pages) {
    const el = h(`<div class="book" style="background:#525659"><iframe class="pdffall" src="${fileUrl(t, path)}"></iframe></div>`);
    push({ el });
    return;
  }
  const key = `tvbook:${t.id}:${path}`;
  let n = 1;
  try { n = Math.min(pages, Math.max(1, +localStorage.getItem(key) || 1)); } catch { /* */ }
  const el = h(`<div class="player book"><div class="grid-wrap" style="top:0;bottom:0;padding:0"><img class="pg" alt=""></div><div class="counter"></div>
    <div class="osd hide"><div class="keys"><span><b>←</b>الصفحة التالية</span><span><b>→</b>السابقة</span><span><b>موافق</b>تكبير</span><span><b>رجوع</b>خروج</span></div></div></div>`);
  const img = el.querySelector(".pg"), wrap = el.querySelector(".grid-wrap"), counter = el.querySelector(".counter"), osd = el.querySelector(".osd");
  const url = (i) => `/api/tv/tile/${t.id}/page?p=${encodeURIComponent(path)}&n=${i}`;
  let hideT = 0;
  const show = (i) => {
    n = Math.min(pages, Math.max(1, i));
    img.src = url(n);
    wrap.scrollTop = 0;
    counter.textContent = `${n} / ${pages}`;
    try { localStorage.setItem(key, n); } catch { /* */ }
    if (n < pages) new Image().src = url(n + 1);
    osd.classList.remove("hide"); clearTimeout(hideT); hideT = setTimeout(() => osd.classList.add("hide"), 2500);
  };
  push({
    el,
    destroy() { clearTimeout(hideT); },
    key(e) {
      const k = e.key;
      if (k === NEXT_KEY || k === "PageDown") { show(n + 1); return true; }
      if (k === PREV_KEY || k === "PageUp") { show(n - 1); return true; }
      if (k === "Enter" || k === " ") { img.classList.toggle("zoom"); wrap.scrollTop = 0; return true; }
      if (k === "ArrowDown") { wrap.scrollBy({ top: 200, behavior: "smooth" }); return true; }
      if (k === "ArrowUp") { wrap.scrollBy({ top: -200, behavior: "smooth" }); return true; }
      return false;
    },
  });
  show(n);
}

// ============================================================== شاشة التوقف + منع إطفاء الشاشة
// الأنواع: مواقيت الصلاة، صوري، نار، نص، أمطار، درب التبانة، وتنويع (يتبدّل كل 4 دقائق)
const SAVERS = [["prayer", "مواقيت الصلاة", "🕌"], ["calendar", "التقويم", "📅"], ["photos", "صوري", "🖼️"], ["nature", "الطبيعة", "🏞️"], ["sea", "تحت الماء", "🐠"],
  ["fire", "نار", "🔥"], ["text", "نص", "📜"], ["rain", "أمطار", "🌧️"], ["snow", "ثلج", "❄️"], ["galaxy", "درب التبانة", "🌌"],
  ["moon", "القمر الليلة", "🌕"], ["clock", "ساعة كبيرة", "🕰️"], ["mix", "تنويع", "🔀"]];
let lastAct = Date.now();
let saverEl = null, saverTimer = 0, saverStop = null;
// البند 72: مؤقّت النوم (من «الليل»): عند انتهائه يتوقف الفيديو والصوت وتُطفأ الشاشة حتى يُضغط زر
let sleepAt = 0, sleepMins = 0, sleeping = false;
function goSleep() {
  try { stopBg(); } catch { /* */ }
  stage.querySelectorAll("video, audio").forEach((m) => { try { m.pause(); } catch { /* */ } });
  if (me) { try { homeScreen(); } catch { /* */ } }
  showSaver(true);   // يخفي أي شاشة توقف ظاهرة أولاً (وذلك يمسح «sleeping»)، فنضعها بعده
  sleeping = true;
}
function activity() { lastAct = Date.now(); }
function inNight() {
  const m = /^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/.exec(settings.night_off || "");
  if (!m) return false;
  const now = new Date(), cur = now.getHours() * 60 + now.getMinutes();
  const a = +m[1] * 60 + +m[2], b = +m[3] * 60 + +m[4];
  return a <= b ? cur >= a && cur < b : cur >= a || cur < b;
}
const prayerOk = () => !!(clockData && clockData.prayer && clockData.prayer.times && clockData.prayer.times.length);
const SCLOCK = `<div class="sclock"><div class="tm js-tm"></div><div class="dt js-dt"></div></div>`;
const rnd = (a, b) => a + Math.random() * (b - a);

function showSaver(night, kind) {
  if (saverEl) hideSaver();
  saverEl = h(`<div class="saver"></div>`);
  stage.appendChild(saverEl);
  const el = saverEl;
  if (night) { el.classList.add("night"); el.innerHTML = SCLOCK; tick(); return; }
  kind = kind || (isNightNow() && prayerOk() ? "prayer" : settings.saver_kind || "prayer");   // في الليل: مواقيت الصلاة بإضاءة خفيفة
  if (kind === "mix") {
    const order = (LITE ? ["prayer", "text", "calendar", "clock"] : ["prayer", "galaxy", "fire", "text", "rain", "calendar", "nature", "sea", "snow", "moon"]).filter((k) => k !== "prayer" || prayerOk());
    let i = Math.floor(Math.random() * order.length);
    const run = () => {
      if (el !== saverEl) return;
      try { saverStop?.(); } catch { /* */ }
      el.innerHTML = ""; el.className = "saver";
      saverStop = startSaver(el, order[i++ % order.length]);
    };
    run();
    saverTimer = setInterval(run, 4 * 60000);
    return;
  }
  saverStop = startSaver(el, kind);
}
function startSaver(el, kind) {
  if (kind === "prayer" && !prayerOk()) kind = "galaxy";
  const fn = { prayer: svPrayer, photos: svPhotos, fire: svFire, text: svText, rain: svRain, galaxy: svGalaxy,
    calendar: svCalendar, nature: svNature, sea: svSea, snow: svSnow, moon: svMoon, clock: svClock }[kind] || svPrayer;
  el.classList.add("sv-" + kind);
  const stop = fn(el);
  tick();
  // الساعة الصغيرة تتحرك قليلاً كل دقيقة حتى لا تحترق الشاشة
  const sc = el.querySelector(".sclock");
  const drift = sc ? setInterval(() => { sc.style.transform = `translate(${rnd(-40, 40)}px, ${rnd(-20, 20)}px)`; }, 60000) : 0;
  return () => { clearInterval(drift); stop?.(); };
}
function hideSaver() {
  clearInterval(saverTimer);
  try { saverStop?.(); } catch { /* */ }
  saverStop = null;
  saverEl?.remove();
  saverEl = null;
  sleeping = false;
  activity();
}
setInterval(() => {
  if (sleepAt && Date.now() >= sleepAt) { sleepAt = 0; sleepMins = 0; goSleep(); return; }   // البند 72
  if (saverEl) {
    if (saverEl.classList.contains("night") && !inNight() && !sleeping) hideSaver();
    return;
  }
  const t = top();
  if (t?.busy?.()) { activity(); return; }
  const night = inNight();
  const lim = night ? 1 : +settings.saver_min || 0;
  if (lim && Date.now() - lastAct > lim * 60000) showSaver(night);
}, 10000);

// حلقة رسم بعدد إطارات محدود (أخف على جهاز السيرفر)
function frameLoop(fn, fps = 30) {
  if (LITE) fps = Math.min(fps, 15);
  let id = 0, last = 0, stopped = false;
  const f = (t) => {
    if (stopped) return;
    id = requestAnimationFrame(f);
    if (last && t - last < 1000 / fps - 3) return;
    const dt = last ? Math.min(0.1, (t - last) / 1000) : 1 / fps;
    last = t;
    fn(dt, t / 1000);
  };
  id = requestAnimationFrame(f);
  return () => { stopped = true; cancelAnimationFrame(id); };
}
function svCanvas(el, cls) {
  const k = LITE ? 1 : Math.max(1, Math.min(1.6, scale || 1));
  const c = document.createElement("canvas");
  c.className = "svc " + (cls || "");
  c.width = Math.round(1280 * k); c.height = Math.round(720 * k);
  el.appendChild(c);
  const ctx = c.getContext("2d");
  ctx.scale(k, k);
  return { c, ctx, k };
}
const starsHtml = (n, h0 = 720) => Array.from({ length: n }, () => `<i style="left:${rnd(0, 1280).toFixed(0)}px;top:${rnd(0, h0).toFixed(0)}px;--d:${rnd(2, 6).toFixed(1)}s;--s:${rnd(1, 3).toFixed(1)}px;animation-delay:-${rnd(0, 6).toFixed(1)}s"></i>`).join("");

// ---------------------------------------------------------------- 1) مواقيت الصلاة بكامل الشاشة
const MOSQUE = `<svg class="pr-mosque" viewBox="0 0 1280 220" preserveAspectRatio="xMidYMax slice" aria-hidden="true"><g fill="#070b1f">
  <rect x="150" y="96" width="18" height="124"/><path d="M146 96h26l-13-34z"/><rect x="143" y="120" width="32" height="6"/>
  <rect x="1112" y="96" width="18" height="124"/><path d="M1108 96h26l-13-34z"/><rect x="1105" y="120" width="32" height="6"/>
  <rect x="300" y="40" width="30" height="180"/><path d="M294 40h42l-21-48z"/><rect x="288" y="78" width="54" height="9"/><rect x="288" y="128" width="54" height="9"/>
  <rect x="950" y="40" width="30" height="180"/><path d="M944 40h42l-21-48z"/><rect x="938" y="78" width="54" height="9"/><rect x="938" y="128" width="54" height="9"/>
  <path d="M520 132 C 520 52, 760 52, 760 132 Z"/><rect x="636" y="34" width="8" height="26"/><circle cx="640" cy="30" r="7"/>
  <path d="M400 160 C 400 110, 500 110, 500 160 Z"/><path d="M780 160 C 780 110, 880 110, 880 160 Z"/>
  <rect x="380" y="158" width="520" height="62"/><rect x="480" y="130" width="320" height="40"/><rect x="0" y="206" width="1280" height="14"/></g>
  <g fill="#fbbf24" opacity=".75">${[420, 450, 480, 520, 560, 600, 680, 720, 760, 800, 830, 860].map((x) => `<path d="M${x} 200v-18a7 7 0 0 1 14 0v18z"/>`).join("")}
  <path d="M628 150v-22a12 12 0 0 1 24 0v22z"/></g></svg>`;
const MOON = `<svg class="pr-moon" viewBox="0 0 100 120" aria-hidden="true"><path d="M60 8 A52 52 0 1 0 60 112 A40 52 0 1 1 60 8Z" fill="#fef3c7"/></svg>`;
function svPrayer(el) {
  const p = clockData.prayer;
  el.innerHTML = `<div class="pr-sky">${starsHtml(90, 520)}</div>${MOON}${MOSQUE}
    <div class="pr-wrap"><div class="pr-clock js-tm"></div><div class="pr-date"><span class="js-dt"></span>${fmtHijri ? ` · <span class="js-hj"></span>` : ""}</div>
      <div class="pr-next"></div>
      <div class="pr-row">${p.times.map((t) => `<div class="pr-p${t.key === "sunrise" ? " sr" : ""}" data-k="${t.key}" data-t="${t.time}" data-n="${esc(t.name)}"><b>${esc(t.name)}</b><span class="ltr">${t.time}</span></div>`).join("")}</div>
      ${p.city ? `<div class="pr-city">${esc(p.city)}</div>` : ""}</div>`;
  const wrap = el.querySelector(".pr-wrap");
  const mins = (t) => { const [a, b] = t.split(":").map(Number); return a * 60 + b; };
  const upd = () => {
    const now = new Date(), nowM = now.getHours() * 60 + now.getMinutes();
    const cells = [...el.querySelectorAll(".pr-p")], cand = cells.filter((c) => c.dataset.k !== "sunrise");
    let nx = cand.find((c) => mins(c.dataset.t) > nowM), diff;
    if (nx) diff = mins(nx.dataset.t) - nowM; else { nx = cand[0]; diff = 1440 - nowM + mins(nx.dataset.t); }
    cells.forEach((c) => { c.classList.toggle("nx", c === nx); c.classList.toggle("past", mins(c.dataset.t) <= nowM && c !== nx); });
    const hh = Math.floor(diff / 60), mm = diff % 60;
    el.querySelector(".pr-next").innerHTML = `<span>${diff <= 1 ? `حان الآن وقت صلاة ${nm(nx.dataset.n)}` : `${AR ? "صلاة " : ""}<b>${nx.dataset.n}</b> ${inText(hh, mm, true)}`}</span>`;
  };
  upd();
  const id = setInterval(upd, 15000);
  const shift = setInterval(() => { wrap.style.transform = `translate(${rnd(-14, 14)}px, ${rnd(-10, 10)}px)`; }, 60000);
  return () => { clearInterval(id); clearInterval(shift); };
}

// ---------------------------------------------------------------- 2) صوري (كما كانت)
function svPhotos(el) {
  el.innerHTML = `<div class="blurbg"></div><div class="ph"></div><div class="blurbg"></div><div class="ph"></div>${SCLOCK}`;
  let timer = 0, alive = true;
  (async () => {
    let ids = [];
    if (me) { try { ids = (await api("/api/tv/wallpaper")).ids; } catch { /* */ } }
    if (!alive) return;
    if (!ids.length) {
      el.classList.add("empty");
      const clock = el.querySelector(".sclock");
      timer = setInterval(() => { clock.style.right = `${40 + Math.random() * 700}px`; clock.style.bottom = `${40 + Math.random() * 480}px`; }, 20000);
      return;
    }
    const phs = el.querySelectorAll(".ph"), bgs = el.querySelectorAll(".blurbg");
    let i = 0, k = 0;
    const next = () => {
      const img = new Image();
      img.onload = () => {
        const a = k % 2, b = 1 - a;
        phs[a].style.backgroundImage = bgs[a].style.backgroundImage = `url("${img.src}")`;
        phs[a].classList.add("show"); bgs[a].classList.add("show");
        phs[b].classList.remove("show"); bgs[b].classList.remove("show");
        k++;
      };
      img.src = `/api/tv/photo/${ids[i++ % ids.length]}/view`;
    };
    next();
    timer = setInterval(next, 12000);
  })();
  return () => { alive = false; clearInterval(timer); };
}

// ---------------------------------------------------------------- 3) نار (مدفأة): جزيئات لهب ناعمة فوق الحطب
const LOGS = `<svg class="fire-logs" viewBox="0 0 600 120" aria-hidden="true">
  <g transform="rotate(-8 300 80)"><rect x="90" y="62" width="420" height="40" rx="20" fill="#3b2314"/><ellipse cx="500" cy="82" rx="14" ry="20" fill="#7c4a26"/><ellipse cx="500" cy="82" rx="7" ry="11" fill="#a0673a"/></g>
  <g transform="rotate(9 300 80)"><rect x="80" y="70" width="430" height="38" rx="19" fill="#2c1a0e"/><ellipse cx="92" cy="89" rx="13" ry="19" fill="#6b3f20"/><ellipse cx="92" cy="89" rx="6" ry="10" fill="#94592f"/></g>
  <rect x="40" y="104" width="520" height="16" rx="8" fill="#1a0f08"/></svg>`;
function flameSprite(stops) {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d"), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  stops.forEach(([o, col]) => gr.addColorStop(o, col));
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  return c;
}
function svFire(el) {
  el.innerHTML = `<div class="fire-glow"></div>${LOGS}${SCLOCK}`;
  const { ctx } = svCanvas(el, "flames");
  el.querySelector(".fire-logs").before(el.querySelector(".flames"));
  const SPR = [
    flameSprite([[0, "rgba(255,236,160,.85)"], [0.3, "rgba(255,200,80,.55)"], [0.65, "rgba(255,140,30,.2)"], [1, "rgba(255,120,0,0)"]]),
    flameSprite([[0, "rgba(255,200,80,.85)"], [0.35, "rgba(255,130,20,.5)"], [1, "rgba(220,60,0,0)"]]),
    flameSprite([[0, "rgba(230,80,10,.6)"], [0.45, "rgba(170,30,5,.28)"], [1, "rgba(90,10,0,0)"]]),
  ];
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 1.5;
  const parts = [], sparks = [];
  return frameLoop((dt, t) => {
    // لهب جديد من فوق الحطب، أكثف في الوسط
    for (let n = 0; n < 12; n++) {
      const off = gauss() * 190;
      parts.push({ x: 640 + off, y: rnd(590, 615), vx: -off * 0.25 + rnd(-15, 15), vy: rnd(-230, -130) * (1 - Math.abs(off) / 420), life: 0, max: rnd(0.7, 1.5), s: rnd(70, 120) });
    }
    if (sparks.length < 40 && Math.random() < 0.4) sparks.push({ x: 640 + gauss() * 150, y: rnd(560, 600), vx: rnd(-25, 25), vy: rnd(-110, -50), life: 0, max: rnd(1.6, 3.4), r: rnd(1.2, 2.6) });
    ctx.clearRect(0, 0, 1280, 720);
    ctx.globalCompositeOperation = "lighter";
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      p.life += dt;
      const k = p.life / p.max;
      if (k >= 1) { parts.splice(i, 1); continue; }
      p.x += (p.vx + Math.sin(t * 3 + p.y * 0.02) * 22) * dt; p.y += p.vy * dt; p.vx *= 0.97;
      const size = p.s * (1 - k * 0.75), spr = SPR[k < 0.3 ? 0 : k < 0.65 ? 1 : 2];
      ctx.globalAlpha = Math.min(1, (1 - k) * 1.4) * 0.42;
      ctx.drawImage(spr, p.x - size / 2, p.y - size / 2, size, size * 1.25);
    }
    ctx.globalAlpha = 1;
    for (let i = sparks.length - 1; i >= 0; i--) {
      const p = sparks[i];
      p.life += dt; p.x += (p.vx + Math.sin(p.life * 6 + p.max) * 18) * dt; p.y += p.vy * dt;
      if (p.life > p.max) { sparks.splice(i, 1); continue; }
      const a = 1 - p.life / p.max;
      ctx.fillStyle = `rgba(255,${(150 + 100 * a) | 0},60,${a})`;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
    }
    ctx.globalCompositeOperation = "source-over";
  }, 30);
}

// ---------------------------------------------------------------- 4) نص: آيات وأحاديث وحِكم تتبدّل، أو نص يختاره المدير
function svText(el) {
  const custom = (settings.saver_text || "").trim();
  el.innerHTML = `<div class="tx-bg"></div><div class="tx-orbs">${Array.from({ length: 14 }, () => `<i style="left:${rnd(0, 1200) | 0}px;top:${rnd(0, 680) | 0}px;--z:${rnd(40, 160) | 0}px;--d:${rnd(14, 30) | 0}s;animation-delay:-${rnd(0, 20) | 0}s"></i>`).join("")}</div>
    <div class="tx-box"></div>${SCLOCK}`;
  const box = el.querySelector(".tx-box");
  let alive = true, timer = 0, stopLoop = null;
  if (custom) {
    box.classList.add("bounce");
    box.innerHTML = `<div class="tx-custom">${esc(custom)}</div>`;
    let x = 200, y = 200, vx = 70, vy = 48, hue = 0;
    stopLoop = frameLoop((dt) => {
      const w = box.offsetWidth, hh = box.offsetHeight;
      x += vx * dt; y += vy * dt;
      if (x < 0 || x + w > 1280) { vx = -vx; x = Math.max(0, Math.min(1280 - w, x)); hue += 60; }
      if (y < 0 || y + hh > 640) { vy = -vy; y = Math.max(0, Math.min(640 - hh, y)); hue += 60; }
      box.style.transform = `translate(${x}px, ${y}px)`;
      box.style.filter = `hue-rotate(${hue % 360}deg)`;
    }, 30);
  } else {
    let list = [], i = 0;
    const show = () => {
      if (!alive || !list.length) return;
      const t = list[i++ % list.length];
      box.classList.remove("in");
      setTimeout(() => {
        if (!alive) return;
        box.className = `tx-box rot ${t.kind}`;
        box.innerHTML = `<div class="lbl">${TEXT_ICON[t.kind] || "✨"} ${esc(t.label)}</div><div class="tx">${textBody(t)}</div>${t.source ? `<div class="src">${esc(t.source)}</div>` : ""}`;
        box.style.transform = `translate(${rnd(-110, 110) | 0}px, ${rnd(-60, 50) | 0}px)`;
        box.classList.add("in");
      }, 1200);
    };
    api("/api/tv/saver").then((d) => { list = d.texts || []; show(); timer = setInterval(show, 20000); }).catch(() => {
      box.className = "tx-box rot in"; box.innerHTML = `<div class="tx">HOME ANAB</div>`;
    });
  }
  return () => { alive = false; clearInterval(timer); stopLoop?.(); };
}

// ---------------------------------------------------------------- 5) أمطار فوق المدينة ليلاً
function skyline(seed, color, hmin, hmax, lit) {
  let x = 0, s = "", w = "";
  let r = seed;
  const R = () => { r = (r * 9301 + 49297) % 233280; return r / 233280; };
  while (x < 1280) {
    const bw = 40 + R() * 70, bh = hmin + R() * (hmax - hmin);
    s += `<rect x="${x.toFixed(0)}" y="${(720 - bh).toFixed(0)}" width="${(bw + 1).toFixed(0)}" height="${bh.toFixed(0)}"/>`;
    if (lit) for (let wy = 720 - bh + 12; wy < 700; wy += 18) for (let wx = x + 8; wx < x + bw - 10; wx += 14) if (R() < 0.16) w += `<rect x="${wx.toFixed(0)}" y="${wy.toFixed(0)}" width="6" height="8"/>`;
    x += bw;
  }
  return `<svg class="rn-city" viewBox="0 0 1280 720" preserveAspectRatio="none" aria-hidden="true"><g fill="${color}">${s}</g><g fill="#fcd34d" opacity=".55">${w}</g></svg>`;
}
function svRain(el) {
  el.innerHTML = `<div class="rn-sky"></div>${skyline(7, "#1e293b", 120, 300, false)}${skyline(31, "#0f172a", 60, 220, true)}<div class="rn-flash"></div>${SCLOCK}`;
  const { ctx } = svCanvas(el, "rain");
  const drops = [], ripples = [], wind = -0.18;
  const mk = (top) => {
    const z = Math.random(), sp = 520 + z * 700;
    return { x: rnd(-60, 1340), y: top ? rnd(-720, 0) : -40, len: 10 + z * 26, sp, z, ground: 650 + z * 60 };
  };
  for (let i = 0; i < 320; i++) drops.push(mk(true));
  const flash = el.querySelector(".rn-flash");
  let nextFlash = rnd(20, 50), tt = 0;
  const stop = frameLoop((dt) => {
    tt += dt;
    if (tt > nextFlash) { tt = 0; nextFlash = rnd(25, 70); flash.classList.remove("go"); void flash.offsetWidth; flash.classList.add("go"); }
    ctx.clearRect(0, 0, 1280, 720);
    ctx.lineCap = "round";
    for (const d of drops) {
      d.y += d.sp * dt; d.x += d.sp * wind * dt;
      if (d.y > d.ground) {
        if (d.z > 0.45 && ripples.length < 90) ripples.push({ x: d.x, y: d.y, r: 1, max: 6 + d.z * 12, a: 0.5 });
        Object.assign(d, mk(false));
        continue;
      }
      ctx.strokeStyle = `rgba(186,206,235,${0.18 + d.z * 0.42})`;
      ctx.lineWidth = 0.6 + d.z * 1.3;
      ctx.beginPath(); ctx.moveTo(d.x, d.y); ctx.lineTo(d.x - d.len * wind, d.y - d.len); ctx.stroke();
    }
    for (let i = ripples.length - 1; i >= 0; i--) {
      const p = ripples[i];
      p.r += 26 * dt; p.a -= 0.9 * dt;
      if (p.a <= 0 || p.r > p.max) { ripples.splice(i, 1); continue; }
      ctx.strokeStyle = `rgba(186,206,235,${p.a})`; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(p.x, p.y, p.r, p.r * 0.3, 0, 0, 7); ctx.stroke();
    }
  }, 30);
  return stop;
}

// ---------------------------------------------------------------- 6) درب التبانة
function galaxyImage(D) {
  const c = document.createElement("canvas");
  c.width = c.height = D;
  const g = c.getContext("2d"), m = D / 2;
  g.fillStyle = "#02030b"; g.fillRect(0, 0, D, D);
  g.translate(m, m); g.rotate(-0.55); g.translate(-m, -m);
  const gauss = () => (Math.random() + Math.random() + Math.random() + Math.random() - 2) / 2;
  g.globalCompositeOperation = "lighter";
  for (let i = 0; i < 1100; i++) {
    const t = Math.random() * 2 - 1, x = m + t * D * 0.55, y = m + gauss() * D * 0.07 * (1.15 - Math.abs(t) * 0.4);
    const core = Math.max(0, 1 - Math.abs(t + 0.1) * 2.2), r = rnd(18, 80) * (D / 1500);
    const col = core > 0.3 ? `255,${(190 + 40 * Math.random()) | 0},${(140 + 50 * Math.random()) | 0}` : Math.random() < 0.5 ? "150,170,255" : "190,150,255";
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, `rgba(${col},${(0.035 + core * 0.05).toFixed(3)})`); gr.addColorStop(1, `rgba(${col},0)`);
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  g.globalCompositeOperation = "source-over";
  for (let i = 0; i < 260; i++) {
    const t = Math.random() * 2 - 1, x = m + t * D * 0.5, y = m + gauss() * D * 0.022 + Math.sin(t * 5) * D * 0.012, r = rnd(8, 26) * (D / 1500);
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, "rgba(2,3,11,.15)"); gr.addColorStop(1, "rgba(2,3,11,0)");
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  g.globalCompositeOperation = "lighter";
  const k = D / 1500;
  for (let i = 0; i < 4200; i++) {
    const near = Math.random() < 0.55, x = near ? m + (Math.random() * 2 - 1) * D * 0.55 : Math.random() * D, y = near ? m + gauss() * D * 0.11 : Math.random() * D;
    const r = (Math.random() < 0.96 ? rnd(0.3, 0.9) : rnd(1, 1.7)) * k, tint = Math.random();
    g.fillStyle = `rgba(${tint < 0.2 ? "255,214,170" : tint < 0.4 ? "180,200,255" : "255,255,255"},${rnd(0.35, 1).toFixed(2)})`;
    g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  for (let i = 0; i < 30; i++) {
    const x = Math.random() * D, y = Math.random() * D, r = rnd(5, 11) * k;
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, "rgba(255,255,255,.95)"); gr.addColorStop(0.2, "rgba(200,220,255,.4)"); gr.addColorStop(1, "rgba(200,220,255,0)");
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  return c;
}
const HILLS = `<svg class="gx-hills" viewBox="0 0 1280 200" preserveAspectRatio="none" aria-hidden="true"><g fill="#010207">
  <path d="M0 120 C 180 60, 320 70, 470 110 C 620 150, 760 80, 940 70 C 1080 62, 1180 96, 1280 90 V200 H0Z"/>
  ${[[150, 92], [190, 84], [230, 90], [1010, 74], [1045, 66], [1085, 76]].map(([x, y]) => `<path d="M${x} ${y - 46}l15 46h-30z"/><path d="M${x} ${y - 30}l19 42h-38z"/><rect x="${x - 2}" y="${y + 8}" width="4" height="10"/>`).join("")}</g></svg>`;
function svGalaxy(el) {
  const k = Math.max(1, Math.min(1.6, scale || 1)), D = Math.ceil(1470 * k);
  const bg = galaxyImage(D);
  bg.className = "gx-bg";
  bg.style.width = bg.style.height = "1470px";
  el.appendChild(bg);
  el.insertAdjacentHTML("beforeend", `${HILLS}${SCLOCK}`);
  const { ctx } = svCanvas(el, "gx-fx");
  const tw = Array.from({ length: 140 }, () => ({ x: rnd(0, 1280), y: rnd(0, 600), r: rnd(0.6, 1.6), ph: rnd(0, 6.3), f: rnd(0.6, 2) }));
  let meteor = null, nextM = rnd(5, 14), tt = 0;
  return frameLoop((dt, t) => {
    ctx.clearRect(0, 0, 1280, 720);
    for (const s of tw) {
      const a = 0.25 + 0.75 * (0.5 + 0.5 * Math.sin(t * s.f + s.ph));
      ctx.fillStyle = `rgba(255,255,255,${a.toFixed(2)})`; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 7); ctx.fill();
    }
    tt += dt;
    if (!meteor && tt > nextM) { tt = 0; nextM = rnd(8, 20); meteor = { x: rnd(200, 1200), y: rnd(20, 260), vx: rnd(-700, -480), vy: rnd(160, 300), life: 0 }; }
    if (meteor) {
      const p = meteor;
      p.life += dt; p.x += p.vx * dt; p.y += p.vy * dt;
      const a = Math.max(0, 1 - p.life / 0.9);
      const gr = ctx.createLinearGradient(p.x, p.y, p.x - p.vx * 0.18, p.y - p.vy * 0.18);
      gr.addColorStop(0, `rgba(255,255,255,${a})`); gr.addColorStop(1, "rgba(255,255,255,0)");
      ctx.strokeStyle = gr; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 0.18, p.y - p.vy * 0.18); ctx.stroke();
      if (p.life > 0.9) meteor = null;
    }
  }, 20);
}

// ================================================================ البند 61: شاشات توقف جديدة (كلها مرسومة في الجهاز، بلا إنترنت)
// التقويم: المناسبات الهجرية القادمة من تقويم أم القرى في المتصفح نفسه
let fmtHijriNum = null;
try { fmtHijriNum = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura-nu-latn", { day: "numeric", month: "numeric" }); } catch { /* غير مدعوم */ }
const OCCASIONS = [[9, 1, "رمضان المبارك", "🌙"], [10, 1, "عيد الفطر", "🎉"], [12, 10, "عيد الأضحى", "🐑"], [1, 1, "رأس السنة الهجرية", "📅"], [3, 12, "المولد النبوي", "✨"]];
function hijriDM(d) {
  if (!fmtHijriNum) return null;
  const p = Object.fromEntries(fmtHijriNum.formatToParts(d).map((x) => [x.type, x.value]));
  return [+p.month, +p.day];
}
function nextOccasions(n = 3) {
  if (!fmtHijriNum) return [];
  const out = [], seen = new Set(), d = new Date(); d.setHours(12, 0, 0, 0);
  for (let i = 0; i < 390 && out.length < n; i++) {
    const [m, dd] = hijriDM(d);
    for (const [om, od, name, ic] of OCCASIONS) {
      if (m === om && dd === od && !seen.has(name)) { seen.add(name); out.push({ name, ic, days: i }); }
    }
    d.setDate(d.getDate() + 1);
  }
  return out;
}
const occDays = (n) => (n === 0 ? "اليوم" : n === 1 ? "غداً" : n === 2 ? "بعد يومين" : n <= 10 ? `بعد ${n} أيام` : `بعد ${n} يوماً`);
const WEEK_AR = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
function monthGrid(now) {
  const y = now.getFullYear(), m = now.getMonth(), first = new Date(y, m, 1).getDay(), days = new Date(y, m + 1, 0).getDate();
  let cells = ["ح", "ن", "ث", "ر", "خ", "ج", "س"].map((w) => `<b>${w}</b>`).join("");
  for (let i = 0; i < first; i++) cells += "<span></span>";
  for (let d = 1; d <= days; d++) cells += `<span class="${d === now.getDate() ? "on" : ""}">${d}</span>`;
  return cells;
}
function svCalendar(el) {
  const draw = () => {
    const now = new Date();
    const mon = new Intl.DateTimeFormat(AR ? "ar" : LOC, { month: "long", year: "numeric", numberingSystem: "latn" }).format(now);
    const occ = nextOccasions(3);
    el.innerHTML = `<div class="cl-wrap">
      <div class="cl-main"><div class="cl-day">${WEEK_AR[now.getDay()]}</div><div class="cl-num">${now.getDate()}</div>
        <div class="cl-g js-dt"></div>${fmtHijri ? `<div class="cl-h">🌙 <span class="js-hj"></span></div>` : ""}<div class="cl-tm js-tm"></div></div>
      <div class="cl-side"><div class="cl-mon">${esc(mon)}</div><div class="cl-grid">${monthGrid(now)}</div>
        ${occ.length ? `<div class="cl-occ">${occ.map((o) => `<div><span>${o.ic}</span><b>${o.name}</b><i>${occDays(o.days)}</i></div>`).join("")}</div>` : ""}</div></div>`;
    tick();
  };
  draw();
  const wrap = () => el.querySelector(".cl-wrap");
  let day = new Date().getDate();
  const id = setInterval(() => {
    if (new Date().getDate() !== day) { day = new Date().getDate(); draw(); }
    const w = wrap(); if (w) w.style.transform = `translate(${rnd(-16, 16)}px, ${rnd(-10, 10)}px)`;
  }, 60000);
  return () => clearInterval(id);
}

// الطبيعة: جبال وبحيرة وأشجار، والسماء حسب وقت اليوم (فجر، نهار، غروب، ليل)
function natureSky() {
  const h0 = new Date().getHours();
  if (h0 >= 5 && h0 < 7) return ["dawn", "#fbcfe8", "#fde68a", "#6d6a9c"];
  if (h0 >= 7 && h0 < 17) return ["day", "#7dd3fc", "#e0f2fe", "#4b7f6b"];
  if (h0 >= 17 && h0 < 19) return ["dusk", "#f97316", "#fcd34d", "#5b3a56"];
  return ["night", "#0b1026", "#1e2a52", "#141c33"];
}
function ridge(seed, y0, amp, step = 40) {
  let r = seed; const R = () => { r = (r * 9301 + 49297) % 233280; return r / 233280; };
  let d = `M0 ${y0}`;
  for (let x = 0; x <= 1280; x += step) d += ` L${x} ${(y0 - R() * amp).toFixed(0)}`;
  return `${d} L1280 720 L0 720Z`;
}
function pines(seed, n, yMin, yMax, color) {
  let r = seed; const R = () => { r = (r * 9301 + 49297) % 233280; return r / 233280; };
  let s = "";
  for (let i = 0; i < n; i++) {
    const x = R() * 1280, y = yMin + R() * (yMax - yMin), hh = 40 + R() * 50, w = hh * 0.42;
    s += `<path d="M${x.toFixed(0)} ${(y - hh).toFixed(0)}l${w.toFixed(0)} ${hh.toFixed(0)}h${(-2 * w).toFixed(0)}z"/>`;
  }
  return `<g fill="${color}">${s}</g>`;
}
function svNature(el) {
  const [mode, top, bot, land] = natureSky();
  const night = mode === "night";
  el.style.background = `linear-gradient(180deg, ${top} 0%, ${bot} 62%, ${land} 100%)`;
  const sun = night ? `<circle cx="1010" cy="150" r="46" fill="#fef3c7" opacity=".95"/>` : `<circle cx="${mode === "day" ? 980 : 640}" cy="${mode === "day" ? 140 : 380}" r="${mode === "day" ? 54 : 70}" fill="${mode === "day" ? "#fff7d6" : "#fde68a"}" opacity=".95"/>`;
  const m1 = night ? "#1f2a4a" : mode === "day" ? "#6b8fb3" : "#7c5b8a", m2 = night ? "#18213b" : mode === "day" ? "#4e7a6a" : "#5a3f62", m3 = night ? "#0f1629" : mode === "day" ? "#2f5d45" : "#3b2a45";
  el.innerHTML = `<svg class="nt-land" viewBox="0 0 1280 720" preserveAspectRatio="none" aria-hidden="true">${sun}
    <path d="${ridge(11, 420, 170, 80)}" fill="${m1}"/><path d="${ridge(23, 470, 110, 60)}" fill="${m2}"/>
    <rect x="0" y="500" width="1280" height="220" fill="${night ? "#0c1430" : mode === "day" ? "#5fa8d3" : "#b45f5a"}" opacity=".85"/>
    <g opacity=".22" transform="translate(0,1000) scale(1,-1)"><path d="${ridge(23, 470, 110, 60)}" fill="${m2}"/></g>
    <path d="M0 560 C 200 540, 360 600, 640 590 C 900 580, 1080 540, 1280 560 V720 H0Z" fill="${m3}"/>
    ${pines(5, 26, 600, 700, night ? "#070b17" : "#1f4030")}</svg>${SCLOCK}`;
  const { ctx } = svCanvas(el, "nt-fx");
  const clouds = Array.from({ length: night ? 0 : 6 }, () => ({ x: rnd(0, 1280), y: rnd(40, 260), s: rnd(0.6, 1.4), v: rnd(6, 16) }));
  const birds = [];
  const flies = Array.from({ length: night ? 40 : 0 }, () => ({ x: rnd(0, 1280), y: rnd(560, 700), ph: rnd(0, 6.3), v: rnd(0.3, 1) }));
  const stars = Array.from({ length: night ? 120 : 0 }, () => ({ x: rnd(0, 1280), y: rnd(0, 380), r: rnd(0.5, 1.5), ph: rnd(0, 6.3) }));
  const ripple = [];
  let nextBird = 3;
  return frameLoop((dt, t) => {
    ctx.clearRect(0, 0, 1280, 720);
    for (const s of stars) { ctx.fillStyle = `rgba(255,255,255,${(0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t * 1.3 + s.ph))).toFixed(2)})`; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 7); ctx.fill(); }
    for (const c of clouds) {
      c.x += c.v * dt; if (c.x > 1400) c.x = -200;
      ctx.fillStyle = mode === "day" ? "rgba(255,255,255,.85)" : "rgba(255,220,200,.55)";
      for (const [dx, dy, r] of [[0, 0, 34], [34, -12, 40], [72, 0, 32], [36, 10, 30]]) { ctx.beginPath(); ctx.arc(c.x + dx * c.s, c.y + dy * c.s, r * c.s, 0, 7); ctx.fill(); }
    }
    if (!night) {
      nextBird -= dt;
      if (nextBird < 0 && birds.length < 6) { nextBird = rnd(6, 14); const y = rnd(120, 300); for (let i = 0; i < 3; i++) birds.push({ x: -40 - i * 36, y: y + i * 14, ph: rnd(0, 6) }); }
      ctx.strokeStyle = "rgba(30,30,40,.7)"; ctx.lineWidth = 2;
      for (let i = birds.length - 1; i >= 0; i--) {
        const b = birds[i]; b.x += 70 * dt; if (b.x > 1340) { birds.splice(i, 1); continue; }
        const w = 8 * Math.sin(t * 8 + b.ph);
        ctx.beginPath(); ctx.moveTo(b.x - 12, b.y - w); ctx.quadraticCurveTo(b.x - 5, b.y - 4, b.x, b.y); ctx.quadraticCurveTo(b.x + 5, b.y - 4, b.x + 12, b.y - w); ctx.stroke();
      }
    }
    for (const f of flies) {
      f.x += Math.cos(t * f.v + f.ph) * 12 * dt; f.y += Math.sin(t * f.v * 1.3 + f.ph) * 10 * dt;
      const a = 0.5 + 0.5 * Math.sin(t * 2 + f.ph), g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, 7);
      g.addColorStop(0, `rgba(253,230,138,${a})`); g.addColorStop(1, "rgba(253,230,138,0)");
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(f.x, f.y, 7, 0, 7); ctx.fill();
    }
    // لمعان خفيف على سطح البحيرة
    if (ripple.length < 30) ripple.push({ x: rnd(0, 1280), y: rnd(505, 570), l: rnd(10, 40), a: 0 , s: rnd(0.3, 0.8) });
    for (let i = ripple.length - 1; i >= 0; i--) {
      const r = ripple[i]; r.a += r.s * dt; const a = Math.sin(Math.min(Math.PI, r.a)) * 0.35;
      if (r.a > Math.PI) { ripple.splice(i, 1); continue; }
      ctx.strokeStyle = `rgba(255,255,255,${a.toFixed(2)})`; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(r.x, r.y); ctx.lineTo(r.x + r.l, r.y); ctx.stroke();
    }
  }, 24);
}

// تحت الماء: أسماك وفقاعات وأعشاب بحرية وأشعة ضوء
const FISH_COLORS = [["#f97316", "#fdba74"], ["#facc15", "#fef08a"], ["#38bdf8", "#bae6fd"], ["#f472b6", "#fbcfe8"], ["#a78bfa", "#ddd6fe"], ["#34d399", "#a7f3d0"]];
function svSea(el) {
  el.innerHTML = `<div class="sea-bg"></div><div class="sea-rays"><i></i><i></i><i></i><i></i></div>${SCLOCK}`;
  const { ctx } = svCanvas(el, "sea-fx");
  const fish = Array.from({ length: LITE ? 6 : 11 }, () => {
    const dir = Math.random() < 0.5 ? 1 : -1, [c1, c2] = FISH_COLORS[(Math.random() * FISH_COLORS.length) | 0];
    return { x: rnd(0, 1280), y: rnd(120, 560), s: rnd(0.6, 1.5), v: rnd(30, 70) * dir, ph: rnd(0, 6.3), c1, c2 };
  });
  const bubbles = [], weeds = Array.from({ length: 16 }, (_, i) => ({ x: 30 + i * 82 + rnd(-20, 20), h: rnd(90, 200), ph: rnd(0, 6.3), c: Math.random() < 0.5 ? "#15803d" : "#166534" }));
  const sand = (x) => 660 + Math.sin(x / 90) * 10 + Math.sin(x / 37) * 4;
  return frameLoop((dt, t) => {
    ctx.clearRect(0, 0, 1280, 720);
    for (const w of weeds) {
      ctx.strokeStyle = w.c; ctx.lineWidth = 9; ctx.lineCap = "round"; ctx.beginPath();
      const by = sand(w.x); ctx.moveTo(w.x, by);
      for (let k = 1; k <= 6; k++) { const yy = by - (w.h * k) / 6; ctx.lineTo(w.x + Math.sin(t * 1.1 + w.ph + k * 0.6) * k * 4, yy); }
      ctx.stroke();
    }
    ctx.fillStyle = "#c2a36b"; ctx.beginPath(); ctx.moveTo(0, 720);
    for (let x = 0; x <= 1280; x += 20) ctx.lineTo(x, sand(x));
    ctx.lineTo(1280, 720); ctx.fill();
    for (const f of fish) {
      f.x += f.v * dt; f.y += Math.sin(t * 0.8 + f.ph) * 8 * dt;
      if (f.v > 0 && f.x > 1360) f.x = -80; if (f.v < 0 && f.x < -80) f.x = 1360;
      const d = f.v > 0 ? 1 : -1, L = 46 * f.s, H = 20 * f.s, tail = Math.sin(t * 9 + f.ph) * 5 * f.s;
      ctx.save(); ctx.translate(f.x, f.y); ctx.scale(d, 1);
      ctx.fillStyle = f.c1; ctx.beginPath(); ctx.moveTo(-L * 0.45, 0); ctx.lineTo(-L * 0.85, -H * 0.7 + tail); ctx.lineTo(-L * 0.85, H * 0.7 + tail); ctx.fill();
      const g = ctx.createLinearGradient(0, -H, 0, H); g.addColorStop(0, f.c2); g.addColorStop(1, f.c1);
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, L * 0.5, H * 0.5, 0, 0, 7); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(L * 0.28, -H * 0.1, 3.4 * f.s, 0, 7); ctx.fill();
      ctx.fillStyle = "#0f172a"; ctx.beginPath(); ctx.arc(L * 0.3, -H * 0.1, 1.8 * f.s, 0, 7); ctx.fill();
      ctx.restore();
      if (Math.random() < 0.006 && bubbles.length < 70) bubbles.push({ x: f.x + 20 * d * f.s, y: f.y, r: rnd(2, 4), v: rnd(30, 60), ph: rnd(0, 6) });
    }
    if (Math.random() < 0.15 && bubbles.length < 70) bubbles.push({ x: rnd(0, 1280), y: 700, r: rnd(2, 7), v: rnd(40, 90), ph: rnd(0, 6) });
    ctx.strokeStyle = "rgba(255,255,255,.55)"; ctx.lineWidth = 1.2;
    for (let i = bubbles.length - 1; i >= 0; i--) {
      const b = bubbles[i]; b.y -= b.v * dt; b.x += Math.sin(t * 3 + b.ph) * 10 * dt;
      if (b.y < -10) { bubbles.splice(i, 1); continue; }
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 7); ctx.stroke();
    }
  }, 30);
}

// ثلج يتساقط على قرية في الليل
function svSnow(el) {
  el.innerHTML = `<div class="sn-sky"></div>${skyline(53, "#1e293b", 50, 140, true)}<div class="sn-ground"></div>${SCLOCK}`;
  const { ctx } = svCanvas(el, "sn-fx");
  const flakes = Array.from({ length: LITE ? 140 : 300 }, () => ({ x: rnd(0, 1280), y: rnd(-720, 720), z: Math.random(), ph: rnd(0, 6.3) }));
  return frameLoop((dt, t) => {
    ctx.clearRect(0, 0, 1280, 720);
    for (const f of flakes) {
      f.y += (25 + f.z * 60) * dt; f.x += Math.sin(t * 0.7 + f.ph) * (8 + f.z * 14) * dt;
      if (f.y > 730) { f.y = -10; f.x = rnd(0, 1280); }
      ctx.fillStyle = `rgba(255,255,255,${(0.35 + f.z * 0.6).toFixed(2)})`; ctx.beginPath(); ctx.arc(f.x, f.y, 0.8 + f.z * 2.6, 0, 7); ctx.fill();
    }
  }, 30);
}

// القمر والنجوم: شكل القمر الحقيقي الليلة (طور القمر) والتاريخ الهجري
const MOON_NAMES = ["محاق", "هلال", "تربيع أول", "أحدب متزايد", "بدر", "أحدب متناقص", "تربيع أخير", "هلال أخير"];
function moonPhase(d = new Date()) {
  const syn = 29.530588853, ref = Date.UTC(2000, 0, 6, 18, 14);
  return ((((d.getTime() - ref) / 86400000) % syn) + syn) % syn / syn;   // 0 محاق، 0.5 بدر
}
function svMoon(el) {
  const ph = moonPhase(), name = MOON_NAMES[Math.round(ph * 8) % 8];
  el.innerHTML = `<div class="mn-sky">${starsHtml(160)}</div><div class="mn-info"><b>${name}</b>${fmtHijri ? `<span class="js-hj"></span>` : ""}</div>${HILLS}${SCLOCK}`;
  const { ctx } = svCanvas(el, "mn-fx");
  const R = 120, cx = 640, cy = 300;
  const drawMoon = (glow) => {
    const g = ctx.createRadialGradient(cx, cy, R * 0.8, cx, cy, R * 2.4);
    g.addColorStop(0, `rgba(254,243,199,${0.18 * glow})`); g.addColorStop(1, "rgba(254,243,199,0)");
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R * 2.4, 0, 7); ctx.fill();
    ctx.fillStyle = "#1e2440"; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.fill();
    // الجزء المضيء: نصف دائرة + قطع ناقص حسب الطور
    const k = Math.cos(ph * 2 * Math.PI), wax = ph < 0.5;
    ctx.fillStyle = "#fef3c7"; ctx.beginPath();
    ctx.arc(cx, cy, R, -Math.PI / 2, Math.PI / 2, !wax);
    ctx.ellipse(cx, cy, Math.abs(k) * R, R, 0, Math.PI / 2, -Math.PI / 2, (k > 0) === wax ? true : false);
    ctx.fill();
    ctx.fillStyle = "rgba(180,160,120,.18)";
    for (const [dx, dy, r] of [[-30, -40, 18], [35, 20, 24], [-10, 50, 12], [50, -45, 10]]) { ctx.beginPath(); ctx.arc(cx + dx, cy + dy, r, 0, 7); ctx.fill(); }
  };
  return frameLoop((dt, t) => { ctx.clearRect(0, 0, 1280, 720); drawMoon(0.8 + 0.2 * Math.sin(t * 0.5)); }, 8);
}

// ساعة كبيرة بلون يتغير ببطء وتتحرك قليلاً (حتى لا تحترق الشاشة)
function svClock(el) {
  el.innerHTML = `<div class="ck-wrap"><div class="ck-tm"><span class="js-tm"></span><i class="ck-s"></i></div><div class="ck-dt"><span class="js-dt"></span>${fmtHijri ? ` · <span class="js-hj"></span>` : ""}</div></div>`;
  const w = el.querySelector(".ck-wrap"), s = el.querySelector(".ck-s");
  let hue = rnd(0, 360);
  const id = setInterval(() => {
    s.textContent = String(new Date().getSeconds()).padStart(2, "0");
    hue = (hue + 0.4) % 360; w.style.setProperty("--h", hue.toFixed(0));
  }, 1000);
  const mv = setInterval(() => { w.style.transform = `translate(${rnd(-180, 180)}px, ${rnd(-120, 120)}px)`; }, 60000);
  return () => { clearInterval(id); clearInterval(mv); };
}

let wakeLock = null;
async function keepAwake() {
  if (!settings.nosleep || !navigator.wakeLock || document.visibilityState !== "visible") return;
  try { if (!wakeLock || wakeLock.released) wakeLock = await navigator.wakeLock.request("screen"); } catch { /* غير متاح */ }
}
// وضع خفيف: للأجهزة الضعيفة (تلقائياً) أو من لوحة التحكم ← وضع التلفاز
let LITE = false;
function applyLite() {
  const auto = (navigator.deviceMemory || 8) <= 2 || (navigator.hardwareConcurrency || 8) <= 2;
  LITE = settings.lite === "on" || (settings.lite !== "off" && auto);
  document.documentElement.classList.toggle("lite", LITE);
}
// الليل: خلفية بإضاءة خفيفة جداً ومواقيت الصلاة واضحة، حتى لا يزعج الضوء العين.
// من العشاء حتى الشروق (أو 21:00–06:00 إن لم تُضبط المواقيت)، ويمكن إيقافه من لوحة التحكم
function isNightNow() {
  if ((settings.night_dim || "auto") === "off") return false;
  const t = (clockData && clockData.prayer && clockData.prayer.times) || (me && me.prayer && me.prayer.times) || [];
  const at = (k) => (t.find((x) => x.key === k) || {}).time;
  const toM = (v) => { const [a, b] = v.split(":").map(Number); return a * 60 + b; };
  const now = new Date(), m = now.getHours() * 60 + now.getMinutes();
  const from = at("isha") ? toM(at("isha")) : 21 * 60;
  const to = at("sunrise") ? toM(at("sunrise")) : at("fajr") ? toM(at("fajr")) : 6 * 60;
  return from > to ? m >= from || m < to : m >= from && m < to;
}
function applyNightDim() { document.documentElement.classList.toggle("night-dim", isNightNow()); }
setInterval(applyNightDim, 60000);
function applyPrefs() {
  applyLite();
  applyNightDim();
  fit();
  if (settings.nosleep) keepAwake();
  else if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
}
document.addEventListener("visibilitychange", keepAwake);

// تحديث المواقيت وكلمة اليوم كل نصف ساعة (وعند منتصف الليل)
let clockData = null;
async function loadClock(refresh = true) {
  try {
    clockData = await api("/api/tv/clock");
    if (refresh) stack.forEach((s) => s.refresh?.(clockData));
  } catch { /* */ }
}
setInterval(loadClock, 30 * 60000);
setTimeout(() => loadClock(false), 3000);

// إعدادات التلفاز من لوحة التحكم تُطبَّق خلال دقيقة، بلا إعادة تحميل
let settingsSig = "";
setInterval(async () => {
  if (document.hidden) return;
  let r;
  try { r = await api("/api/tv/settings"); } catch { return; }
  const sig = JSON.stringify(r.settings);
  if (!settingsSig) { settingsSig = sig; return; }
  if (sig === settingsSig) return;
  if ((r.settings.lang || "ar") !== (window.FORCE_LANG || "ar")) {   // تغيّرت لغة الواجهة: نعيد تحميل الصفحة (إلا أثناء مشاهدة أو لعب)
    const t = top();
    if (!(t && t.busy?.())) location.reload();
    return;
  }
  settingsSig = sig;
  settings = r.settings;
  applyPrefs();
  const t = top();
  if (me && t && t.home && !t.busy?.() && !saverEl) homeScreen();   // على الرئيسية: نعيد رسمها بالإعدادات الجديدة
}, 60000);

// ============================================================== الأذان
const adhanDone = {};
const hmShift = (hm, m) => { const [a, b] = hm.split(":").map(Number); const t = (a * 60 + b + m + 1440) % 1440; return `${pad(Math.floor(t / 60))}:${pad(t % 60)}`; };
function localDay(d = new Date()) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function chime(seconds = 7) {
  try {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    const notes = [523.25, 659.25, 783.99, 659.25, 523.25, 392];
    for (let i = 0; i < seconds; i++) {
      const o = ac.createOscillator(), g = ac.createGain(), t = ac.currentTime + i * 1.1;
      o.type = "sine"; o.frequency.value = notes[i % notes.length];
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);
      o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 1.7);
    }
    setTimeout(() => ac.close(), seconds * 1100 + 2000);
  } catch { /* */ }
}
function playingMedia() {
  const out = [];
  const scan = (doc) => { try { doc.querySelectorAll("video, audio").forEach((m) => { if (!m.paused && !m.ended) out.push(m); }); doc.querySelectorAll("iframe").forEach((f) => { try { scan(f.contentDocument); } catch { /* */ } }); } catch { /* */ } };
  scan(document);
  return out;
}
function playAdhan(t, c) {
  const a = c.adhan;
  const paused = a.pause ? playingMedia() : [];
  paused.forEach((m) => m.pause());
  const ov = h(`<div class="adhan-ov"><div class="adhan-card"><div class="emo mosque">🕌</div><h2>حان الآن وقت صلاة ${nm(esc(t.name))}</h2>
    <p>${esc(c.prayer.city || "")} · <span class="ltr">${esc(t.time)}</span></p><small>اضغط أي زر لإيقاف الأذان</small></div></div>`);
  stage.appendChild(ov);
  let au = null, done = false;
  const finish = () => {
    if (done) return;
    done = true;
    document.removeEventListener("keydown", stopKey, true);
    au?.pause();
    ov.classList.add("out"); setTimeout(() => ov.remove(), 600);
    setTimeout(() => paused.forEach((m) => m.play().catch(() => {})), 1200);
  };
  const stopKey = (e) => { e.stopPropagation(); e.preventDefault(); finish(); };
  document.addEventListener("keydown", stopKey, true);
  const src = t.key === "fajr" && a.files.fajr ? "/api/tv/adhan/fajr" : a.files.main ? "/api/tv/adhan/main" : null;
  if (src) {
    au = new Audio(src); au.volume = Math.max(0.1, Math.min(1, (a.volume || 80) / 100));
    au.onended = () => setTimeout(finish, 4000);
    au.onerror = () => { chime(); setTimeout(finish, 12000); };
    au.play().catch(() => { chime(); setTimeout(finish, 12000); });
  } else { chime(); setTimeout(finish, 15000); }
  setTimeout(finish, 6 * 60000);
}
function adhanTick() {
  const c = clockData;
  if (!c || !c.adhan || !c.adhan.on || !c.prayer || !c.prayer.times) return;
  const now = new Date(), day = localDay(now);
  if (c.prayer.date && c.prayer.date !== day) { loadClock(); return; }
  const hm = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  for (const t of c.prayer.times) {
    if (t.key === "sunrise" || !(c.adhan.prayers || []).includes(t.key)) continue;
    const k = day + t.key;
    if (t.time === hm && !adhanDone[k]) { adhanDone[k] = 1; playAdhan(t, c); }
    if (c.adhan.remind && hmShift(t.time, -c.adhan.remind) === hm && !adhanDone[k + "r"]) {
      adhanDone[k + "r"] = 1; chime(2); toast(`🕌 بعد ${c.adhan.remind} دقيقة: صلاة ${nm(t.name)}`, 10000);
    }
  }
}
setInterval(adhanTick, 15000);

// ============================================================== يد التحكم (بلايستيشن وغيرها)
// الزر السفلي موافق، الأيمن رجوع، الأسهم أو العصا للتنقل، L1/R1 السابق/التالي، L2/R2 الصوت، Options تشغيل/إيقاف، PS الرئيسية.
const padPrefs = { swap: false, rumble: true };
try { Object.assign(padPrefs, JSON.parse(localStorage.getItem("tvpad") || "{}")); } catch { /* */ }
const savePad = () => { try { localStorage.setItem("tvpad", JSON.stringify(padPrefs)); } catch { /* */ } };
let padPrev = {}, padRep = {}, padState = {}, padName = "";
// البند 49: اليد الأساسية (اللاعب 1) ثابتة في الواجهة وفي كل الألعاب: أول يد يُضغط فيها زر،
// أو اليد التي يختارها المدير («اختيار اليد الأساسية»، وتُحفظ باسمها فترجع أساسية عند اتصالها من جديد)
let PADSEEN = [], PADMAIN = null;
const MAIN_KEY = "hsef-pad-main";
const livePads = () => { try { return [...navigator.getGamepads()].filter((g) => g && g.connected && !/motion sensors|touchpad|accelerometer|gyro/i.test(g.id || "")); } catch { return []; } };
function setMainPad(i, save) {
  PADMAIN = i;
  const g = livePads().find((x) => x.index === i);
  if (save && g) { try { localStorage.setItem(MAIN_KEY, g.id); } catch { /* */ } }
}
function padTouch(gp) {
  if (!PADSEEN.includes(gp.index)) PADSEEN.push(gp.index);
  if (PADMAIN == null || !livePads().some((x) => x.index === PADMAIN)) setMainPad(gp.index, false);
}
// ترتيب اللاعبين: [اللاعب 1، اللاعب 2، …] بأرقام الأيادي. تقرؤه الألعاب (kit.js) من هنا
window.hsefPadOrder = () => {
  const live = livePads().map((g) => g.index);
  return [PADMAIN, ...PADSEEN].filter((i, k, a) => i != null && a.indexOf(i) === k && live.includes(i));
};
const playerNo = (i) => window.hsefPadOrder().indexOf(i) + 1;
const padKey = (key) => document.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true }));
function rumble(gp, ms = 40) {
  if (!padPrefs.rumble) return;
  try { gp.vibrationActuator && gp.vibrationActuator.playEffect("dual-rumble", { duration: ms, strongMagnitude: 0.4, weakMagnitude: 0.6 }); } catch { /* */ }
}
// البند 4: نوع اليد من رقم الشركة والمنتج (Vendor/Product) في اسمها، مع تصحيح يدوي يُحفظ باسمها
const PAD_KINDS = { ps: "بلايستيشن", xbox: "إكس بوكس", nintendo: "نينتندو", "8bitdo": "8BitDo", generic: "عامة" };
const PAD_VENDORS = { "054c": "ps", "0f0d": "ps", "045e": "xbox", "0e6f": "xbox", "24c6": "xbox", "046d": "xbox", "0738": "xbox", "1532": "xbox",
  "057e": "nintendo", "20d6": "nintendo", "2dc8": "8bitdo" };
let PADKINDS = {};
try { PADKINDS = JSON.parse(localStorage.getItem("hsef-padtypes") || "{}"); } catch { /* */ }
function padIds(gp) {
  const id = (gp && gp.id) || "";
  const m = id.match(/Vendor:\s*([0-9a-f]{4}).*?Product:\s*([0-9a-f]{4})/i) || id.match(/^([0-9a-f]{4})-([0-9a-f]{4})-/i);
  return m ? [m[1].toLowerCase(), m[2].toLowerCase()] : ["", ""];
}
function padKind(gp) {
  if (!gp) return "generic";
  if (PADKINDS[gp.id]) return PADKINDS[gp.id];
  const [v] = padIds(gp);
  return PAD_VENDORS[v] || (/dualsense|dualshock|wireless controller|playstation/i.test(gp.id) ? "ps" : /xbox|x-box/i.test(gp.id) ? "xbox"
    : /nintendo|pro controller|joy-?con/i.test(gp.id) ? "nintendo" : "generic");
}
function setPadKind(gp, kind) {
  if (kind) PADKINDS[gp.id] = kind; else delete PADKINDS[gp.id];
  try { localStorage.setItem("hsef-padtypes", JSON.stringify(PADKINDS)); } catch { /* */ }
}
window.hsefPadKind = (i) => padKind(livePads().find((g) => g.index === i));
function padFire(name, gp) {
  const t = top();
  if (t && t.isGame && t.asking) { if (name === "ps") { t.closeAsk(true); return; } }   // البند 51: PS مرة ثانية = خروج
  else if (t && t.isGame) { if (name === "ps") { if (t.askExit) t.askExit(); else padKey("Escape"); } return; }  // داخل اللعبة: اليد للعبة، وزر PS للخروج
  if (t && t.padTest && ["l1", "r1", "l2", "r2", "options", "create", "triangle", "square"].includes(name)) return;   // البند 73: صفحة «تعديل» تجربة فقط
  // البند 52: «موافق» الزر السفلي و«رجوع» الأيمن في كل الأيادي (بلايستيشن ونينتندو وغير الأصلية)، إلا إن بدّلهما المستعمل
  const swap = !!padPrefs.swap;
  const okB = swap ? "circle" : "cross", backB = swap ? "cross" : "circle";
  const map = { up: "ArrowUp", down: "ArrowDown", left: "ArrowLeft", right: "ArrowRight", options: "MediaPlayPause",
    l1: "MediaTrackPrevious", r1: "MediaTrackNext", l2: "AudioVolumeDown", r2: "AudioVolumeUp", ps: "Home",
    triangle: "ContextMenu", square: "F2" };
  map[okB] = "Enter"; map[backB] = "Escape";
  if (name === okB) rumble(gp);
  if (map[name]) padKey(map[name]);
}
// ترتيب أزرار اليد: يد معروفة (standard) كما هي، ويد عامة بلا ماركة حسب «إعداد يد جديدة» المحفوظ لاسمها
const PAD_ORDER = ["a", "b", "x", "y", "l1", "r1", "l2", "r2", "select", "start", "ls", "rs", "up", "down", "left", "right", "home"];
function padNorm(g, maps) {
  const m = maps && maps[g.id];
  if (!m) return g;
  const on = (c) => !!c && (c.t === "b" ? !!(g.buttons[c.i] && g.buttons[c.i].pressed) : (g.axes[c.i] || 0) * c.s > 0.6);
  const used = new Set(Object.values(m).filter((c) => c && c.t === "a").map((c) => c.i));
  const ax = (i) => (used.has(i) ? 0 : g.axes[i] || 0);
  const buttons = PAD_ORDER.map((k) => { const p = on(m[k]); return { pressed: p, value: p ? 1 : 0, touched: p }; });
  return { id: g.id, index: g.index, connected: g.connected, mapping: "standard", timestamp: g.timestamp, raw: g,
    vibrationActuator: g.vibrationActuator, buttons, axes: [ax(0), ax(1), ax(2), ax(3)] };
}
let PADMAPS = {};
try { PADMAPS = JSON.parse(localStorage.getItem("hsef-padmaps") || "{}"); } catch { /* */ }
const loadPadMaps = async () => {
  try { PADMAPS = (await api("/api/tv/padmaps")).maps || {}; localStorage.setItem("hsef-padmaps", JSON.stringify(PADMAPS)); } catch { /* */ }
};
loadPadMaps();
let padCapture = false;   // أثناء «إعداد يد جديدة» لا تتحرك الواجهة مع الأزرار
let padLoop = 0;
function pollPads() {
  padLoop = 0;
  const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter((g) => g && g.connected).map((g) => padNorm(g, PADMAPS)) : [];
  if (!pads.length) return;   // لا يد موصولة: نتوقف حتى يصل حدث gamepadconnected
  if (padCapture) { padLoop = requestAnimationFrame(pollPads); return; }
  const now = performance.now();
  for (const gp of pads) {
    const b = (i) => !!(gp.buttons[i] && gp.buttons[i].pressed);
    const ax = gp.axes[0] || 0, ay = gp.axes[1] || 0;
    const st = { up: b(12) || ay < -0.6, down: b(13) || ay > 0.6, left: b(14) || ax < -0.6, right: b(15) || ax > 0.6,
      cross: b(0), circle: b(1), square: b(2), triangle: b(3), l1: b(4), r1: b(5), l2: b(6), r2: b(7),
      create: b(8), options: b(9), ps: b(16) };
    const prev = padPrev[gp.index] || {};
    for (const [name, on] of Object.entries(st)) {
      const k = gp.index + name;
      if (on && !prev[name]) { padRep[k] = now + 420; activity(); padTouch(gp); padFire(name, gp); }
      else if (on && ["up", "down", "left", "right"].includes(name) && now > (padRep[k] || 0)) { padRep[k] = now + 140; padFire(name, gp); }
    }
    padPrev[gp.index] = st;
    padState = st; padName = gp.id;
  }
  padLoop = requestAnimationFrame(pollPads);
}
const startPads = () => { if (!padLoop) padLoop = requestAnimationFrame(pollPads); };
addEventListener("gamepadconnected", (e) => {
  const g = e.gamepad, name = g.id.replace(/\(.*\)/, "").trim() || "يد تحكم";
  if (g.mapping !== "standard" && !PADMAPS[g.id]) toast(`🎮 ${name}: يد جديدة. لتعمل أزرارها صحيحة: الإعدادات ← يد التحكم ← «إعداد يد جديدة»`, 9000);
  else toast(`🎮 ${name}`, 2000);
  let saved = ""; try { saved = localStorage.getItem(MAIN_KEY) || ""; } catch { /* */ }
  if (saved && g.id === saved && !livePads().some((x) => x.index === PADMAIN && x.id === saved)) setMainPad(g.index, false);   // الأساسية رجعت
  rumble(g, 120); startPads();
});
addEventListener("gamepaddisconnected", (e) => {
  PADSEEN = PADSEEN.filter((i) => i !== e.gamepad.index);
  if (PADMAIN === e.gamepad.index) PADMAIN = PADSEEN[0] ?? null;
});
startPads();

// ============================================================== لوحة مفاتيح على الشاشة
function oskScreen(opt, done) {
  let val = opt.value || "", shift = false, sym = false, show = !opt.password;
  const LET = ["1234567890", "qwertyuiop", "asdfghjkl@", "zxcvbnm-_."];
  const SYM = ["1234567890", "!#$%&*()+=", "/\\:;?,'[]{", "<>|~^`€£§}"];
  const el = h(`<div class="bg-dark osk"><div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>رجوع</span></button><h1>${esc(opt.title)}</h1></div>
    <div class="osk-in ltr"><span class="v"></span><i class="caret"></i></div><div class="osk-keys ltr"></div>
    ${hints([["موافق", "اختيار الحرف"], [faceIcon("up"), "حذف"], ["رجوع", "إلغاء"]])}</div>`);
  const draw = () => {
    el.querySelector(".v").textContent = show ? val : "•".repeat(val.length);
    const rows = (sym ? SYM : LET).map((r) => `<div class="osk-row">${[...r].map((c) => {
      const ch = shift && !sym ? c.toUpperCase() : c;
      return `<button class="key f" data-c="${esc(ch)}">${esc(ch)}</button>`;
    }).join("")}</div>`).join("");
    const keep = cur && cur.dataset ? (cur.dataset.c ? `[data-c="${CSS.escape(cur.dataset.c)}"]` : cur.dataset.a ? `[data-a="${cur.dataset.a}"]` : null) : null;
    el.querySelector(".osk-keys").innerHTML = rows + `<div class="osk-row">
      <button class="key wide f ${shift ? "on" : ""}" data-a="shift">⇧</button><button class="key wide f" data-a="sym">${sym ? "abc" : "#+="}</button>
      <button class="key space f" data-a="space">مسافة</button><button class="key wide f" data-a="del">⌫</button>
      ${opt.password ? `<button class="key wide f" data-a="eye">${show ? "إخفاء" : "إظهار"}</button>` : ""}
      <button class="key ok wide f" data-a="ok">${esc(opt.okLabel || "تم")}</button></div>`;
    el.querySelectorAll(".osk-keys [data-c]").forEach((b) => b.addEventListener("click", () => { val += b.dataset.c; if (shift) shift = false; draw(); }));
    el.querySelectorAll(".osk-keys [data-a]").forEach((b) => b.addEventListener("click", () => act(b.dataset.a)));
    if (keep) { const n = el.querySelector(keep); if (n) setFocus(n, false); }
  };
  const act = (a) => {
    if (a === "shift") shift = !shift;
    else if (a === "sym") sym = !sym;
    else if (a === "space") val += " ";
    else if (a === "del") val = val.slice(0, -1);
    else if (a === "eye") show = !show;
    else if (a === "ok") { pop(); done(val); return; }
    draw();
  };
  el.querySelector(".js-back").addEventListener("click", pop);
  draw();
  push({
    el, typing: true,
    initial: () => el.querySelector('[data-c="q"]') || el.querySelector(".key"),
    key(e) {
      if (e.key.length === 1 && e.key !== " " && !e.ctrlKey) { val += e.key; draw(); return true; }
      if (e.key === "Backspace" || e.key === "ContextMenu") { act("del"); return true; }
      if (e.key === "F2") { act("space"); return true; }
      return false;
    },
  });
}

// ============================================================== إعدادات التلفاز (للمدير فقط)
// البند 12: إعدادات التلفاز في مجموعات مثل لوحة التحكم
// البند 72: 12 بطاقة في 3 صفوف × 4، كلها بحجم واحد
const SET_GROUPS = [
  ["الشاشة والصوت", [["screen", "الشاشة", "أي شاشة، والدقة", "#10b981,#0ea5e9"], ["size", "حجم الصورة", "الحجم والهوامش", "#14b8a6,#0e7490"],
    ["audio", "الصوت", "مخرج الصوت وتجربته", "#f59e0b,#ea580c"], ["night", "الليل", "الإضاءة، والإطفاء، ومؤقّت النوم", "#6366f1,#1e3a8a"]]],
  ["ما يظهر على التلفاز", [["home", "الصفحة الرئيسية", "البطاقات والطقس", "#f97316,#db2777"], ["look", "المظهر", "الخلفيات واللغة", "#ec4899,#8b5cf6"],
    ["prayer", "الصلاة والأذان", "المواقيت وصوت الأذان", "#059669,#065f46"], ["saver", "شاشة التوقف", "النوع والمدة", "#0ea5e9,#6366f1"]]],
  ["الأجهزة والشبكة", [["pad", "يد التحكم", "اللاعبون، البطارية، الأزرار", "#a855f7,#ec4899"], ["bt", "البلوتوث", "ربط يد جديدة، وسماعات", "#8b5cf6,#06b6d4"],
    ["wifi", "الوايفاي", "الاتصال بشبكة لاسلكية", "#06b6d4,#2563eb"], ["about", "عن الجهاز", "الإصدار، والتحديث، وإعادة التشغيل", "#64748b,#334155"]]],
];
function settingsScreen() {
  const card = ([k, t, s, c]) => `<button class="set-card f" data-k="${k}"><div class="ic" style="background:${A.gradient(c)}">${SET_ICON[k]}</div>
      <div class="tx"><b>${t}</b><span>${s}</span></div></button>`;
  const el = h(`<div class="bg-dark"><div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>الرئيسية</span></button>
    <div class="ti" style="background:linear-gradient(135deg,#64748b,#1e293b)">${GEAR}</div><h1>الإعدادات</h1></div>
    <div class="set-groups">${SET_GROUPS.map(([g, items]) => `<div class="set-group" style="--n:${items.length}"><h2 class="set-gh">${g}</h2><div class="set-grid">${items.map(card).join("")}</div></div>`).join("")}</div>
    ${hints([["موافق", "فتح"], ["رجوع", "الرئيسية"]])}</div>`);
  el.querySelector(".js-back").addEventListener("click", pop);
  el.querySelectorAll(".set-card").forEach((b) => b.addEventListener("click", () => ({ wifi: wifiScreen, bt: btScreen, pad: padScreen, audio: soundSetScreen, saver: saverSetScreen, screen: screenSetScreen,
    size: sizeSetScreen, night: nightSetScreen, home: homeSetScreen, look: lookSetScreen, prayer: prayerSetScreen, about: aboutScreen })[b.dataset.k]()));
  push({ el, initial: () => el.querySelector(".set-card") });
}
const GEAR = `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/></svg>`;
const SET_ICON = {
  screen: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2.5" y="4" width="19" height="13" rx="2"/><path d="M8 21h8M12 17v4"/></svg>`,
  saver: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/><path d="M17 3v3M15.5 4.5h3M20.5 8.5v2M19.5 9.5h2"/></svg>`,
  wifi: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M2 9a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19.5" r="1.2" fill="#fff"/></svg>`,
  bt: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7l10 10-5 5V2l5 5L7 17"/></svg>`,
  pad: A.icon("games"),
  audio: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/></svg>`,
  size: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 8V3h5M21 8V3h-5M3 16v5h5M21 16v5h-5"/><rect x="8" y="8" width="8" height="8" rx="1.5"/></svg>`,
  night: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 15.5A8 8 0 1 1 8.5 4a6.5 6.5 0 0 0 11.5 11.5z"/><path d="M15 3h4l-4 4h4"/></svg>`,
  home: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/></svg>`,
  look: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.6-.8 1.6-1.6 0-1.4-1.3-1.6-1.3-2.9 0-1 .8-1.6 1.8-1.6H17a4 4 0 0 0 4-4c0-4.4-4-7.9-9-7.9z"/><circle cx="7.5" cy="11" r="1.3" fill="#fff"/><circle cx="10.5" cy="7" r="1.3" fill="#fff"/><circle cx="15.5" cy="7.8" r="1.3" fill="#fff"/></svg>`,
  prayer: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3.5c-1.2 1.6-4.5 3-4.5 6.5h9c0-3.5-3.3-4.9-4.5-6.5z"/><path d="M5.5 21V12h13v9M3 21h18M10 21v-3.5a2 2 0 0 1 4 0V21M19.5 12V6.5M4.5 12V6.5"/></svg>`,
  about: `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.2"/></svg>`,
};

// ============================================================== البند 72: صفوف الإعدادات
// كل صف: رمز، وعنوان، وقيمة بين ‹ ›. الأسهم ← → تغيّر القيمة، و«موافق» تنتقل إلى التالية. تُحفظ فوراً وتُطبَّق على الشاشة.
// الأنواع: values (اختيارات تدور)، أو min/max/step (أرقام)، أو action (زر، ومع confirm يحتاج ضغطة ثانية)، أو pick (قائمة في صفحة).
const ONOFF = [[true, "مفعّل"], [false, "متوقف"]];
let optQ = Promise.resolve();
const sameV = (a, b) => String(a) === String(b);
function optValues(o) {
  if (o.values) return typeof o.values === "function" ? o.values() : o.values;
  const out = [];
  for (let v = o.min; v <= o.max; v += o.step) out.push([v, o.fmt ? o.fmt(v) : String(v)]);
  return out;
}
async function saveTV(patch) {
  const r = await api("/api/tv/admin/settings", { json: patch });
  const langChanged = patch.lang && patch.lang !== (settings.lang || "ar");
  settings = r.settings;
  applyPrefs();   // الحجم والهامش والإضاءة تظهر فوراً؛ والشاشة الرئيسية تُرسم من جديد خلال دقيقة
  if (langChanged) { toast("تتغير لغة الواجهة الآن…", 2500); setTimeout(() => location.reload(), 1200); }
  return r;
}
function optList(box, rows) {
  const draw = (focusI) => {
    box.innerHTML = rows.map((o, i) => {
      if (o.hidden?.()) return "";
      const hint = o.hint ? `<small>${typeof o.hint === "function" ? o.hint() : o.hint}</small>` : "";
      if (o.action || o.pick) {
        const val = o._armed ? "اضغط مرة ثانية للتأكيد" : o.value ? o.value() : "اضغط «موافق»";
        return `<button class="opt-row f act${o._armed ? " armed" : ""}" data-i="${i}"><span class="oi">${o.icon}</span><b>${o.label}${hint}</b><span class="ov">${esc(val)}</span></button>`;
      }
      const vals = optValues(o), cv = o._pend !== undefined ? o._pend : o.get(), it = vals.find(([v]) => sameV(v, cv)) || [cv, String(cv ?? "—")];
      return `<button class="opt-row f${o.changed?.() ? " changed" : ""}" data-i="${i}"><span class="oi">${o.icon}</span><b>${o.label}${hint}</b><span class="ov"><i>‹</i><em>${esc(it[1])}</em><i>›</i></span></button>`;
    }).join("");
    box.querySelectorAll(".opt-row").forEach((b) => {
      const i = +b.dataset.i;
      b.addEventListener("click", () => step(i, 1, true));
      if (!rows[i].action) b._step = (d) => step(i, d, false);
    });
    if (focusI != null) { const f = box.querySelector(`.opt-row[data-i="${focusI}"]`); if (f) setFocus(f, false); }
  };
  const step = async (i, dir, wrap) => {
    const o = rows[i];
    if (o.pick) { o.pick(); return; }
    if (o.action) {
      if (o.confirm && !(o._armed && Date.now() - o._armed < 6000)) {
        o._armed = Date.now(); draw(i);
        setTimeout(() => { if (o._armed && Date.now() - o._armed >= 6000) { o._armed = 0; if (box.isConnected) draw(cur?.dataset?.i != null ? +cur.dataset.i : null); } }, 6100);
        return;
      }
      o._armed = 0;
      try { await o.action(); } catch (e) { toast(e.message, 5000); }
      if (box.isConnected) draw(i);
      return;
    }
    const vals = optValues(o), now = o._pend !== undefined ? o._pend : o.get();
    let k = vals.findIndex(([v]) => sameV(v, now));
    if (o.values || wrap) k = (k + dir + vals.length) % vals.length;   // الاختيارات تدور، والأرقام تقف عند الحدّين (و«موافق» تدور)
    else k = Math.max(0, Math.min(vals.length - 1, (k < 0 ? 0 : k) + dir));
    const v = vals[k][0];
    if (sameV(v, now)) return;
    if (o.set) { o.set(v); o.after?.(v); if (box.isConnected) draw(i); return; }
    // القيمة تظهر فوراً، والحفظ بالترتيب (ضغطات سريعة متتالية لا تضيع ولا يسبق بعضها بعضاً)
    o._pend = v;
    if (box.isConnected) draw(i);
    optQ = optQ.then(() => saveTV(o.patch(v))).then(() => {   // طابور واحد لكل الصفوف: صفوف الأذان مثلاً تحفظ في الإعداد نفسه
      if (sameV(o._pend, v)) o._pend = undefined;
      o.after?.(v);
    }, (e) => { o._pend = undefined; toast(e.message, 5000); if (box.isConnected) draw(cur?.dataset?.i != null ? +cur.dataset.i : i); });
  };
  draw();
  return draw;
}
function optScreen(title, iconKey, rows, note) {
  const el = subScreen(title, iconKey), body = el.querySelector(".set-body");
  body.innerHTML = `<div class="opt-list"></div>${note ? `<p class="set-msg">${note}</p>` : ""}`;
  const draw = optList(body.querySelector(".opt-list"), rows);
  push({ el, initial: () => body.querySelector(".opt-row") });
  return { el, body, draw };
}
// اختيار من قائمة في صفحة (للغة: تغييرها يعيد تحميل الواجهة، فلا تتغير بمجرد المرور بالأسهم)
function pickScreen(title, iconKey, opts, curV, onPick) {
  const el = subScreen(title, iconKey), body = el.querySelector(".set-body");
  body.innerHTML = `<div class="opt-list">${opts.map(([v, n], i) => `<button class="opt-row f pick" data-i="${i}" translate="no"><span class="oi">${sameV(v, curV) ? "✓" : ""}</span><b>${esc(n)}</b></button>`).join("")}</div>`;
  body.querySelectorAll(".opt-row").forEach((b) => b.addEventListener("click", async () => {
    const v = opts[+b.dataset.i][0];
    pop();
    if (!sameV(v, curV)) { try { await onPick(v); } catch (e) { toast(e.message, 5000); } }
  }));
  push({ el, initial: () => body.querySelector(".opt-row .oi:not(:empty)")?.closest(".opt-row") || body.querySelector(".opt-row") });
}

// حجم الصورة: الحجم والهامش، والنتيجة تظهر فوراً مع زوايا صفراء على أطراف الواجهة (إن ظهرت الزوايا كلها فلا شيء مقصوص)
function sizeSetScreen() {
  const { el } = optScreen("حجم الصورة", "size", [
    { icon: "🔍", label: "حجم الواجهة", min: 70, max: 130, step: 5, fmt: (v) => `${v}%`, get: () => +settings.zoom || 100, patch: (v) => ({ zoom: v }) },
    { icon: "🖼️", label: "الهامش حول الأطراف", hint: "زِده إن كانت أطراف الصورة مقصوصة في التلفاز", min: 0, max: 8, step: 1, fmt: (v) => `${v}%`,
      get: () => +settings.margin || 0, patch: (v) => ({ margin: v }) },
    { icon: "↺", label: "الرجوع إلى الأصل", value: () => "100% بلا هامش", action: async () => { await saveTV({ zoom: 100, margin: 0 }); } },
  ], "الأسهم ← → تغيّر القيمة وترى النتيجة فوراً. يجب أن تظهر الزوايا الصفراء الأربع كاملة على أطراف التلفاز.");
  el.insertAdjacentHTML("beforeend", `<div class="size-guide"><i></i><i></i><i></i><i></i></div>`);
}

// الليل: الإضاءة الخفيفة، وإطفاء الشاشة ليلاً، ومؤقّت النوم
const NIGHT_OFF = [["", "أبداً"], ["22:00-06:00", "من 22:00 إلى 6:00"], ["23:00-06:00", "من 23:00 إلى 6:00"], ["00:00-06:00", "من 0:00 إلى 6:00"], ["23:00-07:00", "من 23:00 إلى 7:00"]];
const SLEEP_MINS = [[0, "متوقف"], [15, "بعد 15 دقيقة"], [30, "بعد 30 دقيقة"], [45, "بعد 45 دقيقة"], [60, "بعد ساعة"], [90, "بعد ساعة ونصف"], [120, "بعد ساعتين"]];
function nightSetScreen() {
  optScreen("الليل", "night", [
    { icon: "🌙", label: "إضاءة خفيفة في الليل", hint: "من العشاء حتى الشروق", values: [["auto", "تلقائي"], ["off", "متوقفة"]],
      get: () => settings.night_dim || "auto", patch: (v) => ({ night_dim: v }) },
    { icon: "📴", label: "إطفاء الشاشة ليلاً", hint: "تبقى ساعة صغيرة خافتة، وأي زر يعيدها",
      values: () => { const v = settings.night_off || ""; return NIGHT_OFF.some(([x]) => x === v) ? NIGHT_OFF : [...NIGHT_OFF, [v, v.replace("-", " – ")]]; },
      get: () => settings.night_off || "", patch: (v) => ({ night_off: v }) },
    { icon: "⏲️", label: "مؤقّت النوم", hint: () => (sleepAt ? `تنطفئ الشاشة الساعة ${new Date(sleepAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}` : "يوقف الفيديو والصوت ويطفئ الشاشة"),
      values: SLEEP_MINS, get: () => sleepMins,
      set: (v) => { sleepMins = v; sleepAt = v ? Date.now() + v * 60000 : 0; toast(v ? `🌙 مؤقّت النوم: ${SLEEP_MINS.find(([m]) => m === v)[1]}` : "أُلغي مؤقّت النوم", 3000); } },
  ]);
}

// الصفحة الرئيسية: البطاقات (للجميع، يختارها المدير) والطقس
const HOME_CARD_LIST = [["prayer", "🕌", "مواقيت الصلاة"], ["text", "📖", "نص اليوم"], ["word", "🔤", "كلمة اليوم"], ["calendar", "📅", "التقويم والمناسبات"],
  ["family", "👨‍👩‍👧", "العائلة: أعياد الميلاد والنجوم"], ["memory", "📸", "ذكرى من هذا اليوم"]];
function homeSetScreen() {
  const cards = () => settings.home_cards || ["prayer", "text", "word"];
  optScreen("الصفحة الرئيسية", "home", [
    ...HOME_CARD_LIST.map(([k, ic, n]) => ({ icon: ic, label: n, values: ONOFF, get: () => cards().includes(k),
      patch: (v) => ({ home_cards: HOME_CARD_LIST.map(([x]) => x).filter((x) => (x === k ? v : cards().includes(x))) }) })),
    { icon: "🌤️", label: "الطقس تحت الساعة", hint: "يتصل بالإنترنت كل نصف ساعة", values: ONOFF, get: () => !!settings.weather, patch: (v) => ({ weather: v }) },
  ], "البطاقات تظهر في الشاشة الرئيسية للبالغين، وتتغير خلال دقيقة.");
}

// المظهر: الخلفيات، ولغة الواجهة، والوضع الخفيف
const WALLS = [["animated", "سماء متحركة"], ["photos", "صوري المفضلة"], ["dark", "ليلي هادئ"], ["cars", "🚗 سيارات"], ["islamic", "🕌 إسلامية"]];
const KID_WALLS = [["garden", "🌳 حديقة وسماء"], ["cars", "🚗 سيارات"], ["islamic", "🕌 إسلامية"]];
const TV_LANG_NAMES = [["ar", "العربية"], ["en", "English"], ["fr", "Français"], ["tr", "Türkçe"], ["nl", "Nederlands"]];
const withCustom = (list, v) => (v === "custom" ? [...list, ["custom", "🖼️ صورة من اختياري"]] : list);
function lookSetScreen() {
  optScreen("المظهر", "look", [
    { icon: "🖼️", label: "خلفية شاشة البالغين", values: () => withCustom(WALLS, settings.wallpaper), get: () => settings.wallpaper || "animated", patch: (v) => ({ wallpaper: v }) },
    { icon: "🌳", label: "خلفية شاشة الأطفال", values: () => withCustom(KID_WALLS, settings.kids_wallpaper), get: () => settings.kids_wallpaper || "garden", patch: (v) => ({ kids_wallpaper: v }) },
    { icon: "🌐", label: "لغة الواجهة", value: () => (TV_LANG_NAMES.find(([k]) => k === (settings.lang || "ar")) || [, "العربية"])[1],
      pick: () => pickScreen("لغة الواجهة", "look", TV_LANG_NAMES, settings.lang || "ar", (v) => saveTV({ lang: v })) },
    { icon: "🪶", label: "الوضع الخفيف", hint: "للجهاز أو التلفاز البطيء", values: [["auto", "تلقائي"], ["on", "مفعّل"], ["off", "متوقف"]],
      get: () => settings.lite || "auto", patch: (v) => ({ lite: v }) },
  ], "صور الخلفية المفضلة أو الخاصة تُختار من لوحة التحكم على الكمبيوتر.");
}

// الصلاة والأذان
const ADHAN_PRAYERS = [["fajr", "الفجر"], ["dhuhr", "الظهر"], ["asr", "العصر"], ["maghrib", "المغرب"], ["isha", "العشاء"]];
function prayerSetScreen() {
  const ad = () => ({ on: false, prayers: ADHAN_PRAYERS.map(([k]) => k), volume: 80, remind: 0, pause: true, ...(settings.adhan || {}) });
  const setAd = (patch) => ({ adhan: { ...ad(), ...patch } });
  optScreen("الصلاة والأذان", "prayer", [
    { icon: "🕌", label: "مواقيت الصلاة على الشاشة", values: ONOFF, get: () => !!settings.prayer, patch: (v) => ({ prayer: v }) },
    { icon: "📢", label: "الأذان", values: ONOFF, get: () => !!ad().on, patch: (v) => setAd({ on: v }) },
    { icon: "🔊", label: "صوت الأذان", min: 10, max: 100, step: 10, fmt: (v) => `${v}%`, get: () => +ad().volume || 80, patch: (v) => setAd({ volume: v }) },
    ...ADHAN_PRAYERS.map(([k, n]) => ({ icon: "🕰️", label: `أذان ${n}`, values: ONOFF, get: () => ad().prayers.includes(k),
      patch: (v) => setAd({ prayers: ADHAN_PRAYERS.map(([x]) => x).filter((x) => (x === k ? v : ad().prayers.includes(x))) }) })),
    { icon: "⏰", label: "تذكير قبل الأذان", values: [[0, "بلا تذكير"], [5, "5 دقائق"], [10, "10 دقائق"], [15, "15 دقيقة"], [30, "30 دقيقة"]],
      get: () => +ad().remind || 0, patch: (v) => setAd({ remind: v }) },
    { icon: "⏸️", label: "إيقاف الفيديو والصوت عند الأذان", values: ONOFF, get: () => ad().pause !== false, patch: (v) => setAd({ pause: v }) },
  ], "المدينة وطريقة الحساب وملفات الأذان من لوحة التحكم على الكمبيوتر.");
}

// عن الجهاز: الإصدار والعنوان والمساحة، والبحث عن تحديث (يتصل بالإنترنت عند الضغط فقط)، وإعادة التشغيل
const GB = (b) => `${(b / 1e9).toFixed(b < 1e10 ? 1 : 0)} GB`;
async function aboutScreen() {
  const upd = { state: "", text: "" };
  const rows = [
    { icon: "🔄", label: "ابحث عن تحديث", hint: "يتصل الآن فقط بالإنترنت (GitHub)", value: () => upd.text || "ابحث", action: async () => {
      upd.text = "جارٍ البحث…"; draw();
      const r = await api("/api/tv/admin/update");
      upd.state = r.available ? "new" : "";
      upd.latest = r.latest;
      upd.text = r.status?.running ? "التحديث يعمل الآن…" : r.offline ? "وضع «بدون إنترنت» مفعّل" : r.error ? "تعذر الاتصال" : r.available ? `يوجد إصدار جديد: ${r.latest}` : `لديك آخر إصدار (${r.current})`;
    } },
    { icon: "⬇️", label: "حدّث الآن", hint: "يعيد تشغيل التلفاز وحده بعد التحديث", hidden: () => upd.state !== "new", confirm: true,
      value: () => upd.latest || "", action: async () => { await api("/api/tv/admin/update", { json: {} }); upd.state = ""; upd.text = "جارٍ التحديث… لا تطفئ الجهاز"; } },
    { icon: "📺", label: "أعد تشغيل التلفاز", hint: "إن تجمّدت الصورة أو الصوت", value: () => "أعد التشغيل", confirm: true, action: () => api("/api/tv/admin/power", { json: { action: "tv" } }) },
    { icon: "🔁", label: "أعد تشغيل الجهاز", hint: "يعود خلال دقيقة أو دقيقتين", value: () => "أعد التشغيل", confirm: true,
      action: async () => { await api("/api/tv/admin/power", { json: { action: "reboot" } }); toast("يُعاد تشغيل الجهاز…", 8000); } },
  ];
  const { body, draw } = optScreen("عن الجهاز", "about", rows);
  body.insertAdjacentHTML("afterbegin", `<div class="set-status js-info">…</div>`);
  try {
    const a = await api("/api/tv/admin/about");
    const up = a.uptime == null ? "—" : a.uptime >= 86400 ? `${Math.floor(a.uptime / 86400)} يوم` : a.uptime >= 3600 ? `${Math.floor(a.uptime / 3600)} ساعة` : "أقل من ساعة";
    body.querySelector(".js-info").innerHTML = `<div>الإصدار: <b class="ltr">HOME ANAB ${esc(a.version)}</b> · يعمل منذ: <b>${up}</b></div>
      <div>العنوان في الشبكة: <b class="ltr">${esc(a.name)}.local${a.addresses?.length ? " · " + a.addresses.map(esc).join(" · ") : ""}</b></div>
      ${a.disk ? `<div>المساحة الفارغة: <b class="ltr">${GB(a.disk.free)}</b> من <b class="ltr">${GB(a.disk.total)}</b></div>` : ""}`;
  } catch (e) { body.querySelector(".js-info").textContent = e.message; }
}

// اختيار شاشة التوقف من التلفاز: تظهر فوراً للتجربة
const SAVER_MIN_ROW = { icon: "⏱️", label: "تظهر بعد", values: () => { const L = [[0, "أبداً"], [5, "5 دقائق"], [10, "10 دقائق"], [15, "15 دقيقة"], [30, "30 دقيقة"], [60, "ساعة"]];
  const v = +settings.saver_min || 0; return L.some(([m]) => m === v) ? L : [...L, [v, `${v} دقيقة`]]; }, get: () => +settings.saver_min || 0, patch: (v) => ({ saver_min: v }) };
function saverSetScreen() {
  // البند 61: الأسماء في قائمة فوق بعضها، وعلى الطرف معاينة كبيرة متحركة للشاشة التي عليها التركيز
  const el = subScreen("شاشة التوقف", "saver"), body = el.querySelector(".set-body");
  const draw = () => {
    const cur = settings.saver_kind || "prayer";
    body.innerHTML = `<div class="sv-split"><div class="sv-list">${SAVERS.map(([k, n, ic]) => `<button class="sv-row f${k === cur ? " on" : ""}" data-k="${k}"><span class="emo">${ic}</span><b>${n}</b>${k === cur ? "<i>✓</i>" : ""}</button>`).join("")}</div>
      <div class="sv-side"><div class="sv-big"><span class="emo"></span></div><div class="sv-name"></div>
        <div class="opt-list sv-opt"></div><p class="set-msg">اضغط موافق على أي شاشة لاختيارها وتجربتها بكامل الشاشة، وأي زر للرجوع.</p></div></div>`;
    optList(body.querySelector(".sv-opt"), [SAVER_MIN_ROW]);   // البند 72
    body.querySelectorAll(".sv-row").forEach((b) => b.addEventListener("click", async () => {
      const k = b.dataset.k;
      try { await api("/api/tv/admin/saver", { json: { kind: k } }); } catch (e) { toast(e.message); return; }
      settings.saver_kind = k;
      draw(); shown = null;
      setFocus(body.querySelector(`.sv-row[data-k="${k}"]`));
      showSaver(false, k);
    }));
  };
  draw();
  push({ el, initial: () => el.querySelector(".sv-row.on") || el.querySelector(".sv-row"), onFocus: (f) => f.scrollIntoView?.({ block: "nearest" }) });
  // معاينة واحدة فقط في كل مرة (أخف على الجهاز)، تتبدّل مع التركيز
  let shown = null, pvStop = null;
  const stopPv = () => { try { pvStop?.(); } catch { /* */ } pvStop = null; body.querySelector(".sv-big .sv-mini")?.remove(); };
  const pvId = setInterval(() => {
    if (!el.isConnected) { stopPv(); clearInterval(pvId); return; }
    if (saverEl) { stopPv(); shown = null; return; }
    const row = body.querySelector(".sv-row.focus") || body.querySelector(".sv-row.on");
    const k = row?.dataset.k;
    if (!k || k === shown) return;
    stopPv(); shown = k;
    const [, n, ic] = SAVERS.find((x) => x[0] === k);
    body.querySelector(".sv-name").textContent = k === "mix" ? `${n}: تتبدّل الشاشات كل 4 دقائق` : n;
    body.querySelector(".sv-big .emo").textContent = ic;
    if (k === "mix") return;
    const mini = h(`<div class="saver sv-mini"></div>`);
    body.querySelector(".sv-big").appendChild(mini);
    try { pvStop = startSaver(mini, k); } catch { stopPv(); }
  }, 300);
}

function subScreen(title, iconKey) {
  const el = h(`<div class="bg-dark"><div class="bhead"><button class="back f js-back">${A.CHEVRON}<span>الإعدادات</span></button>
    <div class="ti" style="background:linear-gradient(135deg,#06b6d4,#2563eb)">${SET_ICON[iconKey]}</div><h1>${title}</h1></div>
    <div class="set-body"></div>${hints([["موافق", "اختيار"], ["رجوع", "الإعدادات"]])}</div>`);
  el.querySelector(".js-back").addEventListener("click", pop);
  return el;
}

async function wifiScreen() {
  const el = subScreen("الوايفاي", "wifi"), body = el.querySelector(".set-body");
  const scr = { el };
  push(scr);
  const draw = async (nets) => {
    let d;
    try { d = await api("/api/tv/admin/net"); } catch (e) { body.innerHTML = `<p class="set-msg">${esc(e.message)}</p>`; return; }
    if (!d.available) { body.innerHTML = `<p class="set-msg">متاح على جهاز HOME ANAB المخصص فقط.</p>`; return; }
    const w = d.net.wifi || {};
    let html = `<div class="set-status"><div>الكابل: <b class="ltr">${esc(d.net.ip || "غير موصول")}</b></div>
      <div>الوايفاي: ${w.ssid ? `<b>${esc(w.ssid)}</b> ${w.ip ? `<b class="ltr">${esc(w.ip)}</b>` : "<span class='bad'>بلا عنوان</span>"}` : "غير متصل"}</div></div>`;
    if (!w.iface) html += `<p class="set-msg">لا توجد بطاقة وايفاي في هذا الجهاز.</p>`;
    else if (!w.installed) html += `<button class="btn gold f" data-a="install">تثبيت الوايفاي (يحتاج الكابل والإنترنت)</button>`;
    else {
      html += `<div class="set-row"><button class="btn gold f" data-a="scan">البحث عن الشبكات</button>${w.ssid ? `<button class="btn f" data-a="forget">نسيان «${esc(w.ssid)}»</button>` : ""}</div>`;
      if (nets) html += nets.length ? `<div class="set-list">${nets.map((n, i) => `<button class="set-item f" data-n="${i}"><span class="ltr">${n.signal > -55 ? "▂▄▆█" : n.signal > -70 ? "▂▄▆" : "▂▄"}</span><b>${esc(n.ssid)}</b></button>`).join("")}</div>`
        : `<p class="set-msg">لم تُعثر على شبكات.</p>`;
    }
    body.innerHTML = html;
    body.querySelectorAll("[data-a]").forEach((b) => b.addEventListener("click", () => act(b.dataset.a)));
    body.querySelectorAll("[data-n]").forEach((b) => b.addEventListener("click", () => {
      const n = nets[+b.dataset.n];
      oskScreen({ title: `كلمة مرور «${n.ssid}»`, password: true, okLabel: "اتصال" }, async (pw) => {
        toast("جارٍ الاتصال…", 4000);
        try { const r = await api("/api/tv/admin/wifi/connect", { json: { ssid: n.ssid, password: pw } }); toast(`تم الاتصال ✓ ${r.net && r.net.wifi && r.net.wifi.ip ? r.net.wifi.ip : ""}`, 5000); draw(); }
        catch (e) { toast(`لم ينجح الاتصال: ${e.message}`, 6000); }
      });
    }));
    setFocus(body.querySelector("[data-n]") || body.querySelector(".f") || el.querySelector(".js-back"));
  };
  const act = async (a) => {
    try {
      if (a === "scan") { toast("جارٍ البحث…", 3000); const r = await api("/api/tv/admin/wifi/scan", { json: {} }); return draw(r.networks); }
      if (a === "forget") { await api("/api/tv/admin/wifi/forget", { json: {} }); toast("تم"); }
      if (a === "install") { toast("جارٍ التثبيت… قد يستغرق دقائق", 6000); await api("/api/tv/admin/wifi/install", { json: {} }); toast("تم. أعد تشغيل الجهاز إن لم تظهر البطاقة", 6000); }
    } catch (e) { toast(e.message, 5000); }
    draw();
  };
  draw();
}

function btError(m) {
  if (/press the PS/i.test(m)) return "تم الربط، لكن اليد لم تتصل بعد: اضغط زر PS في اليد مرة واحدة";
  if (/not found|not available/i.test(m)) return "لم نجد اليد: اضغط Create و PS معاً حتى يومض الضوء بسرعة، ثم «البحث» ثم «ربط» مباشرة";
  if (/pairing failed/i.test(m)) return "لم ينجح الربط. اضغط «إزالة» إن وُجدت اليد، ثم ضعها في وضع الربط (Create + PS) وأعد المحاولة";
  return m;
}

// البند 49: «ربط يد جديدة»: خطوة واحدة. السيرفر يبحث حتى تظهر يد في وضع الربط ويربطها وحده
const PAD_HOWTO = [["🎮", "بلايستيشن 5", "اضغط معاً <b>Create</b> و <b>PS</b> حتى يومض الضوء بسرعة"],
  ["🎮", "بلايستيشن 4", "اضغط معاً <b>Share</b> و <b>PS</b> حتى يومض الضوء الخلفي"],
  ["🎮", "إكس بوكس", "شغّل اليد بزر <b>Xbox</b>، ثم اضغط زر الربط الصغير أعلاها حتى يومض"],
  ["🎮", "سويتش برو وغيرها", "اضغط زر <b>Sync</b> الصغير (أعلى اليد) حتى تومض الأضواء"]];
function padPairScreen(done) {
  const el = subScreen("ربط يد جديدة", "pad"), body = el.querySelector(".set-body");
  let left = 45, alive = true, timer = 0;
  body.innerHTML = `<p class="set-msg" style="font-size:28px;font-weight:800;color:#fde68a">ضع اليد في وضع الربط الآن، وانتظر:</p>
    <div class="set-list">${PAD_HOWTO.map(([i, n, t]) => `<div class="set-item"><span>${i}</span><b>${n}</b><span class="muted">${t}</span></div>`).join("")}</div>
    <p class="set-msg js-st" style="font-size:24px">🔎 أبحث عن اليد… <b class="ltr js-left">45</b></p>`;
  const st = body.querySelector(".js-st");
  timer = setInterval(() => { left = Math.max(0, left - 1); const x = body.querySelector(".js-left"); if (x) x.textContent = left; }, 1000);
  push({ el, destroy() { alive = false; clearInterval(timer); } });
  setFocus(el.querySelector(".js-back"));
  api("/api/tv/admin/bt/pairpad", { json: {} }).then((r) => {
    clearInterval(timer);
    if (!alive) return;
    const n = (r.paired && r.paired.name) || "اليد";
    st.innerHTML = `✅ تم ربط <b class="ltr">${esc(n)}</b>. اضغط أي زر فيها.`;
    toast(`✓ تم ربط ${n}`, 5000);
    setTimeout(() => { if (alive) { pop(); if (done) done(r); } }, 2500);
  }).catch((e) => {
    clearInterval(timer);
    if (!alive) return;
    const m = /no controller/i.test(e.message) ? "لم أجد يداً في وضع الربط. تأكد أن ضوءها يومض بسرعة، ثم جرّب مرة أخرى."
      : /adapter/i.test(e.message) ? "لا يوجد بلوتوث في هذا الجهاز. يمكنك وصل قطعة بلوتوث USB صغيرة." : btError(e.message);
    st.innerHTML = `<span class="bad">${esc(m)}</span>`;
    st.insertAdjacentHTML("afterend", `<div class="set-row"><button class="btn gold f js-again">حاول مرة أخرى</button></div>`);
    const again = body.querySelector(".js-again");
    again.addEventListener("click", () => { pop(); padPairScreen(done); });
    setFocus(again);
  });
}

// البند 4: بطارية الأيادي (من السيرفر كل دقيقة)، وتنبيه عند ضعفها
let PADBAT = [], batWarned = {};
async function pollBattery() {
  try { PADBAT = (await api("/api/tv/pads/battery")).pads || []; } catch { PADBAT = []; }
  for (const b of PADBAT) {
    const low = b.status !== "Charging" && ((b.capacity != null && b.capacity <= 15) || /low|critical/i.test(b.level || ""));
    if (low && (!batWarned[b.id] || Date.now() - batWarned[b.id] > 30 * 60000)) {
      batWarned[b.id] = Date.now();
      toast(`🪫 بطارية ${b.model || b.name || "اليد"} ضعيفة${b.capacity != null ? ` (${b.capacity}%)` : ""}: اشحنها`, 6000);
    }
  }
}
setTimeout(pollBattery, 8000); setInterval(pollBattery, 60000);

// البند 65: حفظ شحن القبضات. بعد مدة بلا لعب (إعداد «إطفاء القبضات»، افتراضياً 15 دقيقة) تُفصل القبضات الموصولة بالبلوتوث،
// فتنطفئ وتبقى مربوطة: زر PS يعيد وصلها. أي زر أو حركة عصا في أي يد (في التلفاز أو داخل لعبة) يعيد العدّ.
let padSeen = Date.now(), padSnap = "", padSlept = false;
async function padsOff(manual = false) {
  try {
    const r = await api("/api/tv/pads/off", { json: {} });
    if (manual) toast(r.off?.length ? `🔌 أُطفئت: ${r.off.join("، ")}. اضغط زر PS لإعادة وصلها` : "لا توجد قبضة بلوتوث موصولة", 4500);
    return r.off || [];
  } catch (e) { if (manual) toast(e.message); return []; }
}
setInterval(() => {
  const pads = livePads();
  if (!pads.length) { padSlept = false; padSeen = Date.now(); padSnap = ""; return; }
  const snap = pads.map((g) => g.index + ":" + g.buttons.map((b) => (b.pressed ? 1 : 0)).join("") + ":" + g.axes.map((a) => (Math.abs(a) > 0.4 ? Math.sign(a) : 0)).join("")).join("|");
  if (snap !== padSnap) { padSnap = snap; padSeen = Date.now(); padSlept = false; return; }
  const mins = settings?.pad_sleep ?? 15;
  if (!mins || padSlept || Date.now() - padSeen < mins * 60000) return;
  padSlept = true;   // مرة واحدة حتى تُستعمل يد من جديد (اليد السلكية لا تُطفأ وتبقى ظاهرة)
  padsOff().then((off) => { if (off.length) toast(`🔌 أُطفئت القبضات بعد ${mins} دقيقة بلا لعب. اضغط زر PS لإعادة وصلها`, 6000); });
}, 5000);
function batFor(g, used) {
  const [v, p] = padIds(g), nm = g.id.replace(/\(.*\)/, "").trim().toLowerCase();
  const b = PADBAT.find((x) => !used.has(x.id) && ((v && x.vendor === v && x.product === p) || (x.name || "").toLowerCase() === nm));
  if (b) used.add(b.id);
  return b;
}
// البند 73: البطارية شريط ونسبة (أو المستوى إن لم تُعرف النسبة)
function batBar(b) {
  if (!b) return `<span class="muted">—</span>`;
  const pct = b.capacity != null ? b.capacity : { Full: 100, High: 75, Normal: 50, Low: 20, Critical: 5 }[b.level] ?? null;
  const ch = b.status === "Charging", low = !ch && pct != null && pct <= 15;
  return `<span class="bat${low ? " low" : ""}${ch ? " chg" : ""}"><i style="width:${pct ?? 0}%"></i></span><em class="ltr">${ch ? "⚡" : ""}${pct != null ? `${pct}%` : ""}</em>`;
}

async function btScreen() {
  const el = subScreen("البلوتوث", "bt"), body = el.querySelector(".set-body");
  push({ el });
  let showAllBt = false;   // الأجهزة بلا اسم (عنوان MAC فقط) مطوية
  const draw = (r) => {
    if (!r.available) { body.innerHTML = `<p class="set-msg">متاح على جهاز HOME ANAB المخصص فقط.</p>`; return; }
    let html = "";
    if (!r.installed) html = `<button class="btn gold f" data-a="install">تثبيت البلوتوث (يحتاج الإنترنت)</button>`;
    else if (!r.adapter) html = `<p class="set-msg">لا يوجد بلوتوث في هذا الجهاز. يمكنك وصل قطعة بلوتوث USB صغيرة.</p>`;
    else {
      const isPad = (d) => d.pad ?? d.icon === "input-gaming";
      const pads = r.devices.filter((d) => isPad(d) && d.paired);
      const others = r.devices.filter((d) => !(isPad(d) && d.paired));
      const devRow = (d) => `<div class="set-item"><span>${d.icon === "input-gaming" ? "🎮" : d.icon && d.icon.startsWith("audio") ? "🎧" : d.icon === "input-keyboard" ? "⌨️" : d.icon === "phone" ? "📱" : "🔵"}</span><b>${esc(d.name)}</b>
          ${d.connected ? `<span class="ok">متصل</span>` : d.paired ? `<span>مقترن</span>` : ""}
          ${!d.connected ? `<button class="btn f" data-p="pair" data-m="${d.mac}">${d.paired ? "اتصال" : "ربط"}</button>` : ""}
          ${d.paired ? `<button class="btn f" data-p="remove" data-m="${d.mac}">إزالة</button>` : ""}</div>`;
      html = `<div class="set-row"><button class="btn gold f js-pairpad">🎮 ربط يد جديدة</button></div>
        <p class="set-msg">أياديك المربوطة (تكفي ضغطة على PS أو Home لتتصل):</p>
        <div class="set-list">${pads.map(devRow).join("") || `<p class="set-msg">لا توجد يد مربوطة بعد. اضغط «ربط يد جديدة».</p>`}</div>
        ${showAllBt ? `<p class="set-msg">أجهزة أخرى (سماعات، لوحة مفاتيح…):</p>
          <div class="set-row"><button class="btn f" data-a="scan">البحث عن أجهزة</button></div>
          <div class="set-list">${others.map(devRow).join("") || `<p class="set-msg">لا توجد أجهزة أخرى.</p>`}</div>`
          : `<div class="set-row"><button class="btn f js-allbt">أجهزة أخرى${others.length ? ` (${others.length})` : ""}: سماعات، لوحة مفاتيح…</button></div>`}`;
    }
    body.innerHTML = html;
    body.querySelector(".js-allbt")?.addEventListener("click", () => { showAllBt = true; draw(r); });
    body.querySelector(".js-pairpad")?.addEventListener("click", () => padPairScreen((x) => draw(x)));
    body.querySelectorAll("[data-a]").forEach((b) => b.addEventListener("click", () => act(b.dataset.a)));
    body.querySelectorAll("[data-p]").forEach((b) => b.addEventListener("click", () => act(b.dataset.p, b.dataset.m)));
    setFocus(body.querySelector(".f") || el.querySelector(".js-back"));
  };
  const act = async (a, mac) => {
    toast({ install: "جارٍ التثبيت…", scan: "جارٍ البحث 15 ثانية…", pair: "جارٍ الربط…", remove: "جارٍ الإزالة…" }[a], 5000);
    try { draw(await api(`/api/tv/admin/bt/${a}`, { json: { mac } })); if (a === "pair") toast("تم الربط ✓ اضغط أي زر في اليد", 5000); }
    catch (e) { toast(btError(e.message), 9000); }
  };
  try { draw(await api("/api/tv/admin/bt")); } catch (e) { body.innerHTML = `<p class="set-msg">${esc(e.message)}</p>`; }
}

// البند 11: الشاشة والدقة من إعدادات التلفاز نفسه (نفس لوحة التحكم)
async function screenSetScreen() {
  const el = subScreen("الشاشة والدقة", "screen"), body = el.querySelector(".set-body");
  push({ el });
  const label = (x) => (x.internal || /^(eDP|LVDS|DSI)/.test(x.name) ? "شاشة اللابتوب" : x.name.replace(/-A-/, " ").replace(/-/g, " "))
    + (x.model ? ` — ${x.model}` : "");
  let r, sel = "";
  const draw = () => {
    const screens = r.screens || [], many = screens.length > 1;
    const cur = screens.find((x) => x.name === sel) || { modes: r.modes || [], saved: r.saved, current: r.current, name: sel };
    body.innerHTML = `${many ? `<p class="set-msg">موصول ${screens.length} شاشات. وضع التلفاز يظهر على واحدة:</p>
        <div class="set-list">
          <button class="set-item f" data-s="auto"><span>${!r.preferred ? "✅" : "🖥️"}</span><b>تلقائي</b><span class="muted">HDMI أولاً</span></button>
          ${screens.map((x) => `<button class="set-item f" data-s="${esc(x.name)}"><span>${r.preferred === x.name ? "✅" : "🖥️"}</span><b class="ltr">${esc(label(x))}</b>
            ${x.name === r.shown ? `<span class="ok">معروضة الآن</span>` : ""}</button>`).join("")}
        </div>
        <p class="set-msg">اختيار شاشة أخرى ينقل وضع التلفاز إليها 20 ثانية للتجربة، ثم يسألك: «حفظ» أو يرجع وحده.</p>` : ""}
      <p class="set-msg">الدقة${many ? ` لـ <b class="ltr">${esc(label(cur))}</b>` : ""} — الحالية: <b class="ltr">${esc(cur.current || "—")}</b></p>
      <div class="set-list">
        <button class="set-item f" data-m=""><span>${!cur.saved ? "✅" : "▫️"}</span><b>تلقائي (أفضل دقة)</b></button>
        ${(cur.modes || []).slice(0, 12).map((m) => `<button class="set-item f" data-m="${esc(m)}"><span>${m === cur.saved ? "✅" : "▫️"}</span><b class="ltr">${esc(m)}</b>
          ${m === "1920x1080" ? `<span class="muted">أنعم للفيديو</span>` : ""}</button>`).join("")}
      </div>
      <p class="set-msg">تغيير الدقة يعيد تشغيل الشاشة ثوانٍ قليلة.</p>`;
    body.querySelectorAll("[data-s]").forEach((b) => b.addEventListener("click", () => pickScreen(b.dataset.s)));
    body.querySelectorAll("[data-m]").forEach((b) => b.addEventListener("click", () => setMode(b.dataset.m)));
    setFocus(body.querySelector(".f") || el.querySelector(".js-back"));
  };
  const load = async () => {
    body.innerHTML = `<p class="set-msg">جارٍ قراءة الشاشات…</p>`;
    try { r = await api("/api/tv/admin/display"); } catch (e) { body.innerHTML = `<p class="set-msg">${esc(e.message)}</p>`; return; }
    if (r.error) { body.innerHTML = `<p class="set-msg">تعذرت قراءة الشاشة.</p>`; return; }
    sel = r.preferred || r.shown || ((r.screens || [])[0] || {}).name || "";
    draw();
  };
  const pickScreen = async (name) => {
    if (name === "auto" || name === r.shown) {
      try { await api("/api/tv/admin/screen", { json: { name } }); toast("تم ✓", 3000); } catch (e) { toast(e.message, 5000); }
      return load();
    }
    // تجربة 20 ثانية: هذه الشاشة قد تفرغ. إن ظهر وضع التلفاز على الأخرى ووافق المدير هناك، يُحفظ
    try {
      await api("/api/tv/admin/screen", { json: { name, try: true } });
      toast("وضع التلفاز ينتقل إلى الشاشة المختارة 20 ثانية… إن أعجبتك ارجع إلى هنا واضغط «حفظ»", 8000);
      sel = name; draw();
      body.insertAdjacentHTML("afterbegin", `<div class="set-row"><button class="btn gold f js-keep">💾 حفظ هذه الشاشة</button></div>`);
      const k = body.querySelector(".js-keep");
      k.addEventListener("click", async () => { try { await api("/api/tv/admin/screen", { json: { name } }); toast("حُفظت الشاشة ✓", 4000); } catch (e) { toast(e.message, 5000); } load(); });
      setFocus(k);
    } catch (e) { toast(e.message, 5000); }
  };
  const setMode = async (mode) => {
    try {
      await api("/api/tv/admin/display", { json: { mode, ...((r.screens || []).length > 1 ? { screen: sel } : {}) } });
      toast("تم — تُعاد تشغيل الشاشة", 5000);
    } catch (e) { toast(e.message, 6000); }
  };
  load();
}

async function soundSetScreen() {
  const el = subScreen("الصوت", "audio"), body = el.querySelector(".set-body");
  push({ el });
  const draw = async () => {
    let r;
    try { r = await api("/api/tv/admin/audio"); } catch (e) { body.innerHTML = `<p class="set-msg">${esc(e.message)}</p>`; return; }
    if (r.error) { body.innerHTML = `<p class="set-msg">تعذرت قراءة مخارج الصوت: <span class="ltr">${esc(r.error)}</span></p>`; return; }
    const cur = r.outputs.find((o) => o.active);
    body.innerHTML = `<div class="set-status"><div>المخرج الحالي: <b>${esc(cur ? cur.name : "—")}</b></div>
        <div>المستوى: <b class="ltr">${r.volume ?? "—"}%</b>${r.muted ? " <span class='bad'>صامت</span>" : ""} · الاختيار: <b>${r.auto ? "تلقائي" : "يدوي"}</b></div></div>
      <div class="set-row"><button class="btn gold f" data-a="test">🔔 تجربة الصوت</button><button class="btn f" data-a="auto">${r.auto ? "✓ " : ""}تلقائي (HDMI التلفاز)</button></div>
      <div class="set-list">${r.outputs.map((o, i) => (o.surround && !o.active ? "" : `<button class="set-item f" data-o="${i}"><span>${o.active ? "🔊" : "🔈"}</span><b>${esc(o.name)}</b>${o.surround ? `<span class="muted">5.1/7.1: أغلب التلفازات لا تُخرج صوتها</span>` : o.plugged ? `<span class="ok">موصول</span>` : o.detected === false ? `<span class="muted">غير مكتشف، جرّبه</span>` : ""}</button>`)).join("")}</div>
      <p class="set-msg">إن لم تسمع صوتاً: اختر المخرج الذي فيه <b class="ltr">HDMI</b> وعليه «موصول»، ثم «تجربة الصوت». وتأكد أن صوت التلفاز نفسه ليس صامتاً.</p>`;
    body.querySelectorAll("[data-a]").forEach((b) => b.addEventListener("click", () => act({ action: b.dataset.a })));
    body.querySelectorAll("[data-o]").forEach((b) => b.addEventListener("click", () => { const o = r.outputs[+b.dataset.o]; act({ card: o.card, profile: o.profile }); }));
    setFocus(body.querySelector(".f") || el.querySelector(".js-back"));
  };
  const act = async (d) => {
    try {
      await api("/api/tv/admin/audio", { json: d });
      toast(d.action === "test" ? "يجب أن تسمع ثلاث نغمات 🎵" : "تم ✓ جرّب الصوت", 4000);
    } catch (e) { toast(e.message, 5000); }
    if (d.action !== "test") draw();
  };
  draw();
}

// ============================================================== إعداد يد جديدة (أي يد تحكم، حتى بلا ماركة)
const PAD_STEPS = [["a", "اضغط الزر السفلي من الأزرار الأربعة"], ["b", "اضغط الزر الأيمن من الأزرار الأربعة"], ["up", "اضغط السهم ↑ أعلى"], ["down", "اضغط السهم ↓ أسفل"],
  ["left", "اضغط السهم ← يسار"], ["right", "اضغط السهم → يمين"], ["home", "اضغط زر الخروج من اللعبة (PS أو Home أو Start)", true],
  ["x", "اضغط الزر الأيسر من الأزرار الأربعة", true], ["y", "اضغط الزر العلوي من الأزرار الأربعة", true], ["l1", "اضغط L1 أو LB", true], ["r1", "اضغط R1 أو RB", true], ["start", "اضغط Options أو Start", true]];
const FACE_STEP = { a: "down", b: "right", x: "left", y: "up" };
function padSetupScreen() {
  const el = subScreen("إعداد يد جديدة", "pad"), body = el.querySelector(".set-body");
  let step = 0, padId = null, rest = null, waitRelease = true, loop = 0;
  const map = {};
  const raw = () => (navigator.getGamepads ? [...navigator.getGamepads()].filter((g) => g && g.connected) : []);
  const draw = () => {
    const [k, msg, opt] = PAD_STEPS[step];
    body.innerHTML = `<div class="set-status"><div>اليد: <b class="ltr">${esc(padId || "اضغط أي زر في اليد التي تريد إعدادها")}</b></div></div>
      <p class="set-msg" style="font-size:30px;font-weight:800;color:#fde68a">${step + 1} / ${PAD_STEPS.length}: ${esc(msg)}</p>
      ${FACE_STEP[k] ? `<div class="face-big">${faceIcon(FACE_STEP[k], 110)}</div><p class="set-msg">بالموقع لا بالرمز: الرموز تختلف بين بلايستيشن ونينتندو والأيادي غير الأصلية.</p>` : ""}
      ${opt ? `<p class="set-msg">اختياري: إن لم يكن في يدك هذا الزر، اضغط زر الرجوع الذي اخترته للتخطي.</p>` : ""}
      <div class="pad-test ltr">${PAD_STEPS.map(([kk]) => `<span class="${map[kk] ? "on" : ""}">${FACE_STEP[kk] ? faceIcon(FACE_STEP[kk], 30) : kk.toUpperCase()}</span>`).join("")}</div>
      <p class="set-msg">للإلغاء: زر «رجوع» في الريموت أو Esc.</p>`;
    void k;
  };
  const save = async () => {
    padCapture = false; cancelAnimationFrame(loop);
    try { PADMAPS = (await api("/api/tv/padmaps", { json: { id: padId, map } })).maps || {}; localStorage.setItem("hsef-padmaps", JSON.stringify(PADMAPS)); }
    catch (e) { toast(e.message, 6000); return; }
    toast("✓ حُفظت اليد، وتعمل الآن في الواجهة وكل الألعاب", 5000);
    pop(); padScreen();
  };
  const tick = () => {
    loop = requestAnimationFrame(tick);
    const pads = raw();
    const g = padId ? pads.find((x) => x.id === padId) : null;
    const cand = g ? [g] : pads;
    for (const p of cand) {
      if (!rest || rest.id !== p.id) { if (!padId) { rest = { id: p.id, axes: [...p.axes] }; } else if (p.id === padId && !rest) rest = { id: p.id, axes: [...p.axes] }; }
      const r = rest && rest.id === p.id ? rest.axes : p.axes.map(() => 0);
      const pressedB = p.buttons.findIndex((x) => x && x.pressed);
      const movedA = p.axes.findIndex((v, i) => Math.abs(v - (r[i] || 0)) > 0.6);
      if (waitRelease) { if (pressedB < 0 && movedA < 0) waitRelease = false; continue; }
      let c = null;
      if (pressedB >= 0) c = { t: "b", i: pressedB };
      else if (movedA >= 0) c = { t: "a", i: movedA, s: p.axes[movedA] - (r[movedA] || 0) > 0 ? 1 : -1 };
      if (!c) continue;
      padId = p.id;
      const [k, , opt] = PAD_STEPS[step];
      const isBack = map.b && map.b.t === c.t && map.b.i === c.i && (c.t === "b" || map.b.s === c.s);
      if (!(opt && isBack)) map[k] = c;
      rumble(p, 60);
      waitRelease = true;
      step++;
      if (step >= PAD_STEPS.length) { save(); return; }
      draw();
      return;
    }
  };
  padCapture = true;
  push({ el, destroy() { padCapture = false; cancelAnimationFrame(loop); } });
  draw();
  loop = requestAnimationFrame(tick);
}

// البند 73: رسالة تأكيد فوق الشاشة الحالية؛ «رجوع» = إلغاء
function tvConfirm(title, html, okLabel = "نعم، احفظ", danger = false) {
  return new Promise((resolve) => {
    const t = top();
    if (!t) { resolve(false); return; }
    const before = cur, prevBack = t.back;
    const m = h(`<div class="tv-modal"><div class="tm-card"><div class="tm-ic">${danger ? "⚠️" : "✏️"}</div><b>${title}</b>${html ? `<div class="tm-body">${html}</div>` : ""}
      <div class="tm-row"><button class="btn ${danger ? "red" : "gold"} f js-yes">${okLabel}</button><button class="btn f js-no">إلغاء</button></div></div></div>`);
    const close = (v) => {
      m.remove(); t.back = prevBack;
      setFocus(before && t.el.contains(before) ? before : focusables()[0]);
      resolve(v);
    };
    m.querySelector(".js-yes").addEventListener("click", () => close(true));
    m.querySelector(".js-no").addEventListener("click", () => close(false));
    t.back = () => close(false);
    t.el.appendChild(m);
    setFocus(m.querySelector(danger ? ".js-no" : ".js-yes"));
  });
}

// القبضات: المقترنة بالبلوتوث (من السيرفر) والموصولة الآن (من المتصفح، ومنها السلكية)
const padClean = (id) => (id || "").replace(/\(.*\)/, "").trim() || "يد تحكم";
function padItems(bt) {
  const live = livePads(), order = window.hsefPadOrder(), used = new Set(), out = [];
  const player = (g) => (g ? order.indexOf(g.index) + 1 : 0);
  for (const d of (bt?.devices || []).filter((x) => (x.pad ?? x.icon === "input-gaming") && x.paired)) {
    const g = d.connected ? live.find((x) => !used.has(x.index) && (padClean(x.id) === d.name || x.id.startsWith(d.name))) : null;
    if (g) used.add(g.index);
    out.push({ key: d.mac, name: d.name || padClean(g?.id), mac: d.mac, connected: !!d.connected, gp: g || null, player: player(g),
      bat: PADBAT.find((b) => b.mac && b.mac === d.mac) || (g ? batFor(g, new Set()) : null) });
  }
  for (const g of live.filter((x) => !used.has(x.index))) {
    out.push({ key: `g${g.index}`, name: padClean(g.id), mac: "", connected: true, gp: g, player: player(g), bat: batFor(g, new Set()), wired: true });
  }
  return out.sort((a, b) => (a.player || 99) - (b.player || 99));
}
function padScreen() {
  const el = subScreen("يد التحكم", "pad"), body = el.querySelector(".set-body");
  body.innerHTML = `<div class="pad-list js-pads"></div><div class="pad-foot"><button class="btn gold f js-add">➕ إضافة قبضة</button></div>`;
  const list = body.querySelector(".js-pads");
  let bt = null, sig = "";
  let first = true;
  const draw = () => {
    const items = padItems(bt);
    const s2 = JSON.stringify(items.map((x) => [x.key, x.connected, x.player, x.bat?.capacity, x.bat?.level, x.bat?.status]));
    if (s2 === sig) return;
    sig = s2;
    const keep = cur && list.contains(cur) ? [cur.closest(".pad-row")?.dataset.key, cur.dataset.a] : null;
    list.innerHTML = items.length ? items.map((x) => {
      const st = x.connected ? `${x.wired ? "سلكية" : "متصلة"}${x.player ? ` · اللاعب ${x.player}` : ""}${x.player === 1 ? " · الأساسية" : ""}` : "غير متصلة · اضغط زر PS في اليد لتتصل";
      return `<div class="pad-row${x.connected ? "" : " off"}" data-key="${esc(x.key)}"><div class="pr-ic">${x.player === 1 ? "⭐" : "🎮"}</div>
        <div class="pr-tx"><b><bdi>${esc(x.name)}</bdi></b><span>${st}</span></div><div class="pr-bat">${x.connected ? batBar(x.bat) : ""}</div>
        <div class="pr-acts"><button class="btn f" data-a="edit">✏️ تعديل</button>${x.mac && x.connected ? `<button class="btn f" data-a="disc">فصل</button>` : ""}${x.mac ? `<button class="btn f" data-a="unpair">إلغاء الاقتران</button>` : ""}</div></div>`;
    }).join("") : `<div class="pad-empty"><div class="pe-ic">🎮</div><b>لا توجد قبضة مقترنة</b><span>اضغط «إضافة قبضة» بالأسفل، أو صِلها بالسلك.</span></div>`;
    list.querySelectorAll(".pad-row [data-a]").forEach((b) => b.addEventListener("click", () => act(items.find((x) => x.key === b.closest(".pad-row").dataset.key), b.dataset.a)));
    if (keep) setFocus(list.querySelector(`.pad-row[data-key="${CSS.escape(keep[0] || "")}"] [data-a="${keep[1]}"]`) || list.querySelector(".f") || body.querySelector(".js-add"), false);
    else if (first && items.length && cur === body.querySelector(".js-add")) setFocus(list.querySelector(".f"), false);
    if (items.length) first = false;
  };
  const load = async () => {
    try { const r = await api("/api/tv/admin/bt"); bt = r.available && r.installed !== false ? r : null; } catch { bt = null; }
    await pollBattery(); sig = ""; draw();
  };
  const act = async (x, a) => {
    if (!x) return;
    if (a === "edit") { padEditScreen(x); return; }
    const disc = a === "disc";
    const ok = await tvConfirm(disc ? `فصل «${esc(x.name)}»؟` : `إلغاء اقتران «${esc(x.name)}»؟`,
      disc ? "تنطفئ القبضة وتبقى مقترنة، وتعود بالضغط على زر PS." : "لن تتصل بعدها حتى تُضاف من جديد بـ«إضافة قبضة».",
      disc ? "فصل" : "إلغاء الاقتران", !disc);
    if (!ok) return;
    try {
      await api(`/api/tv/admin/bt/${disc ? "disconnect" : "remove"}`, { json: { mac: x.mac } });
      toast(disc ? `🔌 فُصلت: ${x.name}` : `أُلغي اقتران: ${x.name}`, 3500);
    } catch (e) { toast(e.message, 5000); }
    load();
  };
  body.querySelector(".js-add").addEventListener("click", () => { pop(); padPairScreen(() => padScreen()); });
  const tm = setInterval(draw, 1000), tb = setInterval(load, 8000);
  push({ el, initial: () => list.querySelector(".f") || body.querySelector(".js-add"), onShow: () => { sig = ""; load(); },
    destroy() { clearInterval(tm); clearInterval(tb); } });
  draw(); load();
}

// رسم قبضة عام (ليس لماركة): الأزرار بالموقع، وكل زر يُضغط في اليد يضيء
const PAD_SVG = `<svg class="pad-svg" viewBox="0 0 420 250" aria-hidden="true">
  <rect class="pb" x="70" y="58" width="280" height="118" rx="56"/><ellipse class="pb" cx="104" cy="168" rx="58" ry="70" transform="rotate(18 104 168)"/>
  <ellipse class="pb" cx="316" cy="168" rx="58" ry="70" transform="rotate(-18 316 168)"/>
  <rect data-p="l2" x="84" y="10" width="70" height="26" rx="10"/><rect data-p="r2" x="266" y="10" width="70" height="26" rx="10"/>
  <rect data-p="l1" x="78" y="40" width="82" height="15" rx="7"/><rect data-p="r1" x="260" y="40" width="82" height="15" rx="7"/>
  <rect data-p="up" x="108" y="80" width="22" height="26" rx="4"/><rect data-p="down" x="108" y="122" width="22" height="26" rx="4"/>
  <rect data-p="left" x="84" y="103" width="26" height="22" rx="4"/><rect data-p="right" x="128" y="103" width="26" height="22" rx="4"/>
  <circle data-p="b3" cx="304" cy="86" r="14"/><circle data-p="b2" cx="278" cy="114" r="14"/><circle data-p="b1" cx="330" cy="114" r="14"/><circle data-p="b0" cx="304" cy="142" r="14"/>
  <rect data-p="create" x="166" y="80" width="24" height="13" rx="6"/><rect data-p="options" x="230" y="80" width="24" height="13" rx="6"/>
  <circle data-p="ps" cx="210" cy="124" r="12"/>
  <circle data-p="ls" cx="166" cy="164" r="25"/><circle class="knob js-lk" cx="166" cy="164" r="13"/>
  <circle data-p="rs" cx="254" cy="164" r="25"/><circle class="knob js-rk" cx="254" cy="164" r="13"/></svg>`;

// صفحة «تعديل»: رسم القبضة، والخيارات تبقى معلّقة حتى «حفظ التعديل» ثم رسالة التأكيد
const PAD_KIND_LIST = [[null, "تلقائي"], ["ps", "بلايستيشن"], ["xbox", "إكس بوكس"], ["nintendo", "نينتندو"], ["8bitdo", "8BitDo"], ["generic", "عامة (بلا ماركة)"]];
const PAD_SLEEP_LIST = [[5, "5 دقائق"], [10, "10 دقائق"], [15, "15 دقيقة"], [30, "30 دقيقة"], [60, "ساعة"], [0, "أبداً"]];
function padEditScreen(item) {
  const el = subScreen("تعديل القبضة", "pad"), body = el.querySelector(".set-body");
  const gpNow = () => livePads().find((g) => item.gp && g.index === item.gp.index && padClean(g.id) === padClean(item.gp.id))
    || livePads().find((g) => padClean(g.id) === item.name || g.id.startsWith(item.name)) || null;
  const p = {};   // التعديلات المعلّقة
  const has = (k) => Object.prototype.hasOwnProperty.call(p, k);
  const isMain = () => { const g = gpNow(); return !!g && window.hsefPadOrder()[0] === g.index; };
  const rows = [
    { icon: "⭐", label: "اجعلها اليد الأساسية (اللاعب 1)", hint: "تتحكم بقوائم الألعاب", values: [[false, "لا"], [true, "نعم"]], hidden: () => !gpNow() || isMain(),
      get: () => (has("main") ? p.main : false), set: (v) => { if (v) p.main = true; else delete p.main; }, changed: () => has("main") },
    { icon: "🎮", label: "نوع اليد", hint: "يُعرف وحده؛ غيّره إن كانت الأزرار خطأ", values: PAD_KIND_LIST, hidden: () => !gpNow(),
      get: () => (has("kind") ? p.kind : PADKINDS[gpNow()?.id] || null), set: (v) => { if (sameV(v, PADKINDS[gpNow()?.id] || null)) delete p.kind; else p.kind = v; }, changed: () => has("kind") },
    { icon: "✅", label: "زر الموافقة", hint: "لكل القبضات", values: [[false, "الزر السفلي"], [true, "الزر الأيمن"]],
      get: () => (has("swap") ? p.swap : !!padPrefs.swap), set: (v) => { if (v === !!padPrefs.swap) delete p.swap; else p.swap = v; }, changed: () => has("swap") },
    { icon: "📳", label: "الاهتزاز", hint: "لكل القبضات", values: ONOFF,
      get: () => (has("rumble") ? p.rumble : !!padPrefs.rumble), set: (v) => { if (v === !!padPrefs.rumble) delete p.rumble; else p.rumble = v; }, changed: () => has("rumble") },
    { icon: "🔋", label: "تنطفئ بلا لعب بعد", hint: "لكل القبضات، لحفظ الشحن", values: PAD_SLEEP_LIST,
      get: () => (has("sleep") ? p.sleep : +(settings.pad_sleep ?? 15)), set: (v) => { if (v === +(settings.pad_sleep ?? 15)) delete p.sleep; else p.sleep = v; }, changed: () => has("sleep") },
    { icon: "🛠️", label: "إعداد الأزرار من جديد", hint: "لليد التي لا تعمل أزرارها صحيحة", hidden: () => !gpNow(), value: () => "ابدأ", action: () => padSetupScreen() },
    { icon: "🩺", label: "تشخيص اليد", value: () => "افتح", action: () => padDiagScreen() },
  ];
  body.innerHTML = `<div class="pad-edit"><div class="pe-opts"><div class="opt-list js-opts"></div>
      <div class="pe-btns"><button class="btn gold f js-save">💾 حفظ التعديل</button><button class="btn f js-cancel">إلغاء</button></div></div>
    <div class="pe-draw"><b class="pe-name ltr">${esc(item.name)}</b><div class="pe-svg" dir="ltr">${PAD_SVG}</div><div class="pe-cap js-cap"></div>
      <div class="pad-legend js-legend"></div></div></div>`;
  const draw = optList(body.querySelector(".js-opts"), rows);
  const legend = () => {
    const sw = has("swap") ? p.swap : !!padPrefs.swap;
    body.querySelector(".js-legend").innerHTML = [[sw ? "right" : "down", "موافق"], [sw ? "down" : "right", "رجوع"], ["left", "إضافي"], ["up", "إضافي"]]
      .map(([pos, t]) => `<span>${faceIcon(pos, 30)}<i>${t}</i></span>`).join("");
  };
  rows.forEach((o) => { if (o.set) { const s0 = o.set; o.set = (v) => { s0(v); legend(); }; } });
  legend();
  const save = async () => {
    const lines = [];
    if (has("main")) lines.push("تصير اليد الأساسية (اللاعب 1)");
    if (has("kind")) lines.push(`النوع: ${PAD_KIND_LIST.find(([k]) => sameV(k, p.kind))[1]}`);
    if (has("swap")) lines.push(`زر الموافقة: ${p.swap ? "الأيمن" : "السفلي"}`);
    if (has("rumble")) lines.push(`الاهتزاز: ${p.rumble ? "مفعّل" : "متوقف"}`);
    if (has("sleep")) lines.push(`تنطفئ بلا لعب بعد: ${PAD_SLEEP_LIST.find(([m]) => m === p.sleep)[1]}`);
    if (!lines.length) { toast("لا تعديل للحفظ", 2500); return; }
    if (!(await tvConfirm("تأكيد التعديل", `<ul>${lines.map((l) => `<li>${esc(l)}</li>`).join("")}</ul>`))) return;
    const g = gpNow();
    try {
      if (has("sleep")) await saveTV({ pad_sleep: p.sleep });
      if (has("main") && g) setMainPad(g.index, true);
      if (has("kind") && g) setPadKind(g, p.kind);
      if (has("swap")) padPrefs.swap = p.swap;
      if (has("rumble")) { padPrefs.rumble = p.rumble; if (p.rumble && g) rumble(g, 250); }
      if (has("swap") || has("rumble")) savePad();
    } catch (e) { toast(e.message, 5000); return; }
    toast("✓ تم حفظ التعديل", 3000);
    pop();
  };
  body.querySelector(".js-save").addEventListener("click", save);
  body.querySelector(".js-cancel").addEventListener("click", pop);
  const parts = [...body.querySelectorAll(".pad-svg [data-p]")], lk = body.querySelector(".js-lk"), rk = body.querySelector(".js-rk");
  let raf = 0, wasOn = null;
  const loop = () => {
    const g = gpNow(), n = g ? padNorm(g, PADMAPS) : null;
    const b = (i) => !!(n && n.buttons[i] && n.buttons[i].pressed), ax = (i) => (n && n.axes[i]) || 0;
    const on = { l2: b(6), r2: b(7), l1: b(4), r1: b(5), up: b(12), down: b(13), left: b(14), right: b(15), b0: b(0), b1: b(1), b2: b(2), b3: b(3),
      create: b(8), options: b(9), ps: b(16), ls: b(10) || Math.hypot(ax(0), ax(1)) > 0.4, rs: b(11) || Math.hypot(ax(2), ax(3)) > 0.4 };
    for (const e of parts) e.classList.toggle("on", !!on[e.dataset.p]);
    lk.setAttribute("transform", `translate(${ax(0) * 9} ${ax(1) * 9})`); rk.setAttribute("transform", `translate(${ax(2) * 9} ${ax(3) * 9})`);
    if (wasOn !== !!g) {
      wasOn = !!g;
      body.querySelector(".pe-svg").classList.toggle("off", !g);
      body.querySelector(".js-cap").textContent = g ? "اضغط أي زر في القبضة فيضيء مكانه في الرسم" : "القبضة غير متصلة، وتتصل بالضغط على زر PS";
      draw(cur?.dataset?.i != null && body.contains(cur) ? +cur.dataset.i : null);
    }
    raf = requestAnimationFrame(loop);
  };
  loop();
  // padTest: تجربة الأزرار لا تغيّر الصوت ولا تشغّل شيئاً (الأسهم وموافق ورجوع وPS تعمل كالعادة)
  push({ el, padTest: true, initial: () => body.querySelector(".js-opts .opt-row"), destroy() { cancelAnimationFrame(raf); } });
}

// تقرير يد التحكم: صوّره وأرسله إن لم تعمل اليد
const browserPads = () => { try { return [...navigator.getGamepads()].filter(Boolean).map((g) => `${g.id} · ${g.mapping || "-"}`); } catch { return []; } };
function padDiagHtml(d, pads) {
  const ok = (b) => (b ? `<b class="ok">✓</b>` : `<b class="bad">✗</b>`);
  const busAr = (b) => ({ bluetooth: "بلوتوث", usb: "كابل USB" }[b] || b);
  const k = d.kernel || [], js = d.js || [], m = d.modules || {}, bt = d.bt || {};
  const hasJs = k.some((x) => /js\d/.test(x.handlers));
  return `<div class="diag">
    <div>${ok(k.length)} النظام يرى اليد: ${k.length ? k.map((x) => `<span class="ltr">${esc(x.name)}</span> (${esc(busAr(x.bus))} · <span class="ltr">${esc(x.handlers)}</span>)`).join("، ") : "لا — اليد غير متصلة"}</div>
    <div>${ok(hasJs)} ملف اليد للألعاب: <span class="ltr">${esc(js.join(" | ") || "—")}</span></div>
    <div>${ok(/\binput\b/.test(d.tv_groups || ""))} صلاحية التلفاز: <span class="ltr">${esc(d.tv_groups || "—")}</span></div>
    <div>${ok(m.joydev && m.hid_playstation)} التعريفات: <span class="ltr">${Object.entries(m).map(([n, v]) => `${n}${v ? "✓" : "✗"}`).join(" ")}</span></div>
    <div>${ok(pads.length)} المتصفح يرى: <span class="ltr">${esc(pads.join(" | ") || "لا شيء (اضغط زراً في اليد ثم أعد التشخيص)")}</span></div>
    <div>🔵 البلوتوث: <span class="ltr">${esc(bt.adapter || "لا يوجد")}</span></div>
    ${(bt.devices || []).map((x) => `<div class="ltr sm">${esc(x.name || x.mac)} — paired:${esc(x.paired)} bonded:${esc(x.bonded || "?")} trusted:${esc(x.trusted)} connected:${esc(x.connected)}</div>`).join("")}
    ${d.nintendo_failed || d.generic ? `<div>${d.generic ? "🔧 أيادي سويتش غير الأصلية تعمل بالتعريف العام" : "⚠️ تعريف نينتندو رفض يداً (غالباً غير أصلية)"}</div>` : ""}
    ${(d.log || []).length ? `<pre class="ltr">${esc(d.log.slice(-8).join("\n"))}</pre>` : ""}
  </div>`;
}
async function padDiagScreen() {
  const el = subScreen("تشخيص يد التحكم", "pad"), body = el.querySelector(".set-body");
  push({ el });
  body.innerHTML = `<p class="set-msg">جارٍ الفحص…</p>`;
  try {
    const d = await api("/api/tv/admin/pad/diag");
    body.innerHTML = d.available === false ? `<p class="set-msg">متاح على جهاز HOME ANAB المخصص فقط.</p>`
      : `${padDiagHtml(d, browserPads())}
        <div class="set-row"><button class="btn f js-generic">${d.generic ? "↩️ إرجاع تعريف نينتندو الأصلي" : "🔧 يد سويتش غير أصلية: استعمل التعريف العام"}</button></div>
        <p class="set-msg">لأيادي «مناسبة لسويتش» التي تتصل ولا تعمل أزرارها: اضغط الزر، ثم افصل اليد وأعد ربطها، ثم «إعداد يد جديدة».</p>
        <p class="set-msg">صوّر هذه الشاشة وأرسلها إن لم تعمل اليد.</p>`;
    body.querySelector(".js-generic")?.addEventListener("click", async () => {
      try { await api("/api/tv/admin/pad/generic", { json: { on: !d.generic } }); } catch (e) { toast(e.message, 6000); return; }
      toast(d.generic ? "عاد تعريف نينتندو الأصلي" : "✓ تم. افصل اليد وأعد ربطها، ثم «إعداد يد جديدة»", 8000);
      pop(); padDiagScreen();
    });
  } catch (e) { body.innerHTML = `<p class="set-msg">${esc(e.message)}</p>`; }
}

// ============================================================== البدء
if (TV.preview) {
  const b = h(`<div class="badge-preview">معاينة من الكمبيوتر: الأسهم للتنقل، Enter للاختيار، Esc للرجوع</div>`);
  stage.appendChild(b);
  setTimeout(() => { b.style.opacity = 0; }, 7000);
}
whoScreen(true);
